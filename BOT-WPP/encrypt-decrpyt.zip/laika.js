const fs = require("fs");
const path = require("path");
const qrcode = require("qrcode-terminal");
const { Client, Buttons, List, MessageMedia } = require("whatsapp-web.js");
const db_DML = require("./DB_DML");
const os = require("os");
RutaEjecutablePrograma = __dirname;
EjecutablePrograma = __filename;
RutaEjecutableProgram = __dirname;
EjecutableProgram = __filename;

var contadorEliminar = 0;

var ContadorExceptGetChat = 0;
const NombreProyecto = "WhatBot_Ingenal_Desarrollo";
const fs2 = require("fs").promises;
const ftp = require("basic-ftp");
var rimraf = require("rimraf");
var Class2 = require("./Class2");

const Gestion = new db_DML.Gestion();
const Permiso = new db_DML.Permiso();
const Mensaje = new db_DML.Mensaje();

const RUTA_CHROME_UBUNTU = "/usr/bin/google-chrome";
const RUTA_CHROME_WINDOWS =
  "C:/Program Files/Google/Chrome/Application/chrome.exe";
//**  APARTADO DE VARIABLRES*/
//agentes
var AgentesOpcion1 = [];
var AgentesOpcion2 = [];
var AgentesOpcion3 = [];

//Rutas de los adjuntos de las opciones de ciudad seleccionadas
var ArrayOpcion1 = [];
var ArrayOpcion2 = [];
//adjuntos nuevo
var filesBogota = [];
var filesCartagena = [];

var LineasAutorizadas = [
  "3053599685",
  "3013775932",
  "3054818254",
  "3106542257",
  "3006870762",
];

Mes = new Date().getMonth() + 1;
if (Mes >= 1 && Mes < 10) {
  Mes = "0" + Mes.toString();
}
Dia = new Date().getDate();
if (Dia >= 1 && Dia < 10) {
  Dia = "0" + Dia.toString();
}
var DiaActual = new Date().getFullYear() + "-" + Mes + "-" + Dia;

const clientWP = new Client({
  puppeteer: {
    headless: false,
    executablePath: getRutaChrome(),
  },
  authTimeoutMs: 3600000,
  clientId: "sesion_mibot",
});

clientWP.initialize();
// * ===============================================
// * ====== [ EVENTOS  Y FUNCIONES DE INCIALIZACIÓN]
// * ===============================================

// * --- se genera código qr
clientWP.on("qr", (qr) => {
  // console.log('QR RECEIVED', qr);
  qrcode.generate(qr, { small: true });
});

// * --- cliente listo
clientWP.on("ready", async () => {
  console.log(`${GetFechaActual()} ${getHoraActual()} READY (cliente listo)`);

  await send_mensaje();
  //no permite que pase de los 10 chats VERIFICAR&&&&&&&&&&&&&&
  eliminarExesoChats();
});

// * --- sesión exitosa en wp web
clientWP.on("authenticated", () => {
  console.log(
    `${GetFechaActual()} ${getHoraActual()} AUTHENTICATED (sesión exitosa)`
  );
});

// * --- sesión no exitosa en wp web
clientWP.on("auth_failure", (msg) => {
  // Fired if session restore was unsuccessfull
  console.error(
    `${GetFechaActual()} ${getHoraActual()} AUTHENTICATION FAILURE (sesión no exitosa)`,
    msg
  );
});

// Obtiene el estado del ultimo mensaje enviado (Solo el ultimo mensaje no los antiguos)
clientWP.on("message_ack", (msg, ack) => {
  /*
        == ACK VALUES ==
        ACK_ERROR: -1
        ACK_PENDING: 0
        ACK_SERVER: 1
        ACK_DEVICE: 2
        ACK_READ: 3
        ACK_PLAYED: 4
    */

  if (ack == -1) {
    EstadoMensaje = "ERROR";
  } else if (ack == 0) {
    EstadoMensaje = "PENDIENTE";
  } else if (ack == 1) {
    EstadoMensaje = "ENTREGADO";
  } else if (ack == 2) {
    EstadoMensaje = "DEVICE";
  } else if (ack == 3) {
    EstadoMensaje = "LEIDO";
  } else if (ack == 4) {
    EstadoMensaje = "REPRODUCIDO";
  } else {
    EstadoMensaje = "DESCONOCIDO";
  }
});

// * --- persona escribe a chat de bot
clientWP.on("message", async (msg) => {
  let numero_chat = msg.from.toString().replace("@c.us", "");

  nombre = await Permiso.valid_numero(numero_chat);

  if (msg.body != "") {
    if (nombre != "") {
      let msg_control = await Gestion.get_msg_by_numero(numero_chat);
      if (msg_control == "") {
        let comprobar = await Gestion.insert_gestion(
          numero_chat,
          "MSG_SALUDO",
          "Activo"
        );
        if (comprobar == true) {
          const MensajeActualAsesor = `Bienvenido ${nombre} a nuestro chat corporativo Laika🐶; cuéntanos cual es tu solicitud:`;
          // clientWP.sendMessage(msg.from, MensajeActualAsesor);
          const options = [
            { title: "Cliente no contesta ni atiende a la puerta" },
            { title: "Valor del pedido" },
            { title: "Dirección no encontrada" },
            { title: "Link de pago" },
            { title: "Pedido no indica que está fuera de zona" },
            { title: "Modificar método de pago" },
            { title: "El cliente retira un producto de la orden" },
            {
              title:
                "Cliente indica que tiene descuento y no aparece en la orden",
            },
            {
              title:
                "Reprogramar orden (se varó, sele quedo el producto, cliente pidió reprogramación)",
            },
            { title: "Demora en la salida del cliente" },
            {
              title: "El cliente no quiere que deje el producto en la portería",
            },
            {
              title:
                "Problemas de pago (no le funciona el datafono, no acepta más métodos de pago) ",
            },
            { title: "Validación de municipio y barrio" },
            { title: "Validar órdenes duplicadas" },
            {
              title:
                "Reprogramación por productos de fabricación (área de bodega)",
            },
          ];
          const menu = [
            { title: "Por favor seleccione un comando", rows: options },
          ];
          const lista = new List(
            MensajeActualAsesor,
            "Seleccione una opción",
            menu
          );
          clientWP.sendMessage(msg.from, lista);
        }
      }else if(msg_control == "MSG_FIN"){
       let id_gestion = await Gestion.get_id_by_numero(numero_chat);
        await Mensaje.insert_mensaje(id_gestion, numero_chat, msg.body, 'chat');
      } else {
        if (msg.type === "list_response") {
          console.log(msg.id.remote);
          let id = await Gestion.get_id_by_numero(numero_chat);
          let comprobar = await Gestion.update_gestion(id, "MSG_FIN", msg.body);
          clientWP.sendMessage(
            msg.from,
            "Espere un momento por favor, en un momento un asesor lo atendera."
          );
        } else {
          clientWP.sendMessage(
            msg.from,
            "No entendi, por favor selecciona una opcion"
          );
        }
      }
    } else {
      clientWP.sendMessage(
        msg.from,
        "Lo siento, este número no está autorizado para usar este chat."
      );

      const options = [
        { title: "Cliente no contesta ni atiende a la puerta" },
        { title: "Valor del pedido" },
        { title: "Dirección no encontrada" },
        { title: "Link de pago" },
        { title: "Pedido no indica que está fuera de zona" },
        { title: "Modificar método de pago" },
        { title: "El cliente retira un producto de la orden" },
        {
          title: "Cliente indica que tiene descuento y no aparece en la orden",
        },
        {
          title:
            "Reprogramar orden (se varó, sele quedo el producto, cliente pidió reprogramación)",
        },
        { title: "Demora en la salida del cliente" },
        {
          title: "El cliente no quiere que deje el producto en la portería",
        },
        {
          title:
            "Problemas de pago (no le funciona el datafono, no acepta más métodos de pago) ",
        },
        { title: "Validación de municipio y barrio" },
        { title: "Validar órdenes duplicadas" },
        {
          title: "Reprogramación por productos de fabricación (área de bodega)",
        },
      ];
      const menu = [
        { title: "Por favor seleccione un comando", rows: options },
      ];
      const lista = new List(
        MensajeActualAsesor,
        "Seleccione una opción",
        menu
      );
      clientWP.sendMessage(msg.from, lista);
    }
  }
});

//Funcion de espera
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function send_mensaje() {
  setInterval(async () => {
    let respuesta = await Mensaje.get_mensaje();
    if (respuesta != null) {
      console.log(respuesta);
      clientWP.sendMessage(
        respuesta.MEN_NUMERO_DESTINO + "@c.us",
        respuesta.MEN_TEXTO
      );
      await Mensaje.update_mensaje(respuesta.PKMEN_NCODIGO, "ENVIADO");
    }
  }, 2000);
}
function GetFechaActual() {
  Mes = new Date().getMonth() + 1;
  if (Mes >= 1 && Mes < 10) {
    Mes = "0" + Mes.toString();
  }
  Dia = new Date().getDate();
  if (Dia >= 1 && Dia < 10) {
    Dia = "0" + Dia.toString();
  }
  var FechaActual = new Date().getFullYear() + "-" + Mes + "-" + Dia;
  return FechaActual;
}

function getHoraActual() {
  const HOY = new Date();
  const HORA = HOY.getHours();
  let MIN = HOY.getMinutes();
  MIN = MIN.toString().length === 1 ? `0${MIN}` : MIN;

  return `${HORA}:${MIN}`;
}

function getRutaChrome() {
  if (os.platform == "linux") {
    return RUTA_CHROME_UBUNTU;
  } else {
    return RUTA_CHROME_WINDOWS;
  }
}

//SI HAY CAMBIO EN EL ESTADO PROBAR SI ESTA DEPRECATED O AUN FUNCIONA
clientWP.on("change_state", (Estado) => {
  if (Estado == "TIMEOUT") {
    Estado = "TELEFONO SIN CONEXION";
  }
  ControlEstadoSesion("Estado sesion", Estado);
  console.log(Estado);
});

// * ===============================================
// * ====== [ EVENTOS  Y FUNCIONES DE INCIALIZACIÓN]
// * ===============================================

function dumpError(err) {
  if (typeof err === "object") {
    if (err.message) {
      return " Message: " + err.message;
    }
    if (err.stack) {
      return err.stack;
    }
  } else {
    return "dumpError :: El arcumento no es de tipo Objeto.";
  }
}

function ControlErrores(Error) {
  var FechaActual = GetFechaActual();
  var HoraActual = getHoraActual();

  if (!fs.existsSync("logs")) {
    fs.mkdirSync("logs");
  }
  var logger = fs.createWriteStream(`./logs/log_${FechaActual}.txt`, {
    flags: "a",
  });
  var DetalleError = dumpError(Error);
  logger.write(`${Error} ${DetalleError} ${FechaActual} - ${HoraActual}\n`);
}

async function eliminarExesoChats() {
  Correcto = true;
  while (Correcto == true) {
    clientWP.getChats().then((Chats) => {
      //Eliminar el exeso de chats
      if (Chats.length > 10) {
        for (let index = 10; index < Chats.length; index++) {
          if (Chats[index].unreadCount <= 0) {
            Chats[index].delete();
          }
        }
      }
    });
    await sleep(60000);
  }
}

//Elimina los chats antiguos
function Eliminar_Chat(chatAll) {
  try {
    if (contadorEliminar > 5) {
      chatAll.delete();
    } else {
      contadorEliminar = contadorEliminar + 1;
    }
  } catch (error) {
    //
  }
}

//Obtiene la fecha actual
function GetFechaActual() {
  Mes = new Date().getMonth() + 1;
  if (Mes >= 1 && Mes < 10) {
    Mes = "0" + Mes.toString();
  }
  Dia = new Date().getDate();
  if (Dia >= 1 && Dia < 10) {
    Dia = "0" + Dia.toString();
  }
  var FechaActual = new Date().getFullYear() + "-" + Mes + "-" + Dia;
  return FechaActual;
}

//Elimina el chat especifico.
function EliminarChatComando(chatAll, NumeroEjecutor) {
  try {
    if (chatAll.id._serialized == NumeroEjecutor) {
      chatAll.delete();
    }
  } catch (error) {
    //
  }
}

//recarga cada 5 segundos el array de los adjuntos con el fin de evitar detener el bot y ponerlo a correr de nuevo
function reloadFIles() {
  setInterval(() => {
    filesBogota = fs.readdirSync("./docs_Ingenal/BOGOTA");
    filesCartagena = fs.readdirSync("./docs_Ingenal/CARTAGENA");
  }, 5000);
}

//**ACLARACION PARA LOS ADJUNTOS, LOS ADJUNTOS NO NECESITAN UNA RUTA LARGA, CON LA CARPETA DOCS
//*SE PUEDEN HACER ENVIOS PERO SIEMPRE DEBE EXISTIR LA CARPETA LOGS Y LAS SUBCARPETAS CORRESPONDIENTES A LAS CIUDADES*/
//**EN ESTE CASO BOGOTA Y CARTAGENA, NO OBSTANTE PUEDE USARSE LA RUTA LARGA (RutaEjecutableProgram)** /

//envia adjuntos a bogota
function envioBogota(froom) {
  try {
    console.log("los archvos son ", filesBogota);
    console.log("TYPEOF", typeof filesBogota);
    filesBogota.forEach((element) => {
      console.log("los valores", element);
      var media = MessageMedia.fromFilePath("./docs_Ingenal/BOGOTA/" + element);
      clientWP.sendMessage(froom, media);
    });
  } catch (error) {
    ControlErrores(error);
  }
}

//Verifica chats sin respuesta y sin terminar por mas de 30 minutos y envia un mensaje de recordatorio
function RecordarConversacion(MensajeRecordatorio, TiempoRecordatorio) {
  sql =
    "SELECT PKGES_CCODIGO, GES_NUMERO_COMUNICA, GES_CDETALLE, GES_CDETALLE1, GES_CDETALLE2, GES_CDETALLE3, GES_CDETALLE5, TIMESTAMPDIFF(MINUTE, GES_CFECHA_MODIFICACION, NOW()) AS DIFERENCIA_TIEMPO FROM u632406828_dbp_whatsappbo.tbl_cgestion WHERE GES_CDETALLE7 IS NULL AND GES_CDETALLE5 IS NULL AND GES_CESTADO = 'Activo' ORDER BY PKGES_CCODIGO DESC LIMIT 1;";
  console.log(sql);
  connDB
    .promise()
    .query(sql)
    .then(([results, fields]) => {
      if (results.length > 0) {
        var CodigoRegistro = results[0].PKGES_CCODIGO;
        var GES_NUMERO_COMUNICA = results[0].GES_NUMERO_COMUNICA;
        var Pregunta1 = results[0].GES_CDETALLE;
        var Pregunta2 = results[0].GES_CDETALLE1;
        var Pregunta3 = results[0].GES_CDETALLE2;
        var Pregunta4 = results[0].GES_CDETALLE3;
        var EstadoRecordado = results[0].GES_CDETALLE5;
        var UltimaFechaInteraccion = results[0].DIFERENCIA_TIEMPO;

        if (
          Pregunta1 == null ||
          Pregunta2 == null ||
          Pregunta3 == null ||
          Pregunta4 == null
        ) {
          if (EstadoRecordado == null) {
            if (UltimaFechaInteraccion >= parseInt(TiempoRecordatorio, 10)) {
              clientWP.sendMessage(
                GES_NUMERO_COMUNICA,
                MensajeRecordatorio + "😊"
              );

              sql =
                "UPDATE " +
                DB +
                ".tbl_cgestion SET GES_CDETALLE5 = 'MENSAJE RECORDATORIO ENVIADO' WHERE (PKGES_CCODIGO = '" +
                CodigoRegistro.toString() +
                "');";
              console.log(sql);
              connDB
                .promise()
                .query(sql)
                .then(([results, fields]) => {})
                .catch((Error) => ControlErrores(Error));
            }
          }
        }
      }
    })
    .catch((Error) => ControlErrores(Error));
}

//Obtiene el tamano actual de un archivo en el PC
function getFilesizeInBytes(filename) {
  var stats = fs.statSync(filename);
  var fileSizeInBytes = stats.size;
  return fileSizeInBytes;
}

Array.prototype.unicos = function () {
  const unicos = [];
  for (i = 0; i < this.length; i++) {
    const valor = this[i];

    if (unicos.indexOf(valor) < 0) {
      unicos.push(valor);
    }
  }

  return unicos;
};
