const fs = require('fs');
const path = require('path');
const qrcode = require('qrcode-terminal');
const { Client, Buttons, List,MessageMedia } = require('whatsapp-web.js');
const mysql = require('mysql2');
const { database } = require('./keys');
const os = require('os');
RutaEjecutablePrograma = __dirname;
EjecutablePrograma = __filename;
RutaEjecutableProgram= __dirname;
EjecutableProgram=__filename ;

var contadorEliminar = 0;

var ContadorExceptGetChat = 0
const NombreProyecto = "WhatBot_Ingenal_Desarrollo";
const fs2 = require('fs').promises
const ftp = require(".//node_modules//basic-ftp")
var rimraf = require(".//node_modules//rimraf");
var Class2 = require(".//Class2")

const RUTA_CHROME_UBUNTU = '/usr/bin/google-chrome';

//**  APARTADO DE VARIABLRES*/
const DB = database.database;
//agentes
var AgentesOpcion1 = [];
var AgentesOpcion2 = [];
var AgentesOpcion3 = [];
//MENSAJES
var mensaje1 = "";
var mensaje2 = "";
var mensaje3 = "";
var mensaje4 = "";
var mensaje5 = "";
var mensaje6 = "";
var mensaje7 = "";
var mensajeDespedida = "";
var mensajeNoEntiende = "";
var mensajeNuevaInteraccion = "";
var mensajeTransferenciaCliente = "";
var mensajeTransferenciaAsesor = "";
//Rutas de los adjuntos de las opciones de ciudad seleccionadas
var ArrayOpcion1 = [];
var ArrayOpcion2 = [];
//adjuntos nuevo
var filesBogota=[] 
var filesCartagena=[] 


var LineasAutorizadas = ["3053599685", "3013775932", "3054818254", "3106542257","3006870762"]

Mes = new Date().getMonth() + 1;
if (Mes >= 1 && Mes < 10) {
    Mes = "0" + Mes.toString();
}
Dia = new Date().getDate();
if (Dia >= 1 && Dia < 10) {
    Dia = "0" + Dia.toString();
}
var DiaActual = new Date().getFullYear() + "-" + Mes + "-" + Dia;


let connDB = mysql.createConnection({
  host: database.host,
  user: database.user,
  database: database.database,
  password: database.password,
  dateStrings: true,
});

const clientWP = new Client({
  puppeteer: {
    headless: false,
    executablePath: getRutaChrome(),
  },
  authTimeoutMs: 3600000,
  clientId: 'sesion_mibot',
});

clientWP.initialize();

// * ===============================================
// * ====== [ EVENTOS  Y FUNCIONES DE INCIALIZACIÓN]
// * ===============================================

// * --- se genera código qr
clientWP.on('qr', (qr) => {
  // console.log('QR RECEIVED', qr);
  qrcode.generate(qr, { small: true });
});

// * --- cliente listo
clientWP.on('ready', async() => {
  console.log(`${GetFechaActual()} ${getHoraActual()} READY (cliente listo)`);
  //carga los mensajes por defecto
  ConsultarParametrosIniciales()

  //Valida el dia actual y el estado de la base de datos
  ValidarDiaNuevo();

  //no permite que pase de los 10 chats VERIFICAR&&&&&&&&&&&&&&
  eliminarExesoChats()
  //llama el envio de mensajes masivos
  EnviarSpam();
  //recarga el array de inicio
  reloadFIles();
  //llama el envio de mensajes masivos
  EnviarSpam();

});

// * --- sesión exitosa en wp web
clientWP.on('authenticated', () => {
  console.log(`${GetFechaActual()} ${getHoraActual()} AUTHENTICATED (sesión exitosa)`);
});

// * --- sesión no exitosa en wp web
clientWP.on('auth_failure', (msg) => {
  // Fired if session restore was unsuccessfull
  console.error(`${GetFechaActual()} ${getHoraActual()} AUTHENTICATION FAILURE (sesión no exitosa)`, msg);
});

// Obtiene el estado del ultimo mensaje enviado (Solo el ultimo mensaje no los antiguos)
clientWP.on('message_ack', (msg, ack) => {
    /*
        == ACK VALUES ==
        ACK_ERROR: -1
        ACK_PENDING: 0
        ACK_SERVER: 1
        ACK_DEVICE: 2
        ACK_READ: 3
        ACK_PLAYED: 4
    */

    if (ack == -1) {
        EstadoMensaje = "ERROR";
    } else if (ack == 0) {
        EstadoMensaje = "PENDIENTE";
    } else if (ack == 1) {
        EstadoMensaje = "ENTREGADO";
    } else if (ack == 2) {
        EstadoMensaje = "DEVICE";
    } else if (ack == 3) {
        EstadoMensaje = "LEIDO";
    } else if (ack == 4) {
        EstadoMensaje = "REPRODUCIDO";
    } else {
        EstadoMensaje = "DESCONOCIDO"
    }

    /*
    sql = "SELECT PKGES_CCODIGO, GES_CDETALLE, GES_CDETALLE1, GES_CDETALLE2, GES_CDETALLE3, GES_CDETALLE4, GES_CDETALLE5, GES_CDETALLE6, GES_CDETALLE7, GES_CDETALLE8, GES_CDETALLE9 FROM " + BaseDatosServidor.toString() + ".tbl_cgestion WHERE GES_NUMERO_COMUNICA = '" + (msg.to).toString() + "' AND GES_CDETALLE9 IS NULL AND GES_CESTADO = 'Activo' ORDER BY PKGES_CCODIGO ASC LIMIT 1;"
    console.log(sql);
    connection2.promise().query(sql)
        .then(([results, fields]) => {
            if (results.length > 0) {
                sql = "UPDATE " + BaseDatosServidor.toString() + ".tbl_cgestion SET GES_CDETALLE6 = '" + (EstadoMensaje).toString() + "' WHERE (PKGES_CCODIGO = '" + (results[0].PKGES_CCODIGO).toString() + "');";
                console.log(sql);
                connection2.promise().query(sql)
                    .then(([results, fields]) => {
                    })
                    .catch((Error) => ControlErrores(Error));
            }
        })
        .catch((Error) => ControlErrores(Error));
    */
});

/* 
clientWP.on('change_state', Estado => {
  if (Estado == "TIMEOUT") {
      Estado = "TELEFONO SIN CONEXION";
  }
  ControlEstadoSesion('Estado sesion', Estado);
  console.log(Estado);
});

ControlEstadoSesion("Desconectado", "Esperando por el telefono");
 */




// * --- persona escribe a chat de bot
clientWP.on('message', async msg => {
  // console.log(objMsg);
  //Se valida si el cliente estuvo en un mensaje masivo anterior
 // console.log('este es todo el msg',msg);
  NumeroCHAT = (msg.from).toString().replace("@c.us", "")
  sql = "SELECT PKENV_NCODIGO, ENV_CKEY_TRANSFERENCIA, ENV_CTRANSFERENCIA, ENV_CKEY_TIPO, ENV_CMENSAJE, ENV_CNOMBREMASIVO, ENV_CADJUNTO FROM " + DB + ".tbl_enviar_mensaje WHERE ENV_CNUMERO_DESTINO = '" + NumeroCHAT.toString() + "' AND ENV_CESTADO_ENVIO = 'ENVIADO' AND ENV_CESTADO_RESPUESTA IS NULL AND ENV_CESTADO = 'Activo' ORDER BY PKENV_NCODIGO ASC LIMIT 1;"; 
   //console.log(sql);
   connDB.promise().query(sql)
   .then(([results, fields]) => {
     
    var Respuesta = 1
    if (results.length > 0) {

      PKENV_NCODIGO = results[0].PKENV_NCODIGO;
      ENV_CKEY_TRANSFERENCIA = results[0].ENV_CKEY_TRANSFERENCIA;
      ENV_CTRANSFERENCIA = results[0].ENV_CTRANSFERENCIA;
      ENV_CKEY_TIPO = results[0].ENV_CKEY_TIPO;
      ENV_CMENSAJE = results[0].ENV_CMENSAJE;
      RUTA_FTP = results[0].ENV_CNOMBREMASIVO;
      ADJUNTO_FTP = results[0].ENV_CADJUNTO.toString().split("|");

      if (ENV_CKEY_TRANSFERENCIA === 'SIN TRANSFERENCIA' || ENV_CKEY_TRANSFERENCIA === 'N/A') {
        sql = "UPDATE " +DB+ ".tbl_enviar_mensaje SET ENV_CESTADO_RESPUESTA = 'RESPONDIDO' WHERE (PKENV_NCODIGO = '" + PKENV_NCODIGO.toString() + "');";
       // console.log(sql);
       console.log("ENTRE A SIN TRANSFRENCIA");
        connDB.promise().query(sql)
            .then(([results, fields]) => {})
            .catch((Error) => ControlErrores(Error));
        Respuesta = 1;
    } 
      else if(ENV_CKEY_TRANSFERENCIA === 'TRANSFERENCIA CIUDAD'){
          console.log("====entre a transferencia de ciudad");
        Ciudad = ParcelarTexto(ENV_CTRANSFERENCIA)
        if (Ciudad.toString() === "Bogota") {
          if (AgentesOpcion1.length >= 1) {
            var FechaActual = GetFechaActual();
            sql = "SELECT FKTRA_NPER_NCODIGO, COUNT(*) AS CANTIDAD FROM " + DB+ ".tbl_ctransferencias, " + DB + ".tbl_rpermiso WHERE PKPER_NCODIGO = FKTRA_NPER_NCODIGO AND PER_CAREA = 'BOGOTA' AND PER_CESTADO = 'Activo' AND PER_CNIVEL = 'Agente' AND TRA_CFECHA_REGISTRO BETWEEN '" + FechaActual.toString() + " 00:00:00' AND '" + FechaActual.toString() + " 23:59:59' AND TRA_CESTADO = 'Activo' GROUP BY FKTRA_NPER_NCODIGO ORDER BY CANTIDAD ASC;";
           // console.log(sql);
            connDB.promise().query(sql)
            .then(([results, fields]) => {
              SiguienteTransferencia = results[0].FKTRA_NPER_NCODIGO;

              //Transferir a opcion 1
              for (let index = 0; index < AgentesOpcion1.length; index++) {
                if (parseInt(AgentesOpcion1[index][0], 10) == SiguienteTransferencia) {
                  sql = "UPDATE " + DB + ".tbl_enviar_mensaje SET ENV_CESTADO_RESPUESTA = 'RESPONDIDO' WHERE (PKENV_NCODIGO = '" + PKENV_NCODIGO.toString() + "');";
                  console.log(sql);
                  connDB.promise().query(sql)
                  .then(([results, fields]) =>{
                     //Transferir asesor al cliente
                     MensajeActualAsesor = mensajeTransferenciaCliente;
                     var re = /NUMERO_ASESOR/g;
                     MensajeActualAsesor = MensajeActualAsesor.replace(re, AgentesOpcion1[index][2]);
                     var re = /NOMBRE_ASESOR/g;
                     MensajeActualAsesor = MensajeActualAsesor.replace(re, AgentesOpcion1[index][1]);
                     clientWP.sendMessage(msg.from, MensajeActualAsesor);

                     //Transferir a asesor
                     let number = AgentesOpcion1[index][2];
                     number = number.includes('@c.us') ? number : `${number}@c.us`;

                    var MensajeMasivoAnterior = ".";
                    if (ENV_CKEY_TIPO === "TEXTO" || ENV_CKEY_TIPO === "MEDIATEXT") {
                        MensajeMasivoAnterior = ", Mensaje enviado al cliente: " + ENV_CMENSAJE + "."
                    }
                    if (ENV_CKEY_TIPO === "MEDIATEXT" || ENV_CKEY_TIPO === "MULTIMEDIA") {

                      for (let index = 0; index < ADJUNTO_FTP.length; index++) {

                        RUTA_ADJUNTO_COMPLETA = RUTA_FTP + "/" + ADJUNTO_FTP[index];
                        if (fs.existsSync('FTP_Agente/' + RUTA_ADJUNTO_COMPLETA)) {
                          console.log('EL ARCHIVO YA EXISTE LOCALMENTE');
                        } else {
                          if (!fs.existsSync('FTP_Agente')) {
                            fs.mkdirSync('FTP_Agente');
                          }
                          if (!fs.existsSync('FTP_Agente/' + RUTA_FTP)) {
                            fs.mkdirSync('FTP_Agente/' + RUTA_FTP);
                          }
                          DescargaFTP(RutaEjecutablePrograma + '/FTP_Agente/' + RUTA_ADJUNTO_COMPLETA, RUTA_ADJUNTO_COMPLETA);
                        }
                        //ENVIAR ADJUNTO
                        try {
                          var media = MessageMedia.fromFilePath(RutaEjecutablePrograma + '/FTP_Agente/' + RUTA_ADJUNTO_COMPLETA);
                          clientWP.sendMessage(number, media);
                        } catch (error) {
                          //
                        }


                      }
                    }
                    MensajeActual = "El cliente con Numero: NUMERO_CLIENTE, ha respondido a un mensaje masivo y se le ha transferido automaticamente a usted MENSAJE_CLIENTE";
                    var re = /NUMERO_CLIENTE/g;
                    MensajeActual = MensajeActual.replace(re, msg.from);
                    var re = /MENSAJE_CLIENTE/g;
                    MensajeActual = MensajeActual.replace(re, MensajeMasivoAnterior);
                    var re = /@c.us/g;
                    MensajeActual = MensajeActual.replace(re, "");
                    clientWP.sendMessage(number, MensajeActual);
                    }).catch((Error) => ControlErrores(Error));

                }


              }
            }).catch((Error) => ControlErrores(Error));
          }
        }
        else if (Ciudad.toString() === "Cartagena") {
          if (AgentesOpcion2.length >= 1) {
            var FechaActual = GetFechaActual();
            sql = "SELECT FKTRA_NPER_NCODIGO, COUNT(*) AS CANTIDAD FROM " + DB + ".tbl_ctransferencias, " + DB + ".tbl_rpermiso WHERE PKPER_NCODIGO = FKTRA_NPER_NCODIGO AND PER_CAREA = 'CARTAGENA' AND PER_CESTADO = 'Activo' AND PER_CNIVEL = 'Agente' AND TRA_CFECHA_REGISTRO BETWEEN '" + FechaActual.toString() + " 00:00:00' AND '" + FechaActual.toString() + " 23:59:59' AND TRA_CESTADO = 'Activo' GROUP BY FKTRA_NPER_NCODIGO ORDER BY CANTIDAD ASC;";
            console.log(sql);
            connDB.promise().query(sql)
            .then(([results, fields]) => {

              SiguienteTransferencia = results[0].FKTRA_NPER_NCODIGO;
              //Transferir a opcion 2
              for (let index = 0; index < AgentesOpcion2.length; index++) {
                if (parseInt(AgentesOpcion2[index][0], 10) == SiguienteTransferencia) {

                  sql = "UPDATE " + DB + ".tbl_enviar_mensaje SET ENV_CESTADO_RESPUESTA = 'RESPONDIDO' WHERE (PKENV_NCODIGO = '" + PKENV_NCODIGO.toString() + "');";
                  console.log(sql);
                  connection2.promise().query(sql)
                  .then(([results, fields]) => {

                    //Transferir asesor al cliente
                    MensajeActualAsesor = mensajeTransferenciaCliente;
                    var re = /NUMERO_ASESOR/g;
                    MensajeActualAsesor = MensajeActualAsesor.replace(re, AgentesOpcion2[index][2]);
                    var re = /NOMBRE_ASESOR/g;
                    MensajeActualAsesor = MensajeActualAsesor.replace(re, AgentesOpcion2[index][1]);
                    clientWP.sendMessage(msg.from, MensajeActualAsesor);

                    //Transferir a asesor
                    let number = AgentesOpcion2[index][2];
                    number = number.includes('@c.us') ? number : `${number}@c.us`;

                    var MensajeMasivoAnterior = ".";

                    if (ENV_CKEY_TIPO === "TEXTO" || ENV_CKEY_TIPO === "MEDIATEXT") {
                    MensajeMasivoAnterior = ", Mensaje enviado al cliente: " + ENV_CMENSAJE + "."
                    }

                    if (ENV_CKEY_TIPO === "MEDIATEXT" || ENV_CKEY_TIPO === "MULTIMEDIA") {
                      for (let index = 0; index < ADJUNTO_FTP.length; index++) {
                        RUTA_ADJUNTO_COMPLETA = RUTA_FTP + "/" + ADJUNTO_FTP[index];
                        if (fs.existsSync("FTP_Agente/" + RUTA_ADJUNTO_COMPLETA)) {
                          console.log("EL ARCHIVO YA EXISTE LOCALMENTE");
                      } else {
                          if (!fs.existsSync("FTP_Agente")) {
                              fs.mkdirSync("FTP_Agente");
                          }
                          if (!fs.existsSync("FTP_Agente/" + RUTA_FTP)) {
                              fs.mkdirSync("FTP_Agente/" + RUTA_FTP);
                          }
                          DescargaFTP(RutaEjecutablePrograma + "/FTP_Agente/" + RUTA_ADJUNTO_COMPLETA, RUTA_ADJUNTO_COMPLETA)
                      }
                      try {
                        var media = MessageMedia.fromFilePath(RutaEjecutablePrograma + "/FTP_Agente/" + RUTA_ADJUNTO_COMPLETA);
                        clientWP.sendMessage(number, media);
                    } catch (error) {
                        //
                    }
                      }
                    }
                    MensajeActual = "El cliente con Numero: NUMERO_CLIENTE, ha respondido a un mensaje masivo y se le ha transferido automaticamente a usted MENSAJE_CLIENTE";
                    var re = /NUMERO_CLIENTE/g;
                    MensajeActual = MensajeActual.replace(re, msg.from);
                    var re = /MENSAJE_CLIENTE/g;
                    MensajeActual = MensajeActual.replace(re, MensajeMasivoAnterior);
                    var re = /@c.us/g;
                    MensajeActual = MensajeActual.replace(re, "");
                    clientWP.sendMessage(number, MensajeActual);

                      }).catch((Error) => ControlErrores(Error));
                }
              }
            }).catch((Error) => ControlErrores(Error));
          }
        }
        Respuesta = 0;
      }
      else if (ENV_CKEY_TRANSFERENCIA === "TRANSFERENCIA AGENTE") {
        console.log("Agente:", ENV_CTRANSFERENCIA);
        for (let index = 0; index < AgentesOpcion1.length; index++) {
          if (parseInt(AgentesOpcion1[index][0], 10) == ENV_CTRANSFERENCIA) {
            //Transferir asesor al cliente
            MensajeActualAsesor = mensajeTransferenciaCliente;
            var re = /NUMERO_ASESOR/g;
            MensajeActualAsesor = MensajeActualAsesor.replace(re, AgentesOpcion1[index][2]);
            var re = /NOMBRE_ASESOR/g;
            MensajeActualAsesor = MensajeActualAsesor.replace(re, AgentesOpcion1[index][1]);
            clientWP.sendMessage(msg.from, MensajeActualAsesor);

            //Transferir a asesor
            let number = AgentesOpcion1[index][2];
            number = number.includes('@c.us') ? number : `${number}@c.us`;

            var MensajeMasivoAnterior = ".";
            if (ENV_CKEY_TIPO === "TEXTO" || ENV_CKEY_TIPO === "MEDIATEXT") {
                MensajeMasivoAnterior = ", Mensaje enviado al cliente: " + ENV_CMENSAJE + "."
            }

             //Envia el archivo adjunto
             if (ENV_CKEY_TIPO === "MEDIATEXT" || ENV_CKEY_TIPO === "MULTIMEDIA") {

              for (let index = 0; index < ADJUNTO_FTP.length; index++) {
                  RUTA_ADJUNTO_COMPLETA = RUTA_FTP + "/" + ADJUNTO_FTP[index];
                  if (fs.existsSync("FTP_Agente/" + RUTA_ADJUNTO_COMPLETA)) {
                      console.log("EL ARCHIVO YA EXISTE LOCALMENTE");
                  } else {
                      if (!fs.existsSync("FTP_Agente")) {
                          fs.mkdirSync("FTP_Agente");
                      }
                      if (!fs.existsSync("FTP_Agente/" + RUTA_FTP)) {
                          fs.mkdirSync("FTP_Agente/" + RUTA_FTP);
                      }
                      DescargaFTP(RutaEjecutablePrograma + "/FTP_Agente/" + RUTA_ADJUNTO_COMPLETA, RUTA_ADJUNTO_COMPLETA)

                  }
                  //ENVIAR ADJUNTO
                  try {
                      var media = MessageMedia.fromFilePath(RutaEjecutablePrograma + "/FTP_Agente/" + RUTA_ADJUNTO_COMPLETA);
                      clientWP.sendMessage(number, media);
                  } catch (error) {
                      //
                  }

              }

          }

          MensajeActual = "El cliente con Numero: NUMERO_CLIENTE, ha respondido a un mensaje masivo y se le ha transferido automaticamente a usted MENSAJE_CLIENTE";
          var re = /NUMERO_CLIENTE/g;
          MensajeActual = MensajeActual.replace(re, msg.from);
          var re = /MENSAJE_CLIENTE/g;
          MensajeActual = MensajeActual.replace(re, MensajeMasivoAnterior);
          var re = /@c.us/g;
          MensajeActual = MensajeActual.replace(re, "");
          clientWP.sendMessage(number, MensajeActual);

          }



        };
        for (let index = 0; index < AgentesOpcion2.length; index++) {
          if (parseInt(AgentesOpcion2[index][0], 10) == ENV_CTRANSFERENCIA) {
            //Transferir asesor al cliente
            MensajeActualAsesor = mensajeTransferenciaCliente;
            var re = /NUMERO_ASESOR/g;
            MensajeActualAsesor = MensajeActualAsesor.replace(re, AgentesOpcion2[index][2]);
            var re = /NOMBRE_ASESOR/g;
            MensajeActualAsesor = MensajeActualAsesor.replace(re, AgentesOpcion2[index][1]);
            clientWP.sendMessage(msg.from, MensajeActualAsesor);

            //Transferir a asesor
            let number = AgentesOpcion2[index][2];
            number = number.includes('@c.us') ? number : `${number}@c.us`;

            var MensajeMasivoAnterior = ".";
            if (ENV_CKEY_TIPO === "TEXTO" || ENV_CKEY_TIPO === "MEDIATEXT") {
              MensajeMasivoAnterior = ", Mensaje enviado al cliente: " + ENV_CMENSAJE + "."
          }
          //Envia el archivo adjunto
          if (ENV_CKEY_TIPO === "MEDIATEXT" || ENV_CKEY_TIPO === "MULTIMEDIA") {

            for (let index = 0; index < ADJUNTO_FTP.length; index++) {
                RUTA_ADJUNTO_COMPLETA = RUTA_FTP + "/" + ADJUNTO_FTP[index];
                if (fs.existsSync("FTP_Agente/" + RUTA_ADJUNTO_COMPLETA)) {
                    console.log("EL ARCHIVO YA EXISTE LOCALMENTE");
                } else {
                    if (!fs.existsSync("FTP_Agente")) {
                        fs.mkdirSync("FTP_Agente");
                    }
                    if (!fs.existsSync("FTP_Agente/" + RUTA_FTP)) {
                        fs.mkdirSync("FTP_Agente/" + RUTA_FTP);
                    }
                    DescargaFTP(RutaEjecutablePrograma + "/FTP_Agente/" + RUTA_ADJUNTO_COMPLETA, RUTA_ADJUNTO_COMPLETA)

                }
                //ENVIAR ADJUNTO
                try {
                    var media = MessageMedia.fromFilePath(RutaEjecutablePrograma + "/FTP_Agente/" + RUTA_ADJUNTO_COMPLETA);
                    clientWP.sendMessage(number, media);
                } catch (error) {
                    //
                }

            }

        }
               MensajeActual = "El cliente con Numero: NUMERO_CLIENTE, ha respondido a un mensaje masivo y se le ha transferido automaticamente a usted MENSAJE_CLIENTE";
              var re = /NUMERO_CLIENTE/g;
              MensajeActual = MensajeActual.replace(re, msg.from);
              var re = /MENSAJE_CLIENTE/g;
              MensajeActual = MensajeActual.replace(re, MensajeMasivoAnterior);
              var re = /@c.us/g;
              MensajeActual = MensajeActual.replace(re, "");
              clientWP.sendMessage(number, MensajeActual);


          }


        };
        sql = "UPDATE " + DB + ".tbl_enviar_mensaje SET ENV_CESTADO_RESPUESTA = 'RESPONDIDO' WHERE (PKENV_NCODIGO = '" + PKENV_NCODIGO.toString() + "');";
        console.log(sql);
        connDB.promise().query(sql)
            .then(([results, fields]) => {})
            .catch((Error) => ControlErrores(Error));
        Respuesta = 0;




      }
      else{
        Respuesta = 1;
      }
        }
    else{
      Respuesta = 1;
    }
     // Respuesta 1: SIN TRANSFERENCIA VALIDA
    // Respuesta 0: TRANSFERENCIA VALIDA, NO PASA POR ARBOL
    if (Respuesta==1) {
      //clientWP.sendMessage(msg.from, "Hola entraste por defecto");
      var textoEnviado = msg.body;
      textoEnviado = textoEnviado.replace(new RegExp('[\u00FF-\uFFFF]+', 'g'), '');
      textoEnviado = textoEnviado.trim();
      textoEnviado = textoEnviado.substring(0, 200);
      console.log("LO QUE SE ESTA ENVIANDO ES ",textoEnviado,"sin hacer trim ni nada de eso",msg.body,msg.type);
      if ((msg.type === 'chat'|| msg.type === 'list_response') && msg.body != "" ) {
        if (msg.body === '!chats' && msg.type === 'list_response') {
          const bool=validarLineasAutorizadad(msg.id.remote);

          if (bool) {
            clientWP.getChats().then(Chats => { msg.reply(`El Bot Tiene ${Chats.length} chats abiertos`) });
          }
          //msg.reply(number)
        }
        else if (msg.body === '!!!StatusPhone' && msg.type === 'list_response' ) {
          const bool=validarLineasAutorizadad(msg.id.remote);
          if (bool) {
            let info = clientWP.info;
            console.log("esta es la info",info);
            //La info que se recogía antes ya no esta disponible en la instancia info del cliente, 
            //los datos versión del whatsapp no esta, tampoco el fabricante del dispositivo.  
            /*los datos que se mantienen son *Nombre de usuario o pushname, el numero del usuario y la plataforma*/
            msg.reply(`_INFO DE CONEXIÓN: USERNAME O PUSHNAME : *${info.pushname}*                    NUMERO (PROPIO CELULAR): *${info.wid.user}*            PLATAFORMA DONDE SE ESTA EJECUTANDO EL BOT: *${info.platform}*_`);
            //INTERACCION CON CUALQUIER MENSAJE RECIBIDO.
          }
          
      }
      //*este metodo aun  no lo entiendo del todo
      else if (msg.body === '!!!Actualizar' && msg.type === 'list_response') {
        const bool=validarLineasAutorizadad(msg.id.remote);
        if (bool) {
          ActualizarParametros();
          msg.reply('Parametros Actualizados');
          console.log('Parametros Actualizados');
        }

      }
      //*este metodo aun  no lo entiendo del todo
      else if (msg.body === '!!!Report_Logs' && msg.type === 'list_response') {
        const bool=validarLineasAutorizadad(msg.id.remote);
        if (bool) {
          try {
            var FechaActual = GetFechaActual();
            if (fs.existsSync(`./logs/log_${FechaActual}.txt`)) {
                var media = MessageMedia.fromFilePath(`./logs/log_${FechaActual}.txt`);
                msg.reply(media);
            } else {
                msg.reply(`No existen Logs para la fecha ${FechaActual}`);
            }
        } catch (error) {
            ControlErrores(error);
        }
        }
        

      }
      //*este metodo aun  no lo entiendo del todo
      else if (msg.body === '!!!Reiniciar_Trabajo' && msg.type === 'list_response') {
        const bool=validarLineasAutorizadad(msg.id.remote);
        if (bool) {
          console.log("el numero es ",msg.from);
          msg.reply('¡por favor espere a que el sistema vuelva a estar en linea!');
  
          ReiniciarTrabajo(msg.from);

        }
        
      }
      else if(msg.body==='!Help'){
        const bool=validarLineasAutorizadad(msg.id.remote);
        if (bool) {
        /*
        messageOfHelp=`Los comandos son:
        *!chats*: cuenta la cantidad de chats activos
        *!!!StatusPhone* : trae el estado del telefono con informacion variada
        *!!!Actualizar*: actualiza todas las variables con las registradas en la base de datos
        *!!!Report_Logs*:  devuelve los logs que se generaron por concepto de cualquier eventualidad
        *!!!Reiniciar_Trabajo*: reinicia el server y elimina el chat de quien le escribe.`
        clientWP.sendMessage(msg.from,messageOfHelp );
*/
        const options =[{title:'Por favor seleccione un comando',rows: [{title:'!chats' },{title:'!!!StatusPhone'},{title:'!!!Actualizar'},{title:'!!!Report_Logs'},{title:'!!!Reiniciar_Trabajo'}] }];
        const lista= new List('Hola','Seleccione una opción',options)
        clientWP.sendMessage(msg.from,lista ).then(()=>{
                    

        });


        }
        
      }
      else if(msg.body==='!rutas'){
          try {
        const options =[{title:'Por favor seleccione una opcion',rows: [{title:'Si' },{title:'No' }] }];
        const lista= new List('Hola','Seleccione una opción',options)
        clientWP.sendMessage(msg.from,lista ).then(()=>{
                      
        
        });
          
          } catch (error) {
            ControlErrores(error)
          }
            }
      else if ((msg.body).includes("'")) {
      msg.reply(mensajeNoEntiende + "La respuesta no puede contener caracteres especiales. (;'+)");
    }
    else{
      try {
      
      //Validar nuevo dia
      Mes = new Date().getMonth() + 1;
      if (Mes >= 1 && Mes < 10) {
          Mes = "0" + Mes.toString();
      }
      Dia = new Date().getDate();
      if (Dia >= 1 && Dia < 10) {
          Dia = "0" + Dia.toString();
      }
      var Hoy = new Date().getFullYear() + "-" + Mes + "-" + Dia;
      if (DiaActual === Hoy) {
          //
      } else {
          Mes = new Date().getMonth() + 1;
          if (Mes >= 1 && Mes < 10) {
              Mes = "0" + Mes.toString();
          }
          Dia = new Date().getDate();
          if (Dia >= 1 && Dia < 10) {
              Dia = "0" + Dia.toString();
          }
          DiaActual = new Date().getFullYear() + "-" + Mes + "-" + Dia;
          ValidarDiaNuevo();
      }
      sql = "SELECT PKGES_CCODIGO, GES_CDETALLE, GES_CDETALLE1, GES_CDETALLE2, GES_CDETALLE3, GES_CDETALLE4, GES_CDETALLE5, GES_CDETALLE6, GES_CDETALLE7, GES_CDETALLE8, GES_CDETALLE9 FROM " + DB + ".tbl_cgestion WHERE GES_NUMERO_COMUNICA = '" + (msg.from).toString() + "' AND GES_CDETALLE9 IS NULL AND GES_CESTADO = 'Activo' ORDER BY PKGES_CCODIGO ASC LIMIT 1;"
      console.log(sql);
      connDB.promise().query(sql)
      .then(([results, fields]) => {
        console.log("AQUI PREGUNTANDO SI YA EXISTE EL QUE ESCRIBE, ESTE ES EL LENGTH ", results.length);
        if (results.length > 0) {
          //Responde preguntando el correo y guarda el nombre
        if (results[0].GES_CDETALLE == null) {
            sql = "UPDATE " + DB + ".tbl_cgestion SET GES_CDETALLE = '" + (msg.body).toString() + "' WHERE (PKGES_CCODIGO = '" + (results[0].PKGES_CCODIGO).toString() + "');";
            console.log(sql);
            connDB.promise().query(sql)
            .then(([results, fields]) => {
                clientWP.sendMessage(msg.from, mensaje2);
            })
            .catch((Error) => ControlErrores(Error));
        }
        else if (results[0].GES_CDETALLE != null && results[0].GES_CDETALLE1 == null) {
            //Guardar correo y preguntar ciudad
            sql = "UPDATE " + DB + ".tbl_cgestion SET GES_CDETALLE1 = '" + (msg.body).toString() + "' WHERE (PKGES_CCODIGO = '" + (results[0].PKGES_CCODIGO).toString() + "');";
            console.log(sql);
            connDB.promise().query(sql)
                .then(([results, fields]) => {
                    const options =[{title:'Por favor seleccione una opcion',rows: [{title:'Bogota' },{title:'Cartagena' }] }];
                    const lista= new List('¿En cual ciudad se encuentra interesado para adquirir vivienda?','Seleccione una opción',options)
                    clientWP.sendMessage(msg.from,lista ).then(()=>{
                    
                    });
                   // clientWP.sendMessage(msg.from, mensaje3);
                })
                .catch((Error) => ControlErrores(Error));
        } 
        else if (results[0].GES_CDETALLE != null && results[0].GES_CDETALLE1 != null && results[0].GES_CDETALLE2 == null && results[0].GES_CDETALLE3 == null) {
        //Guarda la ciudad y trasfiere
        if (((msg.body).toString() === "Bogota" || (msg.body).toString() === "Cartagena") && msg.type === 'list_response' ) {
         //Si selecciona bogotá no desencadena un sub-arbol
          if ((msg.body).toString() === "Bogota") {
              //BOGOTAAAAAAAAAA
            sql = "UPDATE " + DB + ".tbl_cgestion SET GES_CDETALLE2 = '" + (msg.body).toString() + "', GES_CDETALLE3 = 'SinSubArbol', GES_CDETALLE7 = 'TRANSFERIDO' WHERE (PKGES_CCODIGO = '" + (results[0].PKGES_CCODIGO).toString() + "');";
            console.log(sql);
            connDB.promise().query(sql)
            .then(([results, fields]) => {
            //Consultar la ciudad anteriormente seleccionada por el cliente
            var ArrayDatosClientes = [];
            sql = "SELECT PKGES_CCODIGO, GES_NUMERO_COMUNICA, GES_CDETALLE, GES_CDETALLE1, GES_CDETALLE2 FROM " + DB + ".tbl_cgestion WHERE GES_NUMERO_COMUNICA = '" + (msg.from).toString() + "' AND GES_CDETALLE9 IS NULL AND GES_CESTADO = 'Activo' ORDER BY PKGES_CCODIGO ASC LIMIT 1;";
            console.log(sql);
            connDB.promise().query(sql)
            .then(([resultsCiudad, fields]) => {

            //Enviar los documentos
            Codigo_Gestion = resultsCiudad[0].PKGES_CCODIGO;
            ArrayDatosClientes.push(resultsCiudad[0].GES_CDETALLE, resultsCiudad[0].GES_CDETALLE1);
            var MensajeActual = "";
            var MensajeActualAsesor = "";
            var SiguienteTransferencia = "";
            try {
            clientWP.sendMessage(msg.from, mensaje5);
            envioBogota(msg.from);
            console.log("============AQUI");
           // for (let index = 0; index < ArrayOpcion1.length; index++) {
          //  var media = MessageMedia.fromFilePath(ArrayOpcion1[index]);
           // clientWP.sendMessage(msg.from, media);
           // }
            } catch (error) {
            console.error(error);
            }

            if (AgentesOpcion1.length >= 1) {
            //TRAER EL ORDEN JUSTO DE TRANSFERENCIA 
            var FechaActual = GetFechaActual();
            sql = "SELECT FKTRA_NPER_NCODIGO, COUNT(*) AS CANTIDAD FROM " + DB + ".tbl_ctransferencias, " + DB + ".tbl_rpermiso WHERE PKPER_NCODIGO = FKTRA_NPER_NCODIGO AND PER_CAREA = 'BOGOTA' AND PER_CESTADO = 'Activo' AND PER_CNIVEL = 'Agente' AND TRA_CFECHA_REGISTRO BETWEEN '" + FechaActual.toString() + " 00:00:00' AND '" + FechaActual.toString() + " 23:59:59' AND TRA_CESTADO = 'Activo' GROUP BY FKTRA_NPER_NCODIGO ORDER BY CANTIDAD ASC;";
            console.log(sql);
            connDB.promise().query(sql)
            .then(([results, fields]) => {

            SiguienteTransferencia = results[0].FKTRA_NPER_NCODIGO;

            //Transferir a opcion 1

            for (let index = 0; index < AgentesOpcion1.length; index++) {

            if (parseInt(AgentesOpcion1[index][0], 10) == SiguienteTransferencia) {

                //Transferir a asesor
                let number = AgentesOpcion1[index][2];
                number = number.includes('@c.us') ? number : `${number}@c.us`;
                MensajeActual = mensajeTransferenciaAsesor;
                var re = /NOMBRE_CLIENTE/g;
                MensajeActual = MensajeActual.replace(re, ArrayDatosClientes[0]);
                var re = /NUMERO_CLIENTE/g;
                MensajeActual = MensajeActual.replace(re, msg.from);
                var re = /CORREO_CLIENTE/g;
                MensajeActual = MensajeActual.replace(re, ArrayDatosClientes[1]);
                var re = /@c.us/g;
                MensajeActual = MensajeActual.replace(re, "");


                //Transferir asesor al cliente
                MensajeActualAsesor = mensajeTransferenciaCliente;
                var re = /NUMERO_ASESOR/g;
                MensajeActualAsesor = MensajeActualAsesor.replace(re, AgentesOpcion1[index][2]);
                var re = /NOMBRE_ASESOR/g;
                MensajeActualAsesor = MensajeActualAsesor.replace(re, AgentesOpcion1[index][1]);

                var FechaActualCompleta = GetFechaActual() + " " + getHoraActual();
                sql = "INSERT INTO " + DB+ ".tbl_ctransferencias (FKTRA_NPER_NCODIGO, FKTRA_NGES_NCODIGO, TRA_CNUMERO_ASESOR, TRA_CNUMERO_CLIENTE, TRA_MENSAJE_CLIENTE, TRA_MENSAJE_ASESOR, TRA_CFECHA_REGISTRO, TRA_CDETALLE_REGISTRO, TRA_CESTADO) VALUES ('" + (AgentesOpcion1[index][0]).toString() + "', '" + (Codigo_Gestion).toString() + "', '" + (AgentesOpcion1[index][2]).toString() + "', '" + (msg.from).toString().replace("@c.us", "") + "', '" + (MensajeActual).toString() + "', '" + (MensajeActualAsesor).toString() + "', '" + FechaActualCompleta.toString() + "', 'REGISTRO INICIAL DE TRANSFERENCIA', 'Activo');";
                console.log(sql);
                connDB.promise().query(sql)
                    .then(([results, fields]) => {
                        clientWP.sendMessage(number, MensajeActual);
                        clientWP.sendMessage(msg.from, MensajeActualAsesor);
                    })
                    .catch((Error) => ControlErrores(Error));
                break;

                                                  }
                                              }

                                          })
                                          .catch((Error) => ControlErrores(Error));
                                  }
                              })
                              .catch((Error) => ControlErrores(Error));
                      })
                      .catch((Error) => ControlErrores(Error));


              } else if ((msg.body).toString() === "Cartagena") {
                    //CARTAGENAAAAA
                  sql = "UPDATE " + DB + ".tbl_cgestion SET GES_CDETALLE2 = '" + (msg.body).toString() + "' , GES_CDETALLE3 = 'SubArbol' WHERE (PKGES_CCODIGO = '" + (results[0].PKGES_CCODIGO).toString() + "');";
                  console.log(sql);
                  connDB.promise().query(sql)
                      .then(([results, fields]) => {
                          //2 Debe desencadenar nuevo arbol
                          const options =[{title:'Por favor seleccione una opción',rows: [{title:'Ventas' },{title:'Tramites' }] }];
                          const lista= new List('¿a qué área desea comunicarse?','Seleccione una opción',options)
                          clientWP.sendMessage(msg.from,lista ).then(()=>{
                          
                        });

                        //  clientWP.sendMessage(msg.from, mensaje4);
                      })
                      .catch((Error) => ControlErrores(Error));
              }

          } else {
            const options =[{title:'Por favor seleccione una opcion',rows: [{title:'Bogota' },{title:'Cartagena' }] }];
            const lista= new List('_*ATENCION DATOS INCORRECTOS*_\n _recuerda seleccionar,(NO escribir), una ciudad dentro de la lista:_\n ¿En cual ciudad se encuentra interesado para adquirir vivienda?','Seleccione una opción',options)
            clientWP.sendMessage(msg.from,lista ).then(()=>{
            });
              //clientWP.sendMessage(msg.from, mensajeNoEntiende + mensaje3);
          }

        }
        else if (results[0].GES_CDETALLE != null && results[0].GES_CDETALLE1 != null && results[0].GES_CDETALLE2 != null && results[0].GES_CDETALLE3 == "SubArbol" && results[0].GES_CDETALLE7 == null) {
          if (((msg.body).toString() === "Ventas" || (msg.body).toString() === "Tramites")&& msg.type === 'list_response') {
          if ((msg.body).toString() === "Ventas") {
              
          sql = "UPDATE " + DB + ".tbl_cgestion SET  GES_CDETALLE4 = 'Ventas', GES_CDETALLE7 = 'TRANSFERIDO' WHERE (PKGES_CCODIGO = '" + (results[0].PKGES_CCODIGO).toString() + "');";
          console.log(sql);
          connDB.promise().query(sql)
          .then(([results, fields]) => {
          //Consultar la ciudad anteriormente seleccionada por el cliente
          var ArrayDatosClientes = [];
          sql = "SELECT PKGES_CCODIGO, GES_NUMERO_COMUNICA, GES_CDETALLE, GES_CDETALLE1, GES_CDETALLE2 FROM " + DB + ".tbl_cgestion WHERE GES_NUMERO_COMUNICA = '" + (msg.from).toString() + "' AND GES_CDETALLE9 IS NULL AND GES_CESTADO = 'Activo' ORDER BY PKGES_CCODIGO ASC LIMIT 1;";
          console.log(sql);
          connDB.promise().query(sql)
          .then(([resultsCiudad, fields]) => {
         //Enviar los documentos
          Codigo_Gestion = resultsCiudad[0].PKGES_CCODIGO;
          ArrayDatosClientes.push(resultsCiudad[0].GES_CDETALLE, resultsCiudad[0].GES_CDETALLE1);
          var MensajeActual = "";
          var MensajeActualAsesor = "";
          var SiguienteTransferencia = "";
          try {
            clientWP.sendMessage(msg.from, mensaje6);
            envioCartagena(msg.from);
            /*
            for (let index = 0; index < ArrayOpcion2.length; index++) {
                var media = MessageMedia.fromFilePath(ArrayOpcion2[index]);
                clientWP.sendMessage(msg.from, media);
            }*/
           } catch (error) {
            console.error(error);
          }
          if (AgentesOpcion2.length >= 1) {
          //TRAER EL ORDEN JUSTO DE TRANSFERENCIA 
          var FechaActual = GetFechaActual();
          sql = "SELECT FKTRA_NPER_NCODIGO, COUNT(*) AS CANTIDAD FROM " + DB + ".tbl_ctransferencias, " + DB + ".tbl_rpermiso WHERE PKPER_NCODIGO = FKTRA_NPER_NCODIGO AND PER_CAREA = 'CARTAGENA' AND PER_CESTADO = 'Activo' AND PER_CNIVEL = 'Agente' AND TRA_CFECHA_REGISTRO BETWEEN '" + FechaActual.toString() + " 00:00:00' AND '" + FechaActual.toString() + " 23:59:59' AND TRA_CESTADO = 'Activo' GROUP BY FKTRA_NPER_NCODIGO ORDER BY CANTIDAD ASC;";
          console.log(sql);
          connDB.promise().query(sql)
          .then(([results, fields]) => {
          SiguienteTransferencia = results[0].FKTRA_NPER_NCODIGO;
          //Transferir a opcion 2
          for (let index = 0; index < AgentesOpcion2.length; index++) {
        if (parseInt(AgentesOpcion2[index][0], 10) == SiguienteTransferencia) {

            //Transferir a asesor
            let number = AgentesOpcion2[index][2];
            number = number.includes('@c.us') ? number : `${number}@c.us`;
            MensajeActual = mensajeTransferenciaAsesor;
            var re = /NOMBRE_CLIENTE/g;
            MensajeActual = MensajeActual.replace(re, ArrayDatosClientes[0]);
            var re = /NUMERO_CLIENTE/g;
            MensajeActual = MensajeActual.replace(re, msg.from);
            var re = /CORREO_CLIENTE/g;
            MensajeActual = MensajeActual.replace(re, ArrayDatosClientes[1]);
            var re = /@c.us/g;
            MensajeActual = MensajeActual.replace(re, "");
            //Transferir asesor al cliente
            MensajeActualAsesor = mensajeTransferenciaCliente;
            var re = /NUMERO_ASESOR/g;
            MensajeActualAsesor = MensajeActualAsesor.replace(re, AgentesOpcion2[index][2]);
            var re = /NOMBRE_ASESOR/g;
            MensajeActualAsesor = MensajeActualAsesor.replace(re, AgentesOpcion2[index][1]);

            var FechaActualCompleta = GetFechaActual() + " " + getHoraActual();
            sql = "INSERT INTO " + DB + ".tbl_ctransferencias (FKTRA_NPER_NCODIGO, FKTRA_NGES_NCODIGO, TRA_CNUMERO_ASESOR, TRA_CNUMERO_CLIENTE, TRA_MENSAJE_CLIENTE, TRA_MENSAJE_ASESOR, TRA_CFECHA_REGISTRO, TRA_CDETALLE_REGISTRO, TRA_CESTADO) VALUES ('" + (AgentesOpcion2[index][0]).toString() + "', '" + (Codigo_Gestion).toString() + "', '" + (AgentesOpcion2[index][2]).toString() + "', '" + (msg.from).toString().replace("@c.us", "") + "', '" + (MensajeActual).toString() + "', '" + (MensajeActualAsesor).toString() + "', '" + FechaActualCompleta.toString() + "', 'REGISTRO INICIAL DE TRANSFERENCIA', 'Activo');";
            console.log(sql);
            connDB.promise().query(sql)
                .then(([results, fields]) => {
                    clientWP.sendMessage(msg.from, MensajeActualAsesor);
                    clientWP.sendMessage(number, MensajeActual);
                })
                .catch((Error) => ControlErrores(Error));
            break;
        }
    }
    }).catch((Error) => ControlErrores(Error));
    }
    }).catch((Error) => ControlErrores(Error));
          })
          .catch((Error) => ControlErrores(Error));

    } else if ((msg.body).toString() === "Tramites") {
        sql = "UPDATE " + DB + ".tbl_cgestion SET GES_CDETALLE4 = 'Tramites', GES_CDETALLE7 = 'TRANSFERIDO' WHERE (PKGES_CCODIGO = '" + (results[0].PKGES_CCODIGO).toString() + "');";
        console.log(sql);
        connDB.promise().query(sql)
        .then(([results, fields]) => {
        //Consultar la ciudad anteriormente seleccionada por el cliente
        var ArrayDatosClientes = [];
        sql = "SELECT PKGES_CCODIGO, GES_NUMERO_COMUNICA, GES_CDETALLE, GES_CDETALLE1, GES_CDETALLE2 FROM " + DB + ".tbl_cgestion WHERE GES_NUMERO_COMUNICA = '" + (msg.from).toString() + "' AND GES_CDETALLE9 IS NULL AND GES_CESTADO = 'Activo' ORDER BY PKGES_CCODIGO ASC LIMIT 1;";
        console.log(sql);
        connDB.promise().query(sql)
            .then(([resultsCiudad, fields]) => {

        //Enviar los documentos
        Codigo_Gestion = resultsCiudad[0].PKGES_CCODIGO;
        ArrayDatosClientes.push(resultsCiudad[0].GES_CDETALLE, resultsCiudad[0].GES_CDETALLE1);
        var MensajeActual = "";
        var MensajeActualAsesor = "";
        var SiguienteTransferencia = "";

        if (AgentesOpcion3.length >= 1) {
            //TRAER EL ORDEN JUSTO DE TRANSFERENCIA 
        var FechaActual = GetFechaActual();
        sql = "SELECT FKTRA_NPER_NCODIGO, COUNT(*) AS CANTIDAD FROM " + DB + ".tbl_ctransferencias, " + DB + ".tbl_rpermiso WHERE PKPER_NCODIGO = FKTRA_NPER_NCODIGO AND PER_CAREA = 'CARTAGENA-TRAMITES' AND PER_CESTADO = 'Activo' AND PER_CNIVEL = 'Agente' AND TRA_CFECHA_REGISTRO BETWEEN '" + FechaActual.toString() + " 00:00:00' AND '" + FechaActual.toString() + " 23:59:59' AND TRA_CESTADO = 'Activo' GROUP BY FKTRA_NPER_NCODIGO ORDER BY CANTIDAD ASC;";
            console.log(sql);
            connDB.promise().query(sql)
            .then(([results, fields]) => {
            SiguienteTransferencia = results[0].FKTRA_NPER_NCODIGO;

             //Transferir a opcion 2

    for (let index = 0; index < AgentesOpcion3.length; index++) {

        if (parseInt(AgentesOpcion3[index][0], 10) == SiguienteTransferencia) {

            //Transferir a asesor
            let number = AgentesOpcion3[index][2];
            number = number.includes('@c.us') ? number : `${number}@c.us`;
            MensajeActual = mensajeTransferenciaAsesor;
            var re = /NOMBRE_CLIENTE/g;
            MensajeActual = MensajeActual.replace(re, ArrayDatosClientes[0]);
            var re = /NUMERO_CLIENTE/g;
            MensajeActual = MensajeActual.replace(re, msg.from);
            var re = /CORREO_CLIENTE/g;
            MensajeActual = MensajeActual.replace(re, ArrayDatosClientes[1]);
            var re = /ventas/g;
            MensajeActual = MensajeActual.replace(re, "Trámites");
            var re = /@c.us/g;
            MensajeActual = MensajeActual.replace(re, "");

            //Transferir asesor al cliente
            MensajeActualAsesor = mensaje7;
            var re = /NUMERO_ASESOR/g;
            MensajeActualAsesor = MensajeActualAsesor.replace(re, AgentesOpcion3[index][2]);
            var re = /NOMBRE_ASESOR/g;
            MensajeActualAsesor = MensajeActualAsesor.replace(re, AgentesOpcion3[index][1]);

            var FechaActualCompleta = GetFechaActual() + " " + getHoraActual();
            sql = "INSERT INTO " + DB + ".tbl_ctransferencias (FKTRA_NPER_NCODIGO, FKTRA_NGES_NCODIGO, TRA_CNUMERO_ASESOR, TRA_CNUMERO_CLIENTE, TRA_MENSAJE_CLIENTE, TRA_MENSAJE_ASESOR, TRA_CFECHA_REGISTRO, TRA_CDETALLE_REGISTRO, TRA_CESTADO) VALUES ('" + (AgentesOpcion3[index][0]).toString() + "', '" + (Codigo_Gestion).toString() + "', '" + (AgentesOpcion3[index][2]).toString() + "', '" + (msg.from).toString().replace("@c.us", "") + "', '" + (MensajeActual).toString() + "', '" + (MensajeActualAsesor).toString() + "', '" + FechaActualCompleta.toString() + "', 'REGISTRO INICIAL DE TRANSFERENCIA', 'Activo');";
            console.log(sql);
            connDB.promise().query(sql)
                .then(([results, fields]) => {
                    clientWP.sendMessage(number, MensajeActual);
                    clientWP.sendMessage(msg.from, MensajeActualAsesor);
                })
                .catch((Error) => ControlErrores(Error));
            break;
        }
    }
     }).catch((Error) => ControlErrores(Error));
      }
      }).catch((Error) => ControlErrores(Error));
          }).catch((Error) => ControlErrores(Error));
              }
          } else {
              //clientWP.sendMessage(msg.from, mensajeNoEntiende + mensaje4);
              const options =[{title:'Por favor seleccione una opción',rows: [{title:'Ventas' },{title:'Tramites' }] }];
              const lista= new List('_*ATENCION DATOS INCORRECTOS*_\n _recuerda seleccionar,(NO escribir), una opcion dentro de la lista:_\n ¿a qué área desea comunicarse?','Seleccione una opción',options)
              clientWP.sendMessage(msg.from,lista ).then(()=>{
              });


          }

      }
      else if (results[0].GES_CDETALLE != null && results[0].GES_CDETALLE1 != null && results[0].GES_CDETALLE2 != null && results[0].GES_CDETALLE3 != null && results[0].GES_CDETALLE9 == null && results[0].GES_CDETALLE7 != null) {
      //Preguntar si se desea una nueva interaccion, de ser asi la crea.
      if ((msg.body).toString() == "Si" && msg.type === 'list_response') {
      sql = "UPDATE " + DB + ".tbl_cgestion SET GES_CDETALLE9 = 'NUEVA INTERACCION SOLICITADA' WHERE (PKGES_CCODIGO = '" + (results[0].PKGES_CCODIGO).toString() + "');";
      console.log(sql);
      connDB.promise().query(sql)
      .then(([results, fields]) => {
       // Guarda el numero que se comunica y envia el mensaje de bienvenida.
       //consultar los datos dados enteriormente
        sql = "SELECT GES_CDETALLE, GES_CDETALLE1 FROM u632406828_dbp_whatsappbo.tbl_cgestion WHERE GES_NUMERO_COMUNICA = '" + (msg.from).toString() + "' AND GES_CESTADO = 'Activo' ORDER BY PKGES_CCODIGO ASC LIMIT 1;"
        console.log(sql);
        connDB.promise().query(sql)
        .then(([results, fields]) => {
        var NombreCliente = results[0].GES_CDETALLE;
        var CorreoCliente = results[0].GES_CDETALLE1;
        console.log(NombreCliente, CorreoCliente);
        var FechaActualCompleta = GetFechaActual() + " " + getHoraActual();
        sql = "INSERT INTO " + DB + ".tbl_cgestion (GES_NUMERO_COMUNICA, GES_CDETALLE, GES_CDETALLE1, GES_CDETALLE8, GES_CFECHA_REGISTRO, GES_CDETALLE_REGISTRO, GES_CESTADO) VALUES ('" + msg.from + "', '" + NombreCliente + "', '" + CorreoCliente + "', 'ID: " + msg.id + ", ack: " + msg.ack + ", hasMedia: " + msg.hasMedia + ", body: " + msg.body + ", type: " + msg.type + ", timestamp: " + msg.timestamp + ", from: " + msg.from + ", to: " + msg.to + ", isForwarded: " + msg.isForwarded + ", isStatus: " + msg.isStatus + ", isStarred: " + msg.isStarred + ", broadcast: " + msg.broadcast + ", fromMe: " + msg.fromMe + ", hasQuotedMsg: " + msg.hasQuotedMsg +", mentionedIds: " + msg.mentionedIds + ", links: " + msg.links + "', '" + FechaActualCompleta.toString() + "', 'Registro inicial de cliente', 'Activo');";
        console.log(sql);
        connDB.promise().query(sql).then(([results, fields]) => {
        Mensaje1Actual = mensaje3;
        var MomentoDelDia = "";
        var Hora = new Date().getHours();
        if (Hora >= 4 && Hora < 12) {
            MomentoDelDia = "Buenos Dias";
        } else if (Hora >= 12 && Hora < 18) {
            MomentoDelDia = "Buenas Tardes";
        } else if (Hora >= 18 && Hora < 4) {
            MomentoDelDia = "Buenas Noches";
        } else {
            MomentoDelDia = "Buenas Noches"
        };
        var re = /Buen Dia/g;
        Mensaje1Actual = Mensaje1Actual.replace(re, MomentoDelDia);
        //clientWP.sendMessage(msg.from, "Hola buddy");
        const options =[{title:'Por favor seleccione una opcion',rows: [{title:'Bogota' },{title:'Cartagena' }] }];
        const lista= new List('¿En cual ciudad se encuentra interesado para adquirir vivienda?','Seleccione una opción',options)
        clientWP.sendMessage(msg.from,lista ).then(()=>{
                    
                    });


        }).catch((Error) => ControlErrores(Error));
          }).catch((Error) => ControlErrores(Error));
                })
                .catch((Error) => ControlErrores(Error));
        } else if ((msg.body).toString() == "No" && msg.type === 'list_response') {
            clientWP.sendMessage(msg.from, mensajeDespedida);
        } else {
            //clientWP.sendMessage(msg.from, mensajeNuevaInteraccion);
            const options =[{title:'Por favor seleccione una opcion',rows: [{title:'Si' },{title:'No' }] }];
                    const lista= new List('¿Le podemos colaborar en algo más?','Seleccione una opción',options)
                    clientWP.sendMessage(msg.from,lista ).then(()=>{
                    
                    });
        }
    }

        }
        else {        
        console.log("AQUI ENTRE POR DEFECTO AL INICIO DEL ARBOL");
        // Guarda el numero que se comunica y envia el mensaje de bienvenida.
        var FechaActualCompleta = GetFechaActual() + " " + getHoraActual();
        console.log("EL FROM "+msg.from+"EL ID "+ +"EL ACK"+  msg.ack+"EL HASH MEDIA"+  msg.hasMedia+"EL BODY"+  msg.body +"el tipo de mensaje" +msg.type + "el tiem stap"+msg.timestamp +"DE DONDE"+ msg.from +"A QUIEN"+ msg.to+  "SI ES FORWARDED"+ msg.isForwarded +"STATUS"+ msg.isStatus+"STARRED"+  msg.isStarred +"BORDCAST" +msg.broadcast +"FROM ME" +msg.fromMe+"HASHQUOTEDMSG"+  msg.hasQuotedMsg );
        
        //los undefined o vacios no entran  en el insert dentro de los que quedan fuera son
        /** entran :
         * msg.links, msg.mentionedIds, el id trae un objectmm msg.mediaKey , msg.id,msg.author,msg.vCards, msg.location
         * 
         * */ 
        sql = "INSERT INTO " + DB + ".tbl_cgestion (GES_NUMERO_COMUNICA, GES_CDETALLE8, GES_CFECHA_REGISTRO, GES_CDETALLE_REGISTRO, GES_CESTADO) VALUES ('" + msg.from + "','ID: " + msg.id + ", ack: " + msg.ack + ", hasMedia: " + msg.hasMedia + ", body: " + msg.body + ", type: " + msg.type + ", timestamp: " + msg.timestamp + ", from: " + msg.from + ", to: " + msg.to + ", isForwarded: " + msg.isForwarded + ", isStatus: " + msg.isStatus + ", isStarred: " + msg.isStarred + ", broadcast: " + msg.broadcast + ", fromMe: " + msg.fromMe + ", hasQuotedMsg: " + msg.hasQuotedMsg +", mentionedIds: " + msg.mentionedIds + ", links: " + msg.links + "', '" + FechaActualCompleta.toString() + "', 'Registro inicial de cliente', 'Activo');";        console.log(sql);
        connDB.promise().query(sql)
        .then(([results, fields]) => {
          Mensaje1Actual = mensaje1;
          var MomentoDelDia = "";
          var Hora = new Date().getHours();
          if (Hora >= 4 && Hora < 12) {
              MomentoDelDia = "Buenos Dias";
          } else if (Hora >= 12 && Hora < 18) {
              MomentoDelDia = "Buenas Tardes";
          } else if (Hora >= 18 && Hora < 4) {
              MomentoDelDia = "Buenas Noches";
          } else {
              MomentoDelDia = "Buenas Noches"
          };
          var re = /Buen Dia/g;
          Mensaje1Actual = Mensaje1Actual.replace(re, MomentoDelDia);
          clientWP.sendMessage(msg.from, Mensaje1Actual);
        }).catch(console.log)
        
        }
      }).catch((Error) => ControlErrores(Error));


      }catch (error) {
        ControlErrores(error);
        clientWP.sendMessage(msg.from, mensajeNoEntiende);
    }
        }

      }
      else if(msg.type != 'chat'|| msg.type != 'list_response' ) {
      //Responder con el mensaje anterior si mandan un archivo no type chat
     // clientWP.sendMessage(msg.from, "No entiendo lo que dices por favor vuelve a ingresar una opción valida");
       
      sql = "SELECT PKGES_CCODIGO, GES_CDETALLE, GES_CDETALLE1, GES_CDETALLE2, GES_CDETALLE3, GES_CDETALLE4, GES_CDETALLE5, GES_CDETALLE6, GES_CDETALLE7, GES_CDETALLE8, GES_CDETALLE9 FROM " + DB + ".tbl_cgestion WHERE GES_NUMERO_COMUNICA = '" + (msg.from).toString() + "' AND GES_CDETALLE9 IS NULL AND GES_CESTADO = 'Activo' ORDER BY PKGES_CCODIGO ASC LIMIT 1;"
      console.log(sql);
      connDB.promise().query(sql)
    .then(([results, fields]) => {
      if (results.length > 0) {
      if (results[0].GES_CDETALLE == null) {
      Mensaje1Actual = mensaje1;
      var MomentoDelDia = "";
      var Hora = new Date().getHours();
      if (Hora >= 4 && Hora < 12) {
          MomentoDelDia = "Buenos Dias";
      } else if (Hora >= 12 && Hora < 18) {
          MomentoDelDia = "Buenas Tardes";
      } else if (Hora >= 18 && Hora < 4) {
          MomentoDelDia = "Buenas Noches";
      } else {
          MomentoDelDia = "Buenas Noches"
      };
      var re = /Buen Dia/g;
      Mensaje1Actual = Mensaje1Actual.replace(re, MomentoDelDia);
      clientWP.sendMessage(msg.from, mensajeNoEntiende + Mensaje1Actual);
      } else if (results[0].GES_CDETALLE != null && results[0].GES_CDETALLE1 == null) {
          clientWP.sendMessage(msg.from, mensajeNoEntiende + mensaje2);
      } else if (results[0].GES_CDETALLE != null && results[0].GES_CDETALLE1 != null && results[0].GES_CDETALLE2 == null && results[0].GES_CDETALLE3 == null) {
          //clientWP.sendMessage(msg.from, mensajeNoEntiende + mensaje3);
          const options =[{title:'Por favor seleccione una opcion',rows: [{title:'Bogota' },{title:'Cartagena' }] }];
            const lista= new List('_*ATENCION DATOS INCORRECTOS*_\n _recuerda seleccionar,(NO escribir), una ciudad dentro de la lista:_\n ¿En cual ciudad se encuentra interesado para adquirir vivienda?','Seleccione una opción',options)
            clientWP.sendMessage(msg.from,lista ).then(()=>{
            });
      } 
      
      else if (results[0].GES_CDETALLE != null && results[0].GES_CDETALLE1 != null && results[0].GES_CDETALLE2 != null && results[0].GES_CDETALLE3 == "SubArbol" && results[0].GES_CDETALLE7 == null) {
          //clientWP.sendMessage(msg.from, mensajeNoEntiende + mensaje4);
          const options =[{title:'Por favor seleccione una opcion',rows: [{title:'Ventas' },{title:'Tramites' }] }];
            const lista= new List('_*ATENCION DATOS INCORRECTOS*_\n _recuerda seleccionar,(NO escribir), una opción dentro de la lista:_\n ¿A quó área desea comunicarse?','Seleccione una opción',options)
            clientWP.sendMessage(msg.from,lista ).then(()=>{
            });
      } 
      else if (results[0].GES_CDETALLE != null && results[0].GES_CDETALLE1 != null && results[0].GES_CDETALLE2 != null && results[0].GES_CDETALLE3 != null && results[0].GES_CDETALLE9 == null && results[0].GES_CDETALLE7 != null) {
       //  clientWP.sendMessage(msg.from, mensajeNoEntiende + mensajeNuevaInteraccion);
            
          const options =[{title:'Por favor seleccione una opcion',rows: [{title:'Si' },{title:'No' }] }];
            const lista= new List('_*ATENCION DATOS INCORRECTOS*_\n _recuerda seleccionar,(NO escribir), una opción de la lista:_\n ¿Le podemos colaborar en algo más?','Seleccione una opción',options)
            clientWP.sendMessage(msg.from,lista ).then(()=>{
            });
      }
        } else {
      // Guarda el numero que se comunica y envia el mensaje de bienvenida.
      var FechaActualCompleta = GetFechaActual() + " " + getHoraActual();
      sql = "INSERT INTO " + DB + ".tbl_cgestion (GES_NUMERO_COMUNICA, GES_CDETALLE8, GES_CFECHA_REGISTRO, GES_CDETALLE_REGISTRO, GES_CESTADO) VALUES ('" + msg.from + "', 'mediaKey: " + msg.mediaKey + ", ID: " + msg.ack + ", ack: " + msg.ack + ", hasMedia: " + msg.hasMedia + ", body: " + msg.body + ", type: " + msg.type + ", timestamp: " + msg.timestamp + ", from: " + msg.from + ", to: " + msg.to + ", author: " + msg.author + ", isForwarded: " + msg.isForwarded + ", isStatus: " + msg.isStatus + ", isStarred: " + msg.isStarred + ", broadcast: " + msg.broadcast + ", fromMe: " + msg.fromMe + ", hasQuotedMsg: " + msg.hasQuotedMsg + ", location: " + msg.location + ", vCards: " + msg.vCards + ", mentionedIds: " + msg.mentionedIds + ", links: " + msg.links + "', '" + FechaActualCompleta.toString() + "', 'Registro inicial de cliente', 'Activo');";
      console.log(sql);
      connDB.promise().query(sql)
      .then(([results, fields]) => {
      Mensaje1Actual = mensaje1;
      var MomentoDelDia = "";
      var Hora = new Date().getHours();
      if (Hora >= 4 && Hora < 12) {
          MomentoDelDia = "Buenos Dias";
      } else if (Hora >= 12 && Hora < 18) {
          MomentoDelDia = "Buenas Tardes";
      } else if (Hora >= 18 && Hora < 4) {
          MomentoDelDia = "Buenas Noches";
      } else {
        MomentoDelDia = "Buenas Noches"
      };
      var re = /Buen Dia/g;
      Mensaje1Actual = Mensaje1Actual.replace(re, MomentoDelDia);
      clientWP.sendMessage(msg.from, Mensaje1Actual);

                  client.sendMessage(msg.from, mensaje1);
                })
                .catch((Error) => ControlErrores(Error));
        }
    })
    .catch((Error) => ControlErrores(Error));
    
    }



      
    }
  
  }).catch((Error) => ControlErrores(Error));
  
  await sleep(2000);
  console.log("Validar si hay chats resagados");
  try {
    const chatIds = await clientWP.pupPage.evaluate(async() => {
        const chats = await window.WWebJS.getChats();
        return chats.map(chat => chat);
    });
  for (let chats of chatIds) {
    var EstadoMensaje = chats.unreadCount;
      if ((EstadoMensaje == -1 || EstadoMensaje >= 1) && (chats.id._serialized).includes(msg.from) == false) {
            //envia un mensaje a los chat no leido para reavivar la interaccion
            sql = "SELECT PKGES_CCODIGO, GES_CDETALLE, GES_CDETALLE1, GES_CDETALLE2, GES_CDETALLE3, GES_CDETALLE4, GES_CDETALLE5, GES_CDETALLE6, GES_CDETALLE7, GES_CDETALLE8, GES_CDETALLE9 FROM " + DB + ".tbl_cgestion WHERE GES_NUMERO_COMUNICA = '" + (chats.id._serialized).toString() + "' AND GES_CDETALLE9 IS NULL AND GES_CESTADO = 'Activo' ORDER BY PKGES_CCODIGO ASC LIMIT 1;"
            console.log(sql);
            connDB.promise().query(sql)
            .then(([results, fields]) => {
            if (results.length > 0) {
            if (results[0].GES_CDETALLE == null) {
            Mensaje1Actual = mensaje1;
            var MomentoDelDia = "";
            var Hora = new Date().getHours();
            if (Hora >= 4 && Hora < 12) {
                MomentoDelDia = "Buenos Dias";
            } else if (Hora >= 12 && Hora < 18) {
                MomentoDelDia = "Buenas Tardes";
            } else if (Hora >= 18 && Hora < 4) {
                MomentoDelDia = "Buenas Noches";
            } else {
                MomentoDelDia = "Buenas Noches"
            };
            var re = /Buen Dia/g;
            Mensaje1Actual = Mensaje1Actual.replace(re, MomentoDelDia);
            clientWP.sendMessage(chats.id._serialized, mensajeNoEntiende + Mensaje1Actual);
            } else if (results[0].GES_CDETALLE != null && results[0].GES_CDETALLE1 == null) {
            clientWP.sendMessage(chats.id._serialized, mensajeNoEntiende + mensaje2);
            } else if (results[0].GES_CDETALLE != null && results[0].GES_CDETALLE1 != null && results[0].GES_CDETALLE2 == null && results[0].GES_CDETALLE3 == null) {
            //clientWP.sendMessage(chats.id._serialized, mensajeNoEntiende + mensaje3);
            const options =[{title:'Por favor seleccione una opcion',rows: [{title:'Bogota' },{title:'Cartagena' }] }];
            const lista= new List('_*ATENCION DATOS INCORRECTOS*_\n _recuerda seleccionar,(NO escribir), una ciudad dentro de la lista:_\n ¿En cual ciudad se encuentra interesado para adquirir vivienda?','Seleccione una opción',options)
            clientWP.sendMessage(msg.from,lista ).then(()=>{
            });
            } else if (results[0].GES_CDETALLE != null && results[0].GES_CDETALLE1 != null && results[0].GES_CDETALLE2 != null && results[0].GES_CDETALLE3 == "SubArbol" && results[0].GES_CDETALLE7 == null) {
            //clientWP.sendMessage(chats.id._serialized, mensajeNoEntiende + mensaje4);
            const options =[{title:'Por favor seleccione una opcion',rows: [{title:'Ventas' },{title:'Tramites' }] }];
            const lista= new List('_*ATENCION DATOS INCORRECTOS*_\n _recuerda seleccionar,(NO escribir), una opción dentro de la lista:_\n ¿A quó área desea comunicarse?','Seleccione una opción',options)
            clientWP.sendMessage(msg.from,lista ).then(()=>{
            });
            } 
            /*
            else if (results[0].GES_CDETALLE != null && results[0].GES_CDETALLE1 != null && results[0].GES_CDETALLE2 != null && results[0].GES_CDETALLE3 != null && results[0].GES_CDETALLE9 == null && results[0].GES_CDETALLE7 != null) {
            clientWP.sendMessage(chats.id._serialized, mensajeNoEntiende + mensajeNuevaInteraccion);
            }*/

              } else {
              // Guarda el numero que se comunica y envia el mensaje de bienvenida.
              var FechaActualCompleta = GetFechaActual() + " " + getHoraActual();
              sql = "INSERT INTO " + DB + ".tbl_cgestion (GES_NUMERO_COMUNICA, GES_CDETALLE8, GES_CFECHA_REGISTRO, GES_CDETALLE_REGISTRO, GES_CESTADO) VALUES ('" + chats.id._serialized + "', 'Mensaje Resagado', '" + FechaActualCompleta.toString() + "', 'Registro inicial de cliente', 'Activo');";
              console.log(sql);
              connDB.promise().query(sql)
              .then(([results, fields]) => {

                  Mensaje1Actual = mensaje1;
                  var MomentoDelDia = "";
                  var Hora = new Date().getHours();
                  if (Hora >= 4 && Hora < 12) {
                      MomentoDelDia = "Buenos Dias";
                  } else if (Hora >= 12 && Hora < 18) {
                      MomentoDelDia = "Buenas Tardes";
                  } else if (Hora >= 18 && Hora < 4) {
                      MomentoDelDia = "Buenas Noches";
                  } else {
                      MomentoDelDia = "Buenas Noches"
                  };
                  var re = /Buen Dia/g;
                  Mensaje1Actual = Mensaje1Actual.replace(re, MomentoDelDia);
                  clientWP.sendMessage(chats.id._serialized, Mensaje1Actual);

              })
              .catch((Error) => ControlErrores(Error));
              }
                        })
                          .catch((Error) => ControlErrores(Error));
                    }
                  }
              } catch (error) {
                ControlErrores(error);
                ContadorExceptGetChat = ContadorExceptGetChat + 1
                if (ContadorExceptGetChat > 10) {
                    try {
                        connDB.end();
                        await sleep(2000);
                        process.exit(1);
                    } catch (error) {
                        ControlErrores(error);
                        process.exit(1);
                    }
              }
              }





});

//Funcion de espera
function sleep(ms) {
return new Promise(resolve => setTimeout(resolve, ms));
}


function GetFechaActual() {
  Mes = new Date().getMonth() + 1;
  if (Mes >= 1 && Mes < 10) {
      Mes = "0" + Mes.toString();
  }
  Dia = new Date().getDate();
  if (Dia >= 1 && Dia < 10) {
      Dia = "0" + Dia.toString();
  }
  var FechaActual = new Date().getFullYear() + "-" + Mes + "-" + Dia;
  return FechaActual;
}

function getHoraActual() {
  const HOY = new Date();
  const HORA = HOY.getHours();
  let MIN = HOY.getMinutes();
  MIN = MIN.toString().length === 1 ? `0${MIN}` : MIN;

  return `${HORA}:${MIN}`;
}


function getRutaChrome() {
  if (os.platform == 'linux') {
    return RUTA_CHROME_UBUNTU;
  } else {
    return RUTA_CHROME_WINDOWS;
  }
}

//SI HAY CAMBIO EN EL ESTADO PROBAR SI ESTA DEPRECATED O AUN FUNCIONA
clientWP.on('change_state', Estado => {
  if (Estado == "TIMEOUT") {
      Estado = "TELEFONO SIN CONEXION";
  }
  ControlEstadoSesion('Estado sesion', Estado);
  console.log(Estado);
});

// * ===============================================
// * ====== [ EVENTOS  Y FUNCIONES DE INCIALIZACIÓN]
// * ===============================================


function dumpError(err) {
  if (typeof err === 'object') {
      if (err.message) {
          return ' Message: ' + err.message;
      }
      if (err.stack) {
          return err.stack;
      }
  } else {
      return 'dumpError :: El arcumento no es de tipo Objeto.';
  }
}

function ControlErrores(Error) {

  var FechaActual = GetFechaActual();
  var HoraActual = getHoraActual();

  if (!fs.existsSync("logs")) {
      fs.mkdirSync("logs");
  }
  var logger = fs.createWriteStream(`./logs/log_${FechaActual}.txt`, {
      flags: 'a'
  })
  var DetalleError = dumpError(Error);
  logger.write(`${Error} ${DetalleError} ${FechaActual} - ${HoraActual}\n`)

}




async function ActualizarParametros() {

  contadorEliminar = 1;
  const chats = await clientWP.getChats()
  Promise.all(chats.map(chatAll => Eliminar_Chat(chatAll)));

  sql = "SELECT PKPER_NCODIGO FROM " + DB + ".tbl_rpermiso WHERE PER_CNIVEL = 'Agente' AND PER_CESTADO = 'Activo' ORDER BY PKPER_NCODIGO;";
  console.log(sql);
  connDB.query(sql, function(error, results, fields) {
      if (error) throw error;
      for (let index = 0; index < results.length; index++) {
          var FechaActual = GetFechaActual();
          sql = "INSERT INTO " + DB + ".tbl_ctransferencias (FKTRA_NPER_NCODIGO, TRA_CNUMERO_ASESOR, TRA_CFECHA_REGISTRO, TRA_CESTADO) VALUES ('" + (results[index].PKPER_NCODIGO).toString() + "', 'INICIO DIA', '" + FechaActual.toString() + " 12:00:00', 'Activo');";
          console.log(sql);
          connDB.query(sql, function(err, result) {
              if (err) throw err;
          });

      }
  });

  //Descargar Tiempo Espera
  var TiempoEspera = 0;

  sql = "SELECT EST_CDETALLE, COUNT(*) AS CANTIDAD_RESULTADOS FROM " + DB + ".tbl_restandar WHERE EST_CCONSULTA = 'ControlTiempoEspera' AND EST_CESTADO = 'Activo' ORDER BY PKEST_NCODIGO ASC LIMIT 1;";
  console.log(sql);
  connDB.query(sql, function(error, results, fields) {
      if (error) throw error;
      if (results[0].CANTIDAD_RESULTADOS > 0) {
          TiempoEspera = parseInt(results[0].EST_CDETALLE, 10);
      }
  });

  //Actualiza los mensajes de interaccion
  ConsultarParametrosIniciales()

  console.log("Verificando mensajes por enviar masivo para borrar carpetas");
  sql = "SELECT PKENV_NCODIGO, ENV_CNUMERO_DESTINO, ENV_CKEY_TIPO, ENV_CMENSAJE, ENV_CNOMBREMASIVO, ENV_CADJUNTO, ENV_CKEY_TRANSFERENCIA, ENV_CTRANSFERENCIA FROM " + DB + ".tbl_enviar_mensaje WHERE ENV_CESTADO_ENVIO = 'NO ENVIADO' AND ENV_CESTADO_RESPUESTA IS NULL AND ENV_CESTADO = 'Activo' ORDER BY PKENV_NCODIGO ASC;"
  console.log(sql);
  connDB.query(sql, async function(error, results, fields) {
      if (error) throw error;
      if (results.length > 0) {
          //
      } else {
          //Eliminar carpeta FTP
          fs2.rmdir('./FTP', { recursive: true })
              .then(() => {
                  console.log('Carpeta "FTP" Eliminado')
              })
              .catch(err => {
                  console.error('No se pudo eliminar la carpeta FTP', err)
              })
          fs2.rmdir('./FTP_Agente', { recursive: true })
              .then(() => {
                  console.log('Carpeta "FTP_Agente" Eliminado')
              })
              .catch(err => {
                  console.error('No se pudo eliminar la carpeta FTP_Agente', err)
              })
      }
  });


}


async function eliminarExesoChats() {

  Correcto = true
  while (Correcto == true) {
      clientWP.getChats()
          .then(Chats => {
              //Eliminar el exeso de chats
              if (Chats.length > 10) {
                  for (let index = 10; index < Chats.length; index++) {
                      if (Chats[index].unreadCount <= 0) {
                          Chats[index].delete();
                      }
                  }
              }
          });
      await sleep(60000);
  }

}




function ParcelarTexto(Texto) {
    Texto = Texto.toString();
    Texto = Texto.toUpperCase();
    Texto = Texto.replace("Á", "A");
    Texto = Texto.replace("É", "E");
    Texto = Texto.replace("Í", "I");
    Texto = Texto.replace("Ó", "O");
    Texto = Texto.replace("Ú", "U");
    if (Texto.includes("BOGOTA") || Texto.includes("1")) {
        return 1;
    } else if (Texto.includes("CARTAGENA") || Texto.includes("2")) {
        return 2;
    } else if (Texto.includes("VENTAS") || Texto.includes("1")) {
        return 1;
    } else if (Texto.includes("TRAMITES") || Texto.includes("2")) {
        return 2;
    } else {
        return 0;
    }
}



//Elimina los chats antiguos
function Eliminar_Chat(chatAll) {

  try {
      if (contadorEliminar > 5) {
          chatAll.delete();
      } else {
          contadorEliminar = contadorEliminar + 1;
      };
  } catch (error) {
      //
  }


};


//Consultar los mensajes de interaccion
function ConsultarParametrosIniciales() {

  //Extraer Mensajes
  sql = "SELECT EST_CDETALLE, EST_CDETALLE1 FROM " + DB + ".tbl_restandar WHERE EST_CCONSULTA = 'ControlMensajesInteraccion' AND EST_CESTADO = 'Activo' ORDER BY EST_CESTADO ASC;";
  console.log(sql);

  connDB.promise().query(sql)
      .then(([resultsMensajes, fields]) => {
          for (let index = 0; index < resultsMensajes.length; index++) {

              if (resultsMensajes[index].EST_CDETALLE == 1) {
                  mensaje1 = resultsMensajes[index].EST_CDETALLE1;
              } else if (resultsMensajes[index].EST_CDETALLE == 2) {
                  mensaje2 = resultsMensajes[index].EST_CDETALLE1;
              } else if (resultsMensajes[index].EST_CDETALLE == 3) {
                  mensaje3 = resultsMensajes[index].EST_CDETALLE1;
              } else if (resultsMensajes[index].EST_CDETALLE == 4) {
                  mensaje4 = resultsMensajes[index].EST_CDETALLE1;
              } else if (resultsMensajes[index].EST_CDETALLE == 5) {
                  mensaje5 = resultsMensajes[index].EST_CDETALLE1;
              } else if (resultsMensajes[index].EST_CDETALLE == 6) {
                  mensaje6 = resultsMensajes[index].EST_CDETALLE1;
              } else if (resultsMensajes[index].EST_CDETALLE == 7) {
                  mensaje7 = resultsMensajes[index].EST_CDETALLE1;
              } else if (resultsMensajes[index].EST_CDETALLE == "Despedida") {
                  mensajeDespedida = resultsMensajes[index].EST_CDETALLE1;
              } else if (resultsMensajes[index].EST_CDETALLE == "NoEntiende") {
                  mensajeNoEntiende = resultsMensajes[index].EST_CDETALLE1;
              } else if (resultsMensajes[index].EST_CDETALLE == "NuevaInteraccion") {
                  mensajeNuevaInteraccion = resultsMensajes[index].EST_CDETALLE1;
              } else if (resultsMensajes[index].EST_CDETALLE == "TransferenciaCliente") {
                  mensajeTransferenciaCliente = resultsMensajes[index].EST_CDETALLE1;
              } else if (resultsMensajes[index].EST_CDETALLE == "TransferenciaAsesor") {
                  mensajeTransferenciaAsesor = resultsMensajes[index].EST_CDETALLE1;
              }
          }
      })
      .catch((Error) => ControlErrores(Error));

/*
  //Extraer Adjuntos
  sql = "SELECT EST_CDETALLE, EST_CDETALLE1 FROM " + DB + ".tbl_restandar WHERE EST_CCONSULTA = 'ControlRutaAdjunto' AND EST_CESTADO = 'Activo' ORDER BY PKEST_NCODIGO ASC;";
  console.log(sql);
  connDB.promise().query(sql)
      .then(([resultsRutas, fields]) => {
          for (let index = 0; index < resultsRutas.length; index++) {

              if (resultsRutas[index].EST_CDETALLE == 1) {
                  ArrayOpcion1.push(resultsRutas[index].EST_CDETALLE1);
              } else if (resultsRutas[index].EST_CDETALLE == 2) {
                  ArrayOpcion2.push(resultsRutas[index].EST_CDETALLE1);
              }
          }

          ArrayOpcion1 = ArrayOpcion1.filter((item, index) => {
              return ArrayOpcion1.indexOf(item) === index;
          })

          ArrayOpcion2 = ArrayOpcion2.filter((item, index) => {
              return ArrayOpcion2.indexOf(item) === index;
          })
          console.log(ArrayOpcion1)
          console.log(ArrayOpcion2)

      })
      .catch((Error) => ControlErrores(Error));

*/


  //Extraer agentes
  sql = 'SELECT PKPER_NCODIGO, PER_CAREA, CONCAT(CRE_CNOMBRE, " ", CRE_CNOMBRE2, " ", CRE_CAPELLIDO, " ", CRE_CAPELLIDO2) AS NOMBRE_COMPLETO, PER_CNUMERO_WHATSAPP FROM ' + DB+ '.tbl_rcredencial, ' + DB + '.tbl_rpermiso WHERE FKPER_NCRE_NCODIGO = PKCRE_NCODIGO AND PER_CCLIENTE = "INGENAL" AND PER_CCAMPANA = "INGENAL" AND PER_CNIVEL = "Agente" AND CRE_CESTADO = "Activo" AND PER_CESTADO = "Activo" ORDER BY PKPER_NCODIGO ASC;';
  console.log(sql);
  connDB.promise().query(sql)
      .then(([results, fields]) => {
        console.log("ANTES EL CONNDB");
          for (let index = 0; index < results.length; index++) {
          console.log("Despues del for");
              if (results[index].PER_CAREA == "BOGOTA") {
                console.log("en bogota");
                  AgentesOpcion1.push([results[index].PKPER_NCODIGO, results[index].NOMBRE_COMPLETO, results[index].PER_CNUMERO_WHATSAPP]);
              } else if (results[index].PER_CAREA == "CARTAGENA") {
                console.log("en cartagena");
                  AgentesOpcion2.push([results[index].PKPER_NCODIGO, results[index].NOMBRE_COMPLETO, results[index].PER_CNUMERO_WHATSAPP]);
              } else if (results[index].PER_CAREA == "CARTAGENA-TRAMITES") {
                console.log("Cartagena tramites");
                  AgentesOpcion3.push([results[index].PKPER_NCODIGO, results[index].NOMBRE_COMPLETO, results[index].PER_CNUMERO_WHATSAPP]);
              }

          }

          AgentesOpcion1 = AgentesOpcion1.unicos()
          AgentesOpcion2 = AgentesOpcion2.unicos()
          AgentesOpcion3 = AgentesOpcion3.unicos()

          console.log("BOGOTA", AgentesOpcion1);
          console.log("CARTAGENA", AgentesOpcion2);
          console.log("CARTAGENA-TRAMITES", AgentesOpcion3);

      })
      .catch((Error) => ControlErrores(Error));

}





//Valida si es un nuevo dia en la ejecucion y actualiza los asesores disponibles para transferencia
//Elimina los archivos antiguos de los envios masivos
async function ValidarDiaNuevo() {

  try {

      var FechaActual = GetFechaActual();
      console.log("Validando Dia Nuevo", FechaActual);
      sql = "SELECT FKTRA_NPER_NCODIGO, COUNT(*) AS CANTIDAD FROM " + DB+ ".tbl_ctransferencias, " + DB + ".tbl_rpermiso WHERE PKPER_NCODIGO = FKTRA_NPER_NCODIGO AND TRA_CFECHA_REGISTRO BETWEEN '" + FechaActual.toString() + " 00:00:00' AND '" + FechaActual.toString() + " 23:59:59' AND TRA_CESTADO = 'Activo' GROUP BY FKTRA_NPER_NCODIGO ORDER BY CANTIDAD ASC;";
      console.log(sql);
      connDB.promise().query(sql)
          .then(([results, fields]) => {
              if (results.length == 0) {
                  ActualizarParametros();
                  /*await sleep(3000)
                  connection2.end();
                  await sleep(2000)
                  process.exit(1);*/
              };
          })
          .catch((Error) => ControlErrores(Error));
  } catch (Error) {
      ControlErrores(Error)
  };

  try {

      const chatIds = await clientWP.pupPage.evaluate(async() => {
          const chats = await window.WWebJS.getChats();
          return chats.map(c => c.id._serialized);
      });

      let chatCount = 0;
      for (let chatId of chatIds) {
          try {
              const chat = await clientWP.getChatById(chatId);
              if (!chat) {
                  console.log(`Could not serialize chat ${chatId}`);
              } else {
                  chatCount++;
              }
          } catch (e) {
              console.log(`Could not serialize chat ${chatId}`, e);
          }
      }
      console.log(`Validando cantidad de chats: ${chatCount}.`);

      if (chatCount > 10) {
          const chats = await clientWP.getChats()
          contadorEliminar = 1;
          Promise.all(chats.map(chatAll => Eliminar_Chat(chatAll)));
      }

  } catch (Error) {
      try {
          ControlErrores(Error)
          await sleep(3000)
          connDB.end();
          await sleep(2000)
          process.exit(1);
      } catch (error) {
          await sleep(2000)
          process.exit(1);
      }

  }

}



//Obtiene la fecha actual
function GetFechaActual() {
  Mes = new Date().getMonth() + 1;
  if (Mes >= 1 && Mes < 10) {
      Mes = "0" + Mes.toString();
  }
  Dia = new Date().getDate();
  if (Dia >= 1 && Dia < 10) {
      Dia = "0" + Dia.toString();
  }
  var FechaActual = new Date().getFullYear() + "-" + Mes + "-" + Dia;
  return FechaActual;
}



//Reporta a la base de datos el ultimo estado disponible de la sesion con el celular y WhatsappWeb
function ControlEstadoSesion(Estado, Razon) {
  sql = "SELECT PKEST_NCODIGO, COUNT(*) AS CANTIDAD_RESULTADO FROM " + DB + ".tbl_restandar WHERE EST_CCONSULTA = 'ControlEstadoSesion' AND EST_CDETALLE = '" + (NombreProyecto).toString() + "' AND EST_CESTADO = 'Activo' ORDER BY PKEST_NCODIGO ASC LIMIT 1;";
  console.log(sql);
  connDB.promise().query(sql)
      .then(([results, fields]) => {
          if (results.length > 0) {
              sql = "UPDATE " + DB+ ".tbl_restandar SET EST_CDETALLE1 = '" + (Estado).toString() + "', EST_CDETALLE2 = '" + (Razon).toString() + "' WHERE (PKEST_NCODIGO = '" + (results[0].PKEST_NCODIGO).toString() + "');";
              console.log(sql);
              connDB.promise().query(sql)
                  .then(([results, fields]) => {})
                  .catch((Error) => ControlErrores(Error));
          } else {
              sql = "INSERT INTO " + DB + ".tbl_restandar (EST_CCONSULTA, EST_CDETALLE, EST_CDETALLE1, EST_CDETALLE2, EST_CDETALLE_REGISTRO, EST_CESTADO) VALUES ('ControlEstadoSesion', '" + (NombreProyecto).toString() + "', '" + (Estado).toString() + "', '" + (Razon).toString() + "', 'Registro por el sistema', 'Activo');";
              console.log(sql);
              connDB.promise().query(sql)
                  .then(([results, fields]) => {})
                  .catch((Error) => ControlErrores(Error));
          };
      })
      .catch((Error) => ControlErrores(Error));
}
//valida si la linea tiene permiso para enviar comandos especiales, retorna true si esta autorizado
function validarLineasAutorizadad(numberRemote){
  for (let index = 0; index < LineasAutorizadas.length; index++) {

    if ((numberRemote).includes(LineasAutorizadas[index])) {
      return true;
    }

  }
return false;



}


//Elimina el chat especifico.
function EliminarChatComando(chatAll, NumeroEjecutor) {
  try {
      if (chatAll.id._serialized == NumeroEjecutor) {
          chatAll.delete();
      };
  } catch (error) {
      //
  }
}

//Cierra el proceso a partir de su ejecucion
async function ReiniciarTrabajo(NumeroEjecutor) {
//**Por qué cierra la conexión? */
  try {
      await sleep(5000);
      const chats = await clientWP.getChats()
      Promise.all(chats.map(chatAll => EliminarChatComando(chatAll, NumeroEjecutor)));
      connDB.end();
      await sleep(5000);
      process.exit(1);
  } catch (Error) {
      ControlErrores(Error);
      connDB.end();
      await sleep(2000);
      process.exit(1);
  }
}


//Funcion encargada del envio masivo de mensajes Texto/Multimedia
//Por ser Async y de ejecucion perpetua en ella se hacen las llamadas de las funciones de validacion del sistema

//Funcion encargada del envio masivo de mensajes Texto/Multimedia
//Por ser Async y de ejecucion perpetua en ella se hacen las llamadas de las funciones de validacion del sistema
async function EnviarSpam() {

    //Tiempo Espera y recordatorios
    var TiempoEspera = 0;
    var MensajeRecordatorio = "";
    var TiempoRecordatorio = "";

    //Descargar Tiempo Espera
    sql = "SELECT EST_CDETALLE FROM " + DB + ".tbl_restandar WHERE EST_CCONSULTA = 'ControlTiempoEspera' AND EST_CESTADO = 'Activo' ORDER BY PKEST_NCODIGO ASC LIMIT 1;";
    console.log(sql);
    connDB.promise().query(sql)
        .then(([results, fields]) => {
            if (results.length > 0) {
                TiempoEspera = parseInt(results[0].EST_CDETALLE, 10);
            }

        })
        .catch((Error) => ControlErrores(Error));


    //Descargar Mensaje Recordatorio
    sql = "SELECT EST_CDETALLE, EST_CDETALLE1 FROM " + DB + ".tbl_restandar WHERE EST_CCONSULTA = 'ControlMensajesInteraccion' AND EST_CESTADO = 'Activo' ORDER BY EST_CESTADO ASC;";
    connDB.promise().query(sql)
        .then(([results, fields]) => {
            for (let index = 0; index < results.length; index++) {
                if (results[index].EST_CDETALLE == "MensajeRecordatorio") {
                    MensajeRecordatorio = results[index].EST_CDETALLE1;
                }
            }
        })
        .catch((Error) => ControlErrores(Error));


    //Descargar Tiempo Recordatorio
    sql = "SELECT EST_CDETALLE FROM " + DB + ".tbl_restandar WHERE EST_CCONSULTA = 'ControlTiempoMensajeRecordatorio' AND EST_CESTADO = 'Activo' ORDER BY PKEST_NCODIGO ASC LIMIT 1;";
    connDB.promise().query(sql)
        .then(([results, fields]) => {
            if (results.length > 0) {
                TiempoRecordatorio = results[0].EST_CDETALLE;
            }
        })
        .catch((Error) => ControlErrores(Error));


    //esperar para que el async no se vuelva loco
    await sleep(10000);

    n = false;
    while (n == false) {

        console.log("Verificando mensajes por enviar masivo");
        sql = "SELECT PKENV_NCODIGO, ENV_CNUMERO_DESTINO, ENV_CKEY_TIPO, ENV_CMENSAJE, ENV_CNOMBREMASIVO, ENV_CADJUNTO, ENV_CKEY_TRANSFERENCIA, ENV_CTRANSFERENCIA FROM " + DB + ".tbl_enviar_mensaje WHERE ENV_CESTADO_ENVIO = 'NO ENVIADO' AND ENV_CESTADO_RESPUESTA IS NULL AND ENV_CESTADO = 'Activo' ORDER BY PKENV_NCODIGO ASC;"
        console.log(sql);
        connDB.query(sql, async function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                console.log("!Envio de mensaje encontrado¡");
                let number = results[0].ENV_CNUMERO_DESTINO;
                number = number.includes('@c.us') ? number : `${number}@c.us`;
                TIPO_MENSAJE = (results[0].ENV_CKEY_TIPO).toString();
                var Comprobar = "FALSE";
                //Envia el archivo adjunto
                if (TIPO_MENSAJE === "MEDIATEXT" || TIPO_MENSAJE === "MULTIMEDIA") {
                    RUTA_FTP = results[0].ENV_CNOMBREMASIVO;
                    ADJUNTO_FTP = (results[0].ENV_CADJUNTO).toString().split("|");
                    for (let index = 0; index < ADJUNTO_FTP.length; index++) {
                        RUTA_ADJUNTO_COMPLETA = RUTA_FTP + "/" + ADJUNTO_FTP[index];

                        if (fs.existsSync("FTP/" + RUTA_ADJUNTO_COMPLETA)) {
                            TamanoActualFile = getFilesizeInBytes("FTP/" + RUTA_ADJUNTO_COMPLETA)

                            const clientFTP = new ftp.Client()
                            clientFTP.ftp.verbose = true
                            try {

                                await clientFTP.access({

                                    host: "185.201.10.66",
                                    port: "21",
                                    user: "u632406828.bot_whatsapp2",
                                    password: "Temporal$1",
                                    secure: true,
                                    //Para certificados SSL
                                    secureOptions: { rejectUnauthorized: false }

                                    /*host: "172.70.7.23",
                                    port: "24",
                                    user: "FTPWhatsAPP",
                                    password: "Temporal$1",
                                    secure: true,
                                    //Para certificados SSL
                                    secureOptions: { rejectUnauthorized: false }*/

                                })
                                TamanoFile1 = await clientFTP.size(RUTA_ADJUNTO_COMPLETA)
                                console.log(TamanoActualFile, TamanoFile1)

                            } catch (err) {
                                console.log(err)
                            }
                            clientFTP.close()

                            if (parseInt(TamanoActualFile, 10) >= parseInt(TamanoFile1, 10)) {
                                console.log("EL ARCHIVO YA EXISTE LOCALMENTE");
                                Comprobar = "OK";
                                let info = client.info;
                                NumeroOrigen = info.me.user;
                                sql = "UPDATE " + DB + ".tbl_enviar_mensaje SET ENV_CNUMERO_ORIGEN = '" + (NumeroOrigen).toString() + "', ENV_CESTADO_ENVIO = 'ENVIADO' WHERE (PKENV_NCODIGO = '" + (results[0].PKENV_NCODIGO).toString() + "');";
                                console.log(sql);
                                connDB.query(sql, async function(err, result) {
                                    if (err) throw err;
                                    await sleep(TiempoEspera);
                                });
                            }

                        } else {
                            if (!fs.existsSync("FTP")) {
                                fs.mkdirSync("FTP");
                            }
                            if (!fs.existsSync("FTP/" + RUTA_FTP)) {
                                fs.mkdirSync("FTP/" + RUTA_FTP);
                            }
                            //await DescargaFTP(RutaEjecutablePrograma + "/FTP/" + RUTA_ADJUNTO_COMPLETA, RUTA_ADJUNTO_COMPLETA)

                            const clientFTP = new ftp.Client()
                            clientFTP.ftp.verbose = true
                            try {

                                await clientFTP.access({

                                        host: "185.201.10.66",
                                        port: "21",
                                        user: "u632406828.bot_whatsapp2",
                                        password: "Temporal$1",
                                        secure: true,
                                        //Para certificados SSL
                                        secureOptions: { rejectUnauthorized: false }

                                        /*host: "172.70.7.23",
                                        port: "24",
                                        user: "FTPWhatsAPP",
                                        password: "Temporal$1",
                                        secure: true,
                                        //Para certificados SSL
                                        secureOptions: { rejectUnauthorized: false }*/

                                    })
                                    //console.log(await client.list());
                                    //await client.uploadFrom("Prueba.txt", "20210519190134/Prueba.txt");
                                TamanoFile = await clientFTP.size(RUTA_ADJUNTO_COMPLETA)
                                console.log("Tamano del archivo a descargar  = ", TamanoFile)
                                TransfCompleta = "Transferencia sin terminar";
                                clientFTP.trackProgress(async info => {
                                    if ((info.bytesOverall).toString() == TamanoFile.toString()) {
                                        TransfCompleta = "Transferencia completa";
                                        TamanoActualFile = getFilesizeInBytes("FTP/" + RUTA_ADJUNTO_COMPLETA)
                                        if (parseInt(TamanoActualFile, 10) >= parseInt(TamanoFile, 10)) {
                                            Comprobar = "OK2";
                                        }
                                    }
                                });
                                await clientFTP.downloadTo(RutaEjecutablePrograma + "/FTP/" + RUTA_ADJUNTO_COMPLETA, RUTA_ADJUNTO_COMPLETA);

                                console.log(TransfCompleta)

                            } catch (err) {
                                console.log(err)
                            }
                            clientFTP.trackProgress();
                            clientFTP.close()



                        }

                        //ENVIAR ADJUNTO
                        if (Comprobar === "OK") {
                            try {
                                var media = MessageMedia.fromFilePath(RutaEjecutablePrograma + "/FTP/" + RUTA_ADJUNTO_COMPLETA);
                                await client.sendMessage(number, media);
                                let info = client.info;
                                NumeroOrigen = info.me.user;
                                sql = "UPDATE " + BaseDatosServidor.toString() + ".tbl_enviar_mensaje SET ENV_CNUMERO_ORIGEN = '" + (NumeroOrigen).toString() + "', ENV_CESTADO_ENVIO = 'ENVIADO' WHERE (PKENV_NCODIGO = '" + (results[0].PKENV_NCODIGO).toString() + "');";
                                console.log(sql);
                                connDB.query(sql, async function(err, result) {
                                    if (err) throw err;
                                    await sleep(TiempoEspera);
                                });
                            } catch (error) {
                                //
                            }
                        }


                    }

                }

                //Envia el mensaje de texto
                if (TIPO_MENSAJE === "TEXTO") {
                    MENSAJE = results[0].ENV_CMENSAJE;
                    await clientWP.sendMessage(number, MENSAJE);
                    Comprobar = "OK";
                };

                if (Comprobar === "OK") {
                    //Envia el mensaje de texto
                    if (TIPO_MENSAJE === "MEDIATEXT") {
                        MENSAJE = results[0].ENV_CMENSAJE;
                        await clientWP.sendMessage(number, MENSAJE);
                    };
                    let info = clientWP.info;
                    NumeroOrigen = info.me.user;
                    sql = "UPDATE " +DB + ".tbl_enviar_mensaje SET ENV_CNUMERO_ORIGEN = '" + (NumeroOrigen).toString() + "', ENV_CESTADO_ENVIO = 'ENVIADO' WHERE (PKENV_NCODIGO = '" + (results[0].PKENV_NCODIGO).toString() + "');";
                    console.log(sql);
                    connDB.query(sql, async function(err, result) {
                        if (err) throw err;
                        await sleep(TiempoEspera);
                    });
                };

            } else {
                //Eliminar carpeta FTP
                /*fs2.rmdir('./FTP', { recursive: true })
                     .then(() => {
                         console.log('Carpeta "FTP" Eliminado')
                     })
                     .catch(err => {
                         console.error('No se pudo eliminar la carpeta FTP', err)
                     })*/
            };
        });

        connDB.query("COMMIT");

        await sleep(TiempoEspera);
        ControlBotActivo();
        ValidarDiaNuevo();

        console.log("Verificando chats sin respuesta por mas de 30 minutos")
        RecordarConversacion(MensajeRecordatorio, TiempoRecordatorio);

    }

}



//Envia un Ping al servidor cada X tiempo para indicar si está en ejecucion
function ControlBotActivo() {
    sql = "SELECT PKEST_NCODIGO FROM " + DB + ".tbl_restandar WHERE EST_CCONSULTA = 'ControlBotActivo' AND EST_CDETALLE = '" + (NombreProyecto).toString() + "' AND EST_CESTADO = 'Activo' ORDER BY PKEST_NCODIGO ASC LIMIT 1;";
    console.log(sql);
    connDB.promise().query(sql)
        .then(([results, fields]) => {
            if (results.length > 0) {

                sql = "UPDATE " + DB + ".tbl_restandar SET EST_CDETALLE1 = '1' WHERE (PKEST_NCODIGO = '" + (results[0].PKEST_NCODIGO).toString() + "');";
                console.log(sql);
                connDB.promise().query(sql)
                    .then(([results, fields]) => {})
                    .catch((Error) => ControlErrores(Error));
            } else {
                sql = "INSERT INTO " + DB + ".tbl_restandar (EST_CCONSULTA, EST_CDETALLE, EST_CDETALLE1, EST_CDETALLE_REGISTRO, EST_CESTADO) VALUES ('ControlBotActivo', '" + (NombreProyecto).toString() + "', '1', 'Registro por el sistema', 'Activo');";
                console.log(sql);
                connDB.promise().query(sql)
                    .then(([results, fields]) => {})
                    .catch((Error) => ControlErrores(Error));
            };
        })
        .catch((Error) => ControlErrores(Error));

}



//recarga cada 5 segundos el array de los adjuntos con el fin de evitar detener el bot y ponerlo a correr de nuevo
function  reloadFIles() {
    setInterval( () =>  {
    filesBogota=fs.readdirSync("./docs_Ingenal/BOGOTA")
    filesCartagena=fs.readdirSync("./docs_Ingenal/CARTAGENA")
        }, 5000);
}
   


//**ACLARACION PARA LOS ADJUNTOS, LOS ADJUNTOS NO NECESITAN UNA RUTA LARGA, CON LA CARPETA DOCS
//*SE PUEDEN HACER ENVIOS PERO SIEMPRE DEBE EXISTIR LA CARPETA LOGS Y LAS SUBCARPETAS CORRESPONDIENTES A LAS CIUDADES*/
//**EN ESTE CASO BOGOTA Y CARTAGENA, NO OBSTANTE PUEDE USARSE LA RUTA LARGA (RutaEjecutableProgram)** /

//envia adjuntos a bogota
function envioBogota(froom) {

    try {
    console.log("los archvos son ",filesBogota);
    console.log("TYPEOF",typeof(filesBogota));
    filesBogota.forEach(element => {
        
    console.log("los valores",element);
    var media = MessageMedia.fromFilePath( "./docs_Ingenal/BOGOTA/" + element);
    clientWP.sendMessage(froom, media);
    });
    
        

    } catch (error) {
        ControlErrores(error)
    }
        
    
}


//envia adjuntos a cartagena
function envioCartagena(froom) {
    try {
        console.log("los archvos son ",filesCartagena);
        console.log("TYPEOF",typeof(filesCartagena));
        filesCartagena.forEach(element => {
            
            console.log("los valores",element);
            var media = MessageMedia.fromFilePath( "./docs_Ingenal/CARTAGENA/" + element);
            clientWP.sendMessage(froom, media);
        });
    } catch (error) {
        ControlErrores(error);
    }
   
}




//Verifica chats sin respuesta y sin terminar por mas de 30 minutos y envia un mensaje de recordatorio
function RecordarConversacion(MensajeRecordatorio, TiempoRecordatorio) {

    sql = "SELECT PKGES_CCODIGO, GES_NUMERO_COMUNICA, GES_CDETALLE, GES_CDETALLE1, GES_CDETALLE2, GES_CDETALLE3, GES_CDETALLE5, TIMESTAMPDIFF(MINUTE, GES_CFECHA_MODIFICACION, NOW()) AS DIFERENCIA_TIEMPO FROM u632406828_dbp_whatsappbo.tbl_cgestion WHERE GES_CDETALLE7 IS NULL AND GES_CDETALLE5 IS NULL AND GES_CESTADO = 'Activo' ORDER BY PKGES_CCODIGO DESC LIMIT 1;";
    console.log(sql);
    connDB.promise().query(sql)
        .then(([results, fields]) => {
            if (results.length > 0) {

                var CodigoRegistro = results[0].PKGES_CCODIGO;
                var GES_NUMERO_COMUNICA = results[0].GES_NUMERO_COMUNICA;
                var Pregunta1 = results[0].GES_CDETALLE;
                var Pregunta2 = results[0].GES_CDETALLE1;
                var Pregunta3 = results[0].GES_CDETALLE2;
                var Pregunta4 = results[0].GES_CDETALLE3;
                var EstadoRecordado = results[0].GES_CDETALLE5;
                var UltimaFechaInteraccion = results[0].DIFERENCIA_TIEMPO;

                if (Pregunta1 == null || Pregunta2 == null || Pregunta3 == null || Pregunta4 == null) {

                    if (EstadoRecordado == null) {

                        if (UltimaFechaInteraccion >= parseInt(TiempoRecordatorio, 10)) {

                            clientWP.sendMessage(GES_NUMERO_COMUNICA, MensajeRecordatorio + "😊");

                            sql = "UPDATE " + DB + ".tbl_cgestion SET GES_CDETALLE5 = 'MENSAJE RECORDATORIO ENVIADO' WHERE (PKGES_CCODIGO = '" + CodigoRegistro.toString() + "');";
                            console.log(sql);
                            connDB.promise().query(sql)
                                .then(([results, fields]) => {})
                                .catch((Error) => ControlErrores(Error));

                        }

                    }

                }
            }
        })
        .catch((Error) => ControlErrores(Error));


}



//Obtiene el tamano actual de un archivo en el PC
function getFilesizeInBytes(filename) {
    var stats = fs.statSync(filename);
    var fileSizeInBytes = stats.size;
    return fileSizeInBytes;
}





Array.prototype.unicos = function() {
  const unicos = [];
  for (i = 0; i < this.length; i++) {
      const valor = this[i];

      if (unicos.indexOf(valor) < 0) {
          unicos.push(valor);
      }
  }

  return unicos;
};