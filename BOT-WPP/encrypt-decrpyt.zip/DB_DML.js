"use strict";
const mysql = require("mysql2");
const { database } = require("./keys");
const DB = database.database;
let connDB = mysql.createConnection({
  host: database.host,
  user: database.user,
  database: database.database,
  password: database.password,
  dateStrings: true,
});

class Permiso {
  async valid_numero(numero_chat) {
    let estado = "Activo";
    let nivel = "MOTORIZADO";
    let nombre = "";
    const sql = `SELECT * FROM ${DB}.tbl_rpermiso WHERE PER_NUMERO_CELULAR ='${numero_chat}' AND PER_CNIVEL = '${nivel}' AND PER_CESTADO = '${estado}';`;

    await connDB
      .promise()
      .query(sql)
      .then(([results, fields]) => {
        if (results.length > 0) {
          nombre = results[0].PER_CUSUARIO;
        } else {
          nombre = "";
        }
      })
      .catch((Error) => ControlErrores(Error));
    return nombre;
  }
  ControlErrores(Error) {
    var FechaActual = GetFechaActual();
    var HoraActual = getHoraActual();
  
    if (!fs.existsSync("logs")) {
      fs.mkdirSync("logs");
    }
    var logger = fs.createWriteStream(`./logs/log_${FechaActual}.txt`, {
      flags: "a",
    });
    var DetalleError = dumpError(Error);
    logger.write(`${Error} ${DetalleError} ${FechaActual} - ${HoraActual}\n`);
  }
}

class Gestion{
  async insert_gestion(numero, msg, estado) {
    let comprobar = false;
    const sql = `INSERT INTO ${DB}.tbl_gestion (GES_NUMERO_COMUNICA, GES_CULT_MSGBOT, GES_CESTADO) VALUES ('${numero}', '${msg}', '${estado}')`;
    await connDB
      .promise()
      .query(sql)
      .then(() => {
          comprobar = true;        
      });
      return comprobar;
  }

  async get_msg_by_numero(numero_chat) {
    let estado = "Activo";
    let msg_bot = '';
    const sql = `SELECT * FROM ${DB}.tbl_gestion WHERE GES_NUMERO_COMUNICA ='${numero_chat}' AND GES_CESTADO = '${estado}';`;
    await connDB
      .promise()
      .query(sql)
      .then(([results, fields]) => {
        if (results.length > 0) {
          msg_bot = results[0].GES_CULT_MSGBOT;
        } else {
          msg_bot = '';
        }
      })
      .catch((Error) => ControlErrores(Error));

    return msg_bot;
  }

  async get_id_by_numero(numero_chat) {
    let estado = "Activo";
    let id_gestion = '';
    const sql = `SELECT * FROM ${DB}.tbl_gestion WHERE GES_NUMERO_COMUNICA ='${numero_chat}' AND GES_CESTADO = '${estado}';`;
    await connDB
      .promise()
      .query(sql)
      .then(([results, fields]) => {
        if (results.length > 0) {
          id_gestion = results[0].PKGES_CODIGO;
        } else {
          id_gestion = '';
        }
      })
      .catch((Error) => ControlErrores(Error));
    return id_gestion;
  }

  async update_gestion(id, msg, respuesta) {
    let comprobar = false;
    let estado = "Activo";
    const sql = `UPDATE ${DB}.tbl_gestion SET GES_CULT_MSGBOT = '${msg}', GES_CDETALLE = '${respuesta}' WHERE PKGES_CODIGO = '${id}' AND GES_CESTADO = '${estado}';`;
    await connDB
      .promise()
      .query(sql)
      .then(() => {
          comprobar = true;        
      });
      return comprobar;
  }
  ControlErrores(Error) {
    var FechaActual = GetFechaActual();
    var HoraActual = getHoraActual();
  
    if (!fs.existsSync("logs")) {
      fs.mkdirSync("logs");
    }
    var logger = fs.createWriteStream(`./logs/log_${FechaActual}.txt`, {
      flags: "a",
    });
    var DetalleError = dumpError(Error);
    logger.write(`${Error} ${DetalleError} ${FechaActual} - ${HoraActual}\n`);
  }
}

class Mensaje {
  async get_mensaje() {
    let estado = "Activo";
    let estado_mensaje = "POR ENVIAR";
    let respuesta = null;
    const sql = `SELECT PKMEN_NCODIGO, MEN_NUMERO_DESTINO, MEN_TEXTO FROM ${DB}.tbl_mensajes_chat WHERE MEN_ESTADO_MENSAJE ='${estado_mensaje}' AND MEN_CESTADO = '${estado}' LIMIT 1;`;
    await connDB
      .promise()
      .query(sql)
      .then(([results, fields]) => {
        if (results.length > 0) {
          respuesta = results[0];
        } else {
          respuesta = null;
        }
      })
      .catch((Error) => ControlErrores(Error));
    return respuesta;
  }

  async update_mensaje(id, msg) {
    let comprobar = false;
    let estado = "Activo";
    const sql = `UPDATE ${DB}.tbl_mensajes_chat SET MEN_ESTADO_MENSAJE = '${msg}' WHERE PKMEN_NCODIGO = '${id}' AND MEN_CESTADO = '${estado}';`;
    await connDB
      .promise()
      .query(sql)
      .then(() => {
          comprobar = true;        
      });
      return comprobar;
  }

  async insert_mensaje(gestion, numero, mensaje,tipo_mensaje) {
    let comprobar = false;
    let estado = "Activo";
    let estado_mensaje = "RECIBIDO"
    let detalle = "Registrado por el Bot"
    const sql = `INSERT INTO ${DB}.tbl_mensajes_chat (FK_GES_CODIGO, MEN_ESTADO_MENSAJE, MEN_NUMERO_ORIGEN, MEN_TIPO_MENSAJE, MEN_TEXTO, MEN_CDETALLE_REGISTRO, MEN_CESTADO) VALUES ('${gestion}','${estado_mensaje}','${numero}','${tipo_mensaje}','${mensaje}','${detalle}','${estado}');`;
    await connDB
      .promise()
      .query(sql)
      .then(() => {
          comprobar = true;        
      });
      return comprobar;
  }

  ControlErrores(Error) {
    var FechaActual = GetFechaActual();
    var HoraActual = getHoraActual();
  
    if (!fs.existsSync("logs")) {
      fs.mkdirSync("logs");
    }
    var logger = fs.createWriteStream(`./logs/log_${FechaActual}.txt`, {
      flags: "a",
    });
    var DetalleError = dumpError(Error);
    logger.write(`${Error} ${DetalleError} ${FechaActual} - ${HoraActual}\n`);
  }
  
}
module.exports = {Permiso, Gestion, Mensaje};
