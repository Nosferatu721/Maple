# COS_RPA_BOTWHATSAPPSAMARITANA

 
 ![GitHub Dark](https://i.ytimg.com/vi/DEiTDQ2GlxA/mqdefault.jpg)
 
 
Documentación website correspondiente al hospital universitario samaritana.


Conexión a base de datos.
=============

La base de datos a la cual se conecta mediante el archivo keys es la base de datos ubicada en:
Site 6.
IP:172.70.7.23

>**Mas info visitar :** https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/src/keys.js

Dependencias.
=============
El presente proyecto usa express js, mysql2 y whatsappweb de pedro lopez,scanqr,entre otras... todas las dependencias las puede encontrar en el archivo package Json 
>**Todas las Dependencias:**  https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/package.json

Si desea instalar las dependencias de este proyecto clone el presente proyecto y seguido a esto ubiquese en la raiz de la carpeta y  ejecute el comando:
```
npm i 
```
Express js.
=============
Express es un framework de node js que nos ayuda a manejar la parte del backend, para esto express utiliza rutas, estas rutas son accedidas por los tipicos metodos http:
- **POST**.
- **GET**.
- **PUT**.
- **DELETE**. 

 Entre otros, en este proyecto solo se usan dos metódos, POST Y GET.
 
 View.
=============
Para la parte gráfica se hizo uso de los handlebars(HBS), que son plantillas html mucho mas potentes y que nos permiten separar el código html del código javascript  haciendo mucho mas limpio el código.
>HBS nos permite crear una plantilla general definiendo  únicamente el head y ,en las otras vistas que se creen, HBS nos permite cambiar el body del html, también permite la integración con CSS al igual que un documento normal HTML **[Main HBS](https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/src/views/layouts/main.hbs)**. 

Algunas otras vistas que usa la plataforma:
- [Transferencias:](https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/src/views/samaritana/transferencias.hbs) encargado de definir la plantilla original del apartado de las tranferencias.
- [Reportes:](https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/src/views/samaritana/reportes.hbs) encargado de definir la estructura estática de los reportes.
- [Reportes export:](https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/src/views/samaritana/reportExcel.hbs) encargado de definir la estructura básica de los reportes y los intervalos de tiempo que desea el usuario.
- [Nav:](https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/src/views/partials/nav.hbs) encargado de definir la barra del costado izquierdo esto genera un menú para acceder a las distintas opciones.
- [Header:](https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/src/views/partials/header.hbs) encargado de definir la barra superior donde se encuentran los estados del asesor.

Autenticación(login).
=============
Para la autenticación es necesario usar dos de las herramientas que nos brinda expressjs en este caso se usa passport y auth, passport se usa para validar el usuario y la contraseña del usuario, despues de ello realiza una serialización y deserialización que devuelve en forma de dato para ser usada en cualquier parte del proyecto.


>**[PASSPORT](https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/src/lib/passport.js)**


Cuando usamos auth, usamos rutas que nos brinda el express js ṕara direccionar las acciones que pueda tener un usuario al interactuar con el sitio web, por ejemplo si el login es exitoso o no es exitoso a donde debe redirigir el sitio web.


>**[AUTH](https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/src/lib/auth.js)**

RUTAS(lógica de negocio).
=============

Como se mencionaba con anterioridad, express js nos permite gestionar nuestro backend mediante el uso de rutas, es decir si lo vemos como un patron de arquitectura de software, express js nos permite crear MVC, siendo express el que nos garantiza el modelo (el que controla los datos) mediante rutas. 
>Todas las rutas se pueden encontrar aquí: [RUTAS](https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/tree/main/src/routes)

Pero para ser breves las rutas que realmente se usan son: 
- [Transferencias:](https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/src/routes/samaritana.js) encargado de las rutas que permiten la asignación de chats
- [Reportes:](https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/src/routes/samaritanaRep.js) encargado de las rutas que permiten la información plasmada en los reportes.
- [Reportes para exportar en excel:](https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/src/routes/samaritanaRepExport.js) encargado de las rutas que permiten la generación de excel.

Javascript (lógica de los datos).
=============
Una vez se han definido las vistas y las rutas que actuan como lógica de negocio falta definir el intermedio entre los datos y la parte gráfica, para este caso usamos javascript puro sin JQUERY para hacer un intermedio entre estos datos y las interfaces gráficas 

- [Transferencias:](https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/src/public/js/transferencias.js): encargado de realizar la asignación gráfica de los casos, el control de los estados del asesor, y el ping sostenido a la base de datos.  
- [Reportes:](https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/src/public/js/reportes.js): encargado de realizar los reportes de manera gráfica, ayuda a dibujar en el html las gráficas de torta y lineal así como también las tablas con detalles de asesor y casos en cola.
- [Exporte de reportes:](https://github.com/LEONSEBASTIANGOMEZ/COS_RPA_BOTWHATSAPPSAMARITANA/blob/main/src/public/js/reportExport.js): encargado de permitir que el usuario pueda  realizar el filtrado por fecha para luego descargar el excel con los datos recolectados.


Métodos/Funciones.
=============
El proyecto presenta diversos métodos/funciones que ayudan a que la aplicación se ejecute de una correcta manera, para ello veremos por cada modulo, (3 modulos acutales, transferencias,reportes, exporte de reportes), las funciones mas relevantes y que hace cada una.

**TRANSFERENCIAS**
| Método/función | Descripción |
| --- | --- |
| `getId()` | Se encarga de obtener el ID del asesor desde la tabla rpermisos* |
| `ChatsAsignados` | Esta es una función flecha de mucha importancia que tiene como objetivo revisar las variables alojadas dentro del almacenamiento del javascript (" localStorage "), si encuentra que estan vacias procede a ejecutar un select de los últimos arboles y procede a asignarlo al agente(asignar se traduce en hacer un update del id en la tabla de gestión),esta funciíón se ejecuta recursivamente cada 1 segundo|
| `asignacion()` | Hace el llamado a la ruta que ejecuta el update, la anterior función explicada hace un llamado a esta función.|
| `cambio_ids()` | Esta función se encarga de hacer un cambio en los id de los chats,cambia los id por el número de celular del chat asignado, también imprime en la barra superior el número asignado.|
| `refreshMessagesChat1` | Esta función se encarga de traer los mensajes escritos en la base de datos tanto como por el receptor como por el emisor, esto se repite dos veces mas para el chat2 y para el chat3|
| `hidebutton()` | Encargada de volver invisible los botones de deslogueo, esto con el fin que el agente cierre sesión mientras esta en estado activo, cuando su estado sea "cerrar sesión", se habilita este boton siempre y cuando cumpla con que no tiene casos asignados|
| `closeChat1` | Como tal esta no es una función sino un listener que se encarga de desplegar un listener en el modal que se genera una vez el agente quiere cerrar un caso, este controla las variables del localstorage(las remueve) y llama a la función que actualiza el estado del árbol, también envia un mensaje de despedida, este listener se repite para los otros 2 chats.|
| `auxState` | Este es un listener que siempre esta a la escucha de que estado tiene el asesor y lo actualiza por base de datos.|
| `inputMensaje1/btnEnvioMensaje_1 ` | Este listener tiene dos formas de dispararse uno con la tecla enter y el otro con el boton al hacer click, al realizar esto envia el insert a la base de datos que posteriormente será renderiza con el metodo refreshMessagesChatn, este método se repite otras dos veces.|
| `tipificacion1/subtipificacion1 ` | Este listener tiene como objetivo desplegar valores de un select dependiendo del otro, es decir una opción de un select despliega las opciones del otro select.|

**REPORTES**

| Método/función | Descripción |
| --- | --- |
| `refreshtableUser` | Esta función se encarga de dibujar los datos del usuario junto con  su cedula y los casos que tiene activos en el momento |
| `RefreshtableCasosPendientes` | Esta es una función flecha encargada de imprimir los arboles que estan en espera, con datos como el numero el nombre entro otros datos|
| `updateData()` | Encargada de realizar la actualización de las variables del localstorage dadi un cierto tiempo .|



Comandos a utilizar en el proyecto.
=============
Durante la implementación de este proyecto se hizo uso de los siguientes comandos.


| Comando | Descripción |
| --- | --- |
| `npm run dev` | Realiza la ejecución de todo el proyecto* |
| `rs` | rs nos permite reiniciar el servidor sin depender de nodemon |
| `npm i (algun paquete)` | Nos permite instalar paquetes necesarios para el funcionamiento del proyecto |



