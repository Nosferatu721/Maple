const router = require('express').Router();
const db = require('../database');
const path = require('path');
const { userInfo } = require('os');
///!RUTAS PARA REPORTES.

router.get('/reportes', (req, res) => {
  res.render('samaritana/reportes', { title: 'Reportes' });
});

router.get('/allUser', (req, res) => {
  const sql =
    'SELECT PKPER_NCODIGO, CRE_CUSUARIO, CONCAT(CRE_CNOMBRE, " ", CRE_CNOMBRE2, " ",CRE_CAPELLIDO, " ",CRE_CAPELLIDO2) AS NOMBRE, CRE_CDOCUMENTO AS DOCUMENTO , PER_AUXILIAR, (SELECT COUNT(*) FROM dbp_what_samaritana.tbl_gestion, dbp_what_samaritana.tbl_rpermiso, dbp_what_samaritana.tbl_rcredencial WHERE  FKGES_NPER_CODIGO = PKPER_NCODIGO AND FKPER_NCRE_NCODIGO = PKCRE_NCODIGO AND CRE_CDOCUMENTO = DOCUMENTO AND GES_ESTADO_CASO = "ABIERTO" AND PER_CESTADO = "Activo" AND CRE_CESTADO = "Activo") AS CANTIDAD_CHAT FROM dbp_what_samaritana.tbl_rcredencial,dbp_what_samaritana.tbl_rpermiso where dbp_what_samaritana.tbl_rpermiso.FKPER_NCRE_NCODIGO= dbp_what_samaritana.tbl_rcredencial.PKCRE_NCODIGO and PER_CNIVEL="AGENTE" order by CANTIDAD_CHAT desc ;';
  db.promise()
    .query(sql)
    .then(([result]) => {
      res.json({ result });
    });
});
router.get('/countCasosOpen', (req, res) => {
  const sql = 'SELECT COUNT(*) as contador FROM dbp_what_samaritana.tbl_gestion WHERE GES_ESTADO_CASO="ABIERTO";';
  db.promise()
    .query(sql)
    .then(([result]) => {
      res.json({ contador: result[0].contador });
    });
});
router.get('/countCasosClosed', (req, res) => {
  const sql = 'SELECT COUNT(*)  as contador FROM dbp_what_samaritana.tbl_gestion WHERE GES_ESTADO_CASO="CERRADO";';
  db.promise()
    .query(sql)
    .then(([result]) => {
      res.json({ contador: result[0].contador });
    });
});

router.get('/countCasosPending', (req, res) => {
  const sql = 'SELECT COUNT(*) as contador FROM dbp_what_samaritana.tbl_gestion WHERE GES_ESTADO_CASO is null AND GES_CULT_MSGBOT="MSG_FIN";';
  db.promise()
    .query(sql)
    .then(([result]) => {
      res.json({ contador: result[0].contador });
    });
});

async function datosChat(ArrayDatos) {
 
  console.log(ArrayDatos);
  Contador = 0
  ArrayDatos.forEach(element => {
    Contador = Contador + 1;
  });

  
  Dato = ""
  
  for (let index = 0; index < Contador; index++) {

    sql1 =
      "SELECT timestampdiff(MINUTE,(SELECT MEN_CFECHA_REGISTRO FROM dbp_what_samaritana.tbl_mensajes_chat WHERE FK_GES_CODIGO = '" +
      ArrayDatos[index].PKGES_CODIGO +
      "' AND MEN_ESTADO_MENSAJE != 'RECIBIDO' ORDER BY PKMEN_NCODIGO ASC LIMIT 1),(SELECT MEN_CFECHA_REGISTRO FROM dbp_what_samaritana.tbl_mensajes_chat WHERE FK_GES_CODIGO = '" +
      ArrayDatos[index].PKGES_CODIGO +
      "' AND MEN_ESTADO_MENSAJE != 'RECIBIDO' ORDER BY PKMEN_NCODIGO DESC LIMIT 1)) AS DIFERENCIA_ATENCION_ASESOR FROM dbp_what_samaritana.tbl_mensajes_chat WHERE FK_GES_CODIGO = '" +
      ArrayDatos[index].PKGES_CODIGO + "' GROUP BY FK_GES_CODIGO LIMIT 1";
      console.log("Holaaaaaaaaaaaaaaaaaaaaaaaa",sql1);
    await db.promise().query(sql1)
      .then(([rows, fields]) => {
        if(rows.length>0){
          Dato = Dato + ArrayDatos[index].PKGES_CODIGO + "|" + ArrayDatos[index].GES_NUMERO_COMUNICA + "|" + ArrayDatos[index].DIFERENCIA + "|" + rows[0].DIFERENCIA_ATENCION_ASESOR + "-"
        }
        else{
          Dato = Dato + ArrayDatos[index].PKGES_CODIGO + "|" + ArrayDatos[index].GES_NUMERO_COMUNICA + "|" + ArrayDatos[index].DIFERENCIA + "|" + "0" + "-"
        }

      })
  }

  return Dato.slice(0, -1);
  

  



}

router.post('/consultaFeatures', async (req, res) => {
  const { PKPER_NCODIGO } = req.body;
  let id = PKPER_NCODIGO;
  console.log('ESTOY ENTRANDO CUANTAS VECES?');

  //console.log("ESTE ES EL FORMATO ",formatedNumber);
  ArrayDatos = '';
  var Dato1 = '';
  const sql = 'SELECT PKGES_CODIGO, GES_NUMERO_COMUNICA, (timestampdiff(MINUTE,GES_CFECHA_REGISTRO,GES_CFECHA_MODIFICACION)) AS DIFERENCIA FROM dbp_what_samaritana.tbl_gestion WHERE FKGES_NPER_CODIGO= ? AND GES_ESTADO_CASO="ABIERTO";';
  console.log("SOY CONSULTA JEJEEEEEEEEEEEEEEEEE ",sql);
  Dato1 = await db
    .promise()
    .query(sql, [id])
    .then(([result, fields]) => {
      ArrayDatos = result;
      //res.json({ result });
     // console.log('>>>>>>>>>>>>>>>>>>>>>>>DEVUELVO', result);
    })
    .then(async (numeros) => {
      var numeros2 = await datosChat(ArrayDatos);   
      //numeros2 = numeros2.split("-");
      console.log("PILLEEEEEEEEEEEEEEEEEEE",numeros2);
      res.json({numeros2});


    });

});

router.get('/allCasosPendientes', (req, res) => {
  const sql = 'SELECT  PKGES_CODIGO,GES_NUMERO_COMUNICA,GES_CDETALLE,GES_CDETALLE1,GES_CDETALLE3,GES_CDETALLE6 from dbp_what_samaritana.tbl_gestion where GES_ESTADO_CASO is null and GES_CULT_MSGBOT="MSG_FIN";';
  db.promise()
    .query(sql)
    .then(([result]) => {
      res.json({ result });
    });
});

router.post('/count5horas', (req, res) => {
  const { HoraIni, HoraFin } = req.body;

  //console.log("ME LLEGAN >>>>>>>>>>>>>>>>>>>>><",HoraIni,HoraFin);
  //res.json({ arrayIni,arrayFin});
  //datetime= datetime.getFullYear()+"-"+(datetime.getMonth()+1)+"-"+datetime.getDate()+" "+datetime.getHours()+":"+datetime.getMinutes()+"";
  const sql = 'SELECT count(GES_CFECHA_REGISTRO) as contador from dbp_what_samaritana.tbl_gestion where GES_CFECHA_REGISTRO BETWEEN ? AND ?';
  db.promise()
    .query(sql, [HoraIni, HoraFin])
    .then(([result]) => {
      res.json({ contador: result[0].contador });
      console.log('devuelvo>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>', result[0].contador);
    });
});

router.post('/count4horas', (req, res) => {
  const { HoraIni, HoraFin } = req.body;

  //console.log("ME LLEGAN >>>>>>>>>>>>>>>>>>>>><",HoraIni,HoraFin);
  //res.json({ arrayIni,arrayFin});
  //datetime= datetime.getFullYear()+"-"+(datetime.getMonth()+1)+"-"+datetime.getDate()+" "+datetime.getHours()+":"+datetime.getMinutes()+"";
  const sql = 'SELECT count(GES_CFECHA_REGISTRO) as contador from dbp_what_samaritana.tbl_gestion where GES_CFECHA_REGISTRO BETWEEN ? AND ?';
  db.promise()
    .query(sql, [HoraIni, HoraFin])
    .then(([result]) => {
      res.json({ contador: result[0].contador });
      console.log('devuelvo>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>', result[0].contador);
    });
});

router.post('/count3horas', (req, res) => {
  const { HoraIni, HoraFin } = req.body;

  //console.log("ME LLEGAN >>>>>>>>>>>>>>>>>>>>><",HoraIni,HoraFin);
  //res.json({ arrayIni,arrayFin});
  //datetime= datetime.getFullYear()+"-"+(datetime.getMonth()+1)+"-"+datetime.getDate()+" "+datetime.getHours()+":"+datetime.getMinutes()+"";
  const sql = 'SELECT count(GES_CFECHA_REGISTRO) as contador from dbp_what_samaritana.tbl_gestion where GES_CFECHA_REGISTRO BETWEEN ? AND ?';
  db.promise()
    .query(sql, [HoraIni, HoraFin])
    .then(([result]) => {
      res.json({ contador: result[0].contador });
      console.log('devuelvo>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>', result[0].contador);
    });
});

router.post('/count2horas', (req, res) => {
  const { HoraIni, HoraFin } = req.body;

  //console.log("ME LLEGAN >>>>>>>>>>>>>>>>>>>>><",HoraIni,HoraFin);
  //res.json({ arrayIni,arrayFin});
  //datetime= datetime.getFullYear()+"-"+(datetime.getMonth()+1)+"-"+datetime.getDate()+" "+datetime.getHours()+":"+datetime.getMinutes()+"";
  const sql = 'SELECT count(GES_CFECHA_REGISTRO) as contador from dbp_what_samaritana.tbl_gestion where GES_CFECHA_REGISTRO BETWEEN ? AND ?';
  db.promise()
    .query(sql, [HoraIni, HoraFin])
    .then(([result]) => {
      res.json({ contador: result[0].contador });
      console.log('devuelvo>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>', result[0].contador);
    });
});

router.post('/count1horas', (req, res) => {
  const { HoraIni, HoraFin } = req.body;

  //console.log("ME LLEGAN >>>>>>>>>>>>>>>>>>>>><",HoraIni,HoraFin);
  //res.json({ arrayIni,arrayFin});
  //datetime= datetime.getFullYear()+"-"+(datetime.getMonth()+1)+"-"+datetime.getDate()+" "+datetime.getHours()+":"+datetime.getMinutes()+"";
  const sql = 'SELECT count(GES_CFECHA_REGISTRO) as contador from dbp_what_samaritana.tbl_gestion where GES_CFECHA_REGISTRO BETWEEN ? AND ?';
  db.promise()
    .query(sql, [HoraIni, HoraFin])
    .then(([result]) => {
      res.json({ contador: result[0].contador });
      console.log('devuelvo>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>', result[0].contador);
    });
});

router.post('/countHour', (req, res) => {
  const { HoraIni, HoraFin } = req.body;

  //console.log("ME LLEGAN >>>>>>>>>>>>>>>>>>>>><",HoraIni,HoraFin);
  //res.json({ arrayIni,arrayFin});
  //datetime= datetime.getFullYear()+"-"+(datetime.getMonth()+1)+"-"+datetime.getDate()+" "+datetime.getHours()+":"+datetime.getMinutes()+"";
  const sql = 'SELECT count(GES_CFECHA_REGISTRO) as contador from dbp_what_samaritana.tbl_gestion where GES_CFECHA_REGISTRO BETWEEN ? AND ?';
  db.promise()
    .query(sql, [HoraIni, HoraFin])
    .then(([result]) => {
      res.json({ contador: result[0].contador });
      console.log('devuelvo>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>', result[0].contador);
    });
});

module.exports = router;
