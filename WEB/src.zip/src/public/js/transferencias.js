document.addEventListener('DOMContentLoaded', () => {

///*************************************APARTADO DE VAIRABLES**************************///
  var lenOriginal = 0;
  var lengAux = 0;
  var lenOriginal2 = 0;
  var lengAux2 = 0;
  var lenOriginal3 = 0;
  var lengAux3 = 0;
  var idPer = 0;
  var lenOriginalOut = 0;
  var lengAuxOut = 0;
  var number1 = 0;
  var number2 = 0;
  var number3 = 0;
  var contadorMensjNew = 0;
  var contadorMensjNew2 = 0;
  var msjConcatenado = '';
  var msjConcatenado2 = '';
  var msjConcatenado3 = '';
  var contadorMensjNew3 = 0;
  var auxState = 0;
  let state = false;
  var idArbol = 0;
  var idArbol2 = 0;
  var idArbol3 = 0;
  let countMessagesChat1 = 0;
  var numberRecepcion = 0;
  let countMessagesChat2 = 0;
  
  let countMessagesChat3 = 0;
  

  //const chat_313481 = document.getElementById('chat_313481'),
  const chat = document.getElementById('chat');

  var elems = document.querySelectorAll('select');
  M.FormSelect.init(elems);
  ///*************************************APARTADO DE SELECTS E INPUTS*****************************//
  // BOTONES E INPUTS
  inputMensaje1 = document.getElementById('inputMensaje1');
  btnEnvioMensaje_1 = document.getElementById('btnEnvioMensaje_1');
  inputMensaje2 = document.getElementById('inputMensaje2');
  inputMensaje3 = document.getElementById('inputMensaje3');
  btnEnvioMensaje_3 = document.getElementById('btnEnvioMensaje_3');
  auxState = document.querySelector('.estados');
  //BOTON DE LLAMADO DEL MODAL
  closeChat1 = document.getElementById('closeChat1');
  closeChat2 = document.getElementById('closeChat2');
  closeChat3 = document.getElementById('closeChat3');

  tipificacion1= document.getElementById('tipification1');
  subtipificacion1= document.getElementById('subtipification1');

  tipificacion2= document.getElementById('tipification2');
  subtipificacion2= document.getElementById('subtipification2');
  
  tipificacion3= document.getElementById('tipification3');
  subtipificacion3= document.getElementById('subtipification3');
  

  cargarLoader("Espere por favor...");
  
  setTimeout(() => {
    ocultarLoader();
  }, 2000);

  //SIEMPRE QUE ENTRE EL USUARIO VA A ESTAR ACTVIO PERO PRIMERO DEBE VALIDAR SI TIENE UN ESTADO ANTERIOR
  //SI ES NULO SIGNIFICA QUE NO SE LE HA ASIGNADO NADA Y LO PONE COMO EN ESTADO ACTIVO
  //SI SIGNIFICA QUE SI REFRESCA LA PÁGINA NO VA A PERDER EL ESTADO EN EL QUE ESTA, DE OTRA FORMA LO ASIGNA EN ACTIVO
  if (localStorage.getItem('estadoUser') != null) {
    console.log('YA TIENE UN ESTADO CON ANTERIORIDAD');
  } else {
    let ACTIVO = 'ACTIVO';
    localStorage.setItem('estadoUser', ACTIVO);
  }

  //OBTENGO EL ID DEL USUARIO QUE SE LOGUEÓ
  function getId() {
    getData('/laika/getId').then((res) => {
      idPer = res.idPer;
      console.log("CODEE>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",idPer);
      });
  }
  getId();
  
  // VERIFICA SI TIENE CHATS ASIGNADOS
  //CONSTA DE DOS PARTES, UN SELECT QUE ELIGE UN CAMPO QUE CUMPLA CON LOS REQUISITOS Y UN UPDATE
  //QUE ACTUALIZA LOS CAMPOS
  const ChatsAsignados = () => {
    //REALIZA UNA CONSULTA PARA VERIFICAR CON ESE NUMERO LOS MENSAJES RECIBDIDOS
    postData('/laika/chatsAsignados', { PKPER_NCODIGO: idPer }).then(async (res) => {
      localStorage.setItem('cantidad', res.contador);
      let cantidad = localStorage.getItem('cantidad');
      if (cantidad < 3 && localStorage.getItem('estadoUser') === 'ACTIVO') {
       // console.log('ESTOY ENTRANDO AL IFFFFFFFFFFFFFFFFFFF');
          if (localStorage.getItem('number1') === null) {
         // console.log('@@@@@@@@@ENTRO ASIGNO AL CHAT1');
          postData('/laika/asignacionSelect').then(async (res) => {
            res.result.forEach((mensaje) => {
              
              let idArboll = mensaje.PKGES_CODIGO;
              numberRecepcion = mensaje.GES_NUMERO_COMUNICA;
              let ultMSJ = mensaje.GES_CDETALLE;
              
              console.log("************************ESTE ES EL MENSAJE",mensaje);
              idArbol = idArboll;
              let msjConcatenadoo = ultMSJ+'<br>'

              asignacion(idPer, idArbol);
              //    console.log('##################este es el', numberRecepcion);

              localStorage.setItem('number1', numberRecepcion);
              localStorage.setItem('Msj1', msjConcatenadoo);
              localStorage.setItem('arbol1', idArboll);
              Toast.fire({ icon: 'info', title: 'Tiene un nuevo usuario en el chat 1' });
            });
          });

          //        numberRecepcion=0;
        } else if (localStorage.getItem('number2') === null) {
          postData('/laika/asignacionSelect').then(async (res) => {
            res.result.forEach((mensaje) => {

              let idArboll = mensaje.PKGES_CODIGO;
              numberRecepcion = mensaje.GES_NUMERO_COMUNICA;
              let ultMSJ = mensaje.GES_CDETALLE;

              idArbol2 = idArboll;              
              let msjConcatenadoo = ultMSJ+'<br>';
              
              asignacion(idPer, idArbol2);
              //    console.log('##################este es el numero', numberRecepcion);
              localStorage.setItem('arbol2', idArboll);
              localStorage.setItem('number2', numberRecepcion);
              localStorage.setItem('Msj2', msjConcatenadoo);
              Toast.fire({ icon: 'info', title: 'Tiene un nuevo usuario en el chat 2' });
            });
          });
        } else if (localStorage.getItem('number3') === null) {
          postData('/laika/asignacionSelect').then(async (res) => {
            res.result.forEach((mensaje) => {
              let idArboll = mensaje.PKGES_CODIGO;
              numberRecepcion = mensaje.GES_NUMERO_COMUNICA;
              let ultMSJ = mensaje.GES_CDETALLE;

              idArbol2 = idArboll;              
              let msjConcatenadoo = ultMSJ+'<br>';
              
               
              asignacion(idPer, idArbol3);
              //   console.log('##################este es el numero', numberRecepcion);

              localStorage.setItem('number3', numberRecepcion);
              localStorage.setItem('Msj3', msjConcatenadoo);
              localStorage.setItem('arbol3', idArboll);
              Toast.fire({ icon: 'info', title: 'Tiene un nuevo usuario en el chat 3' });
            });
          });
        } else {
          //console.log("##################NUMBER1 QUEDO COMO",number1);
         // console.log('NO PASA NAHHHH');
        }
      } else {
      //  console.log('TERMINE LA GESTION ');
      }
    });

    // ! Repeat
    setTimeout(() => {
      ChatsAsignados();
    }, 1000);
  };
  ChatsAsignados();
  //ESTA FUNCION RECIBE EL ID DEL USUARIO Y EL ID DEL ARBOL, AQUI SE HACE LA ASIGNACION OSEA EL UPDATE
  async function asignacion(myID, IDTree) {
    let x = await postData('/laika/asignacionUpdate', { PKGES_CODIGO: IDTree, FKGES_NPER_CODIGO: myID });
    return x;
  }

  //LEGADA DE TRANSFERENCIA, DESPUES DE CONSULTAR QUE TODO ESTA OK, PROCEDO A
  // DISTRIBUIR LOS NUMEROS EN EL GRID, ENTONCES PRIMERO AISGNO EN EL DIV DE ARRIBA EL NUMERO
  //CAMBIO LAS CLASES.

  let chat1Init = 'chat_1';
  let chat1Init2 = 'chat_2';
  let chat1Init3 = 'chat_3';
  setInterval(function cambio_ids() {
    //ACA PINTO LOS NUMEROS Y SUS ID
    //OBTENGO LAS VARIABLES DEL LOCAL STORAGE
    number1 = localStorage.getItem('number1');
    number2 = localStorage.getItem('number2');
    number3 = localStorage.getItem('number3');
    //console.log('EL COMPILADO DE NUMEROS ES ', number1, number2, number3);
    // AQUI CAMBIO LOS ID DE LOS GRID PERO COMO SE CAMBIAN AL EJECUTARSE POR PRIMERA VEZ ESTA FUNC
    //LO QUE HACE ENTONCES ES ES VERIFICAR CUANDO CAMBIO Y ASIGNAR DE NUEVO EL ID CUANDO HAYA CAMBIADO
    console.log(chat1Init, number1);
    if (chat1Init != number1) {
      document.getElementById(chat1Init).id = number1;
      chat1Init = number1;
    }
    if (chat1Init2 != number2) {
      document.getElementById(chat1Init2).id = number2;
      chat1Init2 = number2;
    }
    if (chat1Init3 != number3) {
      document.getElementById(chat1Init3).id = number3;
      chat1Init3 = number3;
    }

    // PINTO EN EL DIV LOS NUMEROS
    if (number1 != 0) {
      document.getElementById('numero_chat1').innerHTML = number1;
    }
    if (number2 != 0) {
      document.getElementById('numero_chat2').innerHTML = number2;
    }

    if (number3 != 0) {
      document.getElementById('numero_chat3').innerHTML = number3;
    }

    // console.log('EL ID  DEL ARBOL1 ES ', idArbol);
    // console.log('EL ID  DEL ARBOL2 ES ', idArbol2);
    //console.log('EL ID  DEL ARBOL3 ES ', idArbol3);

    //document.getElementById('chat_2').id = number2;

    //document.getElementById('chat_3').id = number3;

    //numero1.innerHTML=number1;
  }, 2000);

  ///ESTAS 3 FUNCIONES SON LAS ENCARGADAS DE REALIZAR LA TOMA INICIAL DEL TAMAÑO DEL ARREGLO
  //TOMA EL TAMAÑO DE UN ARREGLO QUE CONSULTA LOS MENSAJES UNICAMENTE "RECIBIDOS"
  //ESTO SE HACE PARA NOTIFICAR EL SONIDO Y EL NUMERO DE MENSAJES
  setTimeout(function sizeMensajesOrigenChat1() {
    //console.log('entre al tamaño de la funcion size mensaje');
    //console.log('desde el size decimos que el numero 1 es  ', number1);
    postData('/laika/consultaMensajesOrigen', { MEN_NUMERO_DESTINO: number1 }).then((res) => {
      let lengthData = 0;
      res.result.forEach((mensaje) => {
        lengthData += 1;
      });

      lenOriginal = lengthData;
    });
  }, 2000);
  setTimeout(function sizeMensajesOrigenChat2() {
    postData('/laika/consultaMensajesOrigen', { MEN_NUMERO_DESTINO: number2 }).then((res) => {
      let lengthData = 0;
      res.result.forEach((mensaje) => {
        lengthData += 1;
      });

      lenOriginal2 = lengthData;
    });
  }, 2000);
  setTimeout(function sizeMensajesOrigenChat3() {
    postData('/laika/consultaMensajesOrigen', { MEN_NUMERO_DESTINO: number3 }).then((res) => {
      let lengthData = 0;
      res.result.forEach((mensaje) => {
        lengthData += 1;
      });

      lenOriginal3 = lengthData;
    });
  }, 2000);
  function notificar() {
    var sonido = new Audio('/audio/soundWpp.mp3');
    sonido.play();
  }
  //cambio_ids();

  // sizeMensajesOrigenChat1();
  // sizeMensajesOrigenChat2();
  //sizeMensajesOrigenChat3();

  //LISTENER ENCARGADO DE ESCUCHAR CUANDO SE CAMBIA UN TAB EN LA PLATAFORMA, CUANDO SE CAMBIA A OTRA TAB
  //REALIZA UN CAMBIO DE BOOLEANO EN LA VARIABLE STATE, TRUE CUANDO CAMBIA--) FALSE CUANDO NO CAMBIA
  document.addEventListener('visibilitychange', function () {
    console.log(document.hidden);
    state = document.hidden;
  });

  const refreshMessagesChat1 = () => {
    //CHAT1
    //OBTENEMOS EL NUMERO DEL PRIMER GRID DONDE SE VA A ESCRIBIR
    //LA FUNCIÓN EXPLICADA AQUI SE VALIDA PARA LAS OTRAS DOS POR LO CUAL NO ES NECESARIO EXPLICAR SU PROCEDIMIENTO
    let chat_1 = document.getElementById(number1);
    //FUNCION RECURRENTE QUE VA A CONSULTAR LOS MENSAJES QUE SE ESCRIBIERON
    //POSEE OTRAS FUNCIONES COMO LAS NOTIFICACIONES DE CUANDO LLEGA UN NUEVO MENSAJE
    //REALIZA UNA CONSULTA PARA VERIFICAR CON ESE NUMERO LOS MENSAJES RECIBDIDOS
    postData('/laika/consultaMensajesOrigen', { MEN_NUMERO_DESTINO: number1 }).then((res) => {
      let lengthData = 0;
      res.result.forEach((mensaje) => {
        lengthData += 1;
      });
      //GUARDA EL LENGTH DE LA CONSULTA CONSTANTE CON EL FIN DE COMPARARLA CON LA INICIAL
      lengAux = lengthData;
    });
    // console.log('ESTE ES EL MENSAJE', state);
    //LLEGADOS A ESTE PUNTO LAS FUNCIONES AQUI ABAJO LO QUE REALIZAN ES
    //UNA VALIDACION DE SI CAMBIO EL LENGTH DE LOS MENSAJES Y VERIFICA SI SE CAMBIO LA PESTAÑA

    if (lenOriginal != lengAux && state == false) {
      //ESTA FUNCION SOLO MUESTRA SONIDO SINO SE CAMBIO LA PESTAÑA
      console.log('me llego algo nuevo');
      notificar();
      lenOriginal = lengAux;
    } else if (lenOriginal != lengAux && state == true) {
      //ESTA FUNCION MUESTRA SONIDO Y HACE LA SUMA DE CUANTOS MENSAJES HAN LLEGADO, COMO SE SABE
      //EL LENGTH SOLO TRAE UN MENSAJE DE MAS, UNO A LA VEZ POR LO CUAL SE PUEDE SUMAR  LA CANTIDAD
      //DE VECES QUE ENTRA A ESTE CONDICIONAL
      console.log('cambio');
      console.log('me llego algo nuevo');
      notificar();
      contadorMensjNew += 1;
      lenOriginal = lengAux;

      document.title = `Mensajes nuevos(${contadorMensjNew})`;
    } else if (lenOriginal == lengAux && state == false) {
      //CAMBIAMOS A EL TITULO ORIGINAL Y LIMPIAMOS LA VARIABLE, NORMALMENTE DESPUES DE NAVEGAR
      //EN OTRAS PESTAÑAS Y VOLVER A ESTA SE CAMBIAN LOS MENSAJES PENDIENTES Y SE DEJA EL TITULO ORIGINAL
      contadorMensjNew = 0;
      //console.log('dentro del else ');
      document.title = 'Transferencias';
    }
    //ESTE OTRO POSTDATA LO QUE HACE ES VERIFICAR TODOS LOS NUMEROS Y DEPENDIENDO DEL TIPO SE VERIFICA
    //SI ES RECIBIDO O ENVIADO Y LOS PINTA EN EL HTML
    //lo declaro no global para evitar que se ponga en 0 cada vez que refresco
    let arboll1= localStorage.getItem('arbol1');
    postData('/laika/mensajesChat', { MEN_NUMERO_DESTINO: number1 , FK_GES_CODIGO: arboll1 }).then((res) => {
      chat_1.innerHTML = '';
      msjConcatenado = localStorage.getItem('Msj1');
      if (msjConcatenado != null) {
        //console.log('..........................EL MENSAJE CONCATENADO ES..................', msjConcatenado);
        chat_1.innerHTML += `<div class='mensaje_recivido'><span>${msjConcatenado}</span></div>`;

        res.result.forEach((mensaje) => {
          //EXTRAEMOS DATOS DEL JSON
          id = mensaje.PKMEN_NCODIGO;
          menssage = mensaje.MEN_TEXTO;
          fecha = mensaje.MEN_CFECHA_REGISTRO;
          estado = mensaje.MEN_ESTADO_MENSAJE;

          //ARREGLO EL DATO DE LA FECHA
          var hora = fecha.slice(11, 16);

          //VALIDO Y PINTO CON ICONOS EL MENSAJE
          if (estado == 'POR ENVIAR') {
            chat_1.innerHTML += `<div id=${id} class='mensaje_enviado'><span>${menssage} <span>${hora}<i class='bx bx-time-five'></i></span> </span></div>`;
          } else if (estado == 'ENVIADO') {
            chat_1.innerHTML += `<div id=${id} class='mensaje_enviado'><span>${menssage} <span>${hora}<i class='bx bx-check' ></i></span> </span></div>`;
          } else if (estado == 'RECIBIDO') {
            chat_1.innerHTML += `<div class='mensaje_recivido'><span>${menssage}<span>${hora}</span></span></div>`;
          }
        });
        //ACA VALIDAMOS SI EL LENGTH DE LOS MENSAJES CAMBIO Y SI CAMBIO SE HACE UN SCROLL HACIA ABAJO
        //SE HACE UN SCROLL AL INICIO YA QUE DETECTA QUE NO SON IGUALES, PERO LUEGO LAS VARIABLES SE IGUALAN
        // Y YA NO VUELVEN A HACER SCROLL A MENOS QUE LLEGUE UN MENSAJE NUEVO
        if (countMessagesChat1 != res.result.length) {
          console.log('Scrollsito');
          chat_1.scrollTo({
            top: chat_1.scrollHeight,
          });
          countMessagesChat1 = res.result.length;
        } else {
          //console.log('Sin Envios');
        }
      }
    });
    // ! Repeat
    setTimeout(() => {
      refreshMessagesChat1();
    }, 2000);
  };
  refreshMessagesChat1();

  //CHAT2

  const refreshMessagesChat2 = () => {
    let chat_2 = document.getElementById(number2);
    postData('/laika/consultaMensajesOrigen', { MEN_NUMERO_DESTINO: number2 }).then((res) => {
      let lengthData = 0;
      res.result.forEach((mensaje) => {
        lengthData += 1;
      });

      lengAux2 = lengthData;
    });
    //console.log('EL ESTADO DE LA VENTANA ES ', state);

    if (lenOriginal2 != lengAux2 && state == false) {
      console.log('me llego algo nuevo');
      notificar();
      lenOriginal2 = lengAux2;
    } else if (lenOriginal2 != lengAux2 && state == true) {
      console.log('cambio');

      console.log('me llego algo nuevo');
      notificar();
      lenOriginal2 = lengAux2;
      contadorMensjNew2 += 1;
      document.title = `Mensajes nuevos(${contadorMensjNew2})`;
    } else if (lenOriginal2 == lengAux2 && state == false) {
      contadorMensjNew2 = 0;
      //console.log('dentro del else ');
      document.title = 'Transferencias';
    }
    let arboll2= localStorage.getItem('arbol2');
    postData('/laika/mensajesChat', { MEN_NUMERO_DESTINO: number2 ,FK_GES_CODIGO:arboll2}).then((res) => {
      //lenOriginalOut = obj.result.length;
      chat_2.innerHTML = '';
      msjConcatenado2 = localStorage.getItem('Msj2');
      if (msjConcatenado2 != null) {
        //   console.log('..........................EL MENSAJE CONCATENADO ES..................', msjConcatenado2);
        chat_2.innerHTML += `<div class='mensaje_recivido'><span>${msjConcatenado2}</span></div>`;
        res.result.forEach((mensaje) => {
          id = mensaje.PKMEN_NCODIGO;
          menssage = mensaje.MEN_TEXTO;
          fecha = mensaje.MEN_CFECHA_REGISTRO;
          estado = mensaje.MEN_ESTADO_MENSAJE;

          var hora = fecha.slice(11, 16);
          if (estado == 'POR ENVIAR') {
            chat_2.innerHTML += `<div id=${id} class='mensaje_enviado'><span>${menssage} <span>${hora}<i class='bx bx-time-five'></i></span> </span></div>`;
          } else if (estado == 'ENVIADO') {
            chat_2.innerHTML += `<div id=${id} class='mensaje_enviado'><span>${menssage} <span>${hora}<i class='bx bx-check' ></i></span> </span></div>`;
          } else if (estado == 'RECIBIDO') {
            chat_2.innerHTML += `<div class='mensaje_recivido'><span>${menssage}<span>${hora}</span></span></div>`;
          }

          //console.log(obj);
        });
        if (countMessagesChat2 != res.result.length) {
          console.log('Scrollsito');
          chat_2.scrollTo({
            top: chat_2.scrollHeight,
          });
          countMessagesChat2 = res.result.length;
        } else {
          //console.log('Sin Envios');
        }
      }
    });
    // ! Repeat

    setTimeout(() => {
      refreshMessagesChat2();
    }, 2000);
  };
  refreshMessagesChat2();

  //CHAT3

  const refreshMessagesChat3 = () => {
    let chat_3 = document.getElementById(number3);
    postData('/laika/consultaMensajesOrigen', { MEN_NUMERO_DESTINO: number3 }).then((res) => {
      let lengthData = 0;
      res.result.forEach((mensaje) => {
        lengthData += 1;
      });

      lengAux3 = lengthData;
    });
    if (lenOriginal3 != lengAux3 && state == false) {
      console.log('me llego algo nuevo');
      notificar();
      lenOriginal3 = lengAux3;
    } else if (lenOriginal3 != lengAux3 && state == true) {
      console.log('cambio');

      console.log('me llego algo nuevo');
      notificar();
      contadorMensjNew3 += 1;
      lenOriginal3 = lengAux3;
      document.title = `Mensajes nuevos(${contadorMensjNew3})`;
    } else if (lenOriginal3 == lengAux3 && state == false) {
      contadorMensjNew3 = 0;
      // console.log('dentro del else ');
      document.title = 'Transferencias';
    }
    let arboll3= localStorage.getItem('arbol3');
    postData('/laika/mensajesChat', { MEN_NUMERO_DESTINO: number3 ,FK_GES_CODIGO:arboll3}).then((res) => {
      //lenOriginalOut = obj.result.length;
      chat_3.innerHTML = '';
      msjConcatenado3 = localStorage.getItem('Msj3');
      if (msjConcatenado3 != null) {
        //console.log('..........................EL MENSAJE CONCATENADO ES..................', msjConcatenado3);
        chat_3.innerHTML += `<div class='mensaje_recivido'><span>${msjConcatenado3}</span></div>`;
        res.result.forEach((mensaje) => {
          id = mensaje.PKMEN_NCODIGO;
          menssage = mensaje.MEN_TEXTO;
          fecha = mensaje.MEN_CFECHA_REGISTRO;
          estado = mensaje.MEN_ESTADO_MENSAJE;

          var hora = fecha.slice(11, 16);
          if (estado == 'POR ENVIAR') {
            chat_3.innerHTML += `<div id=${id} class='mensaje_enviado'><span>${menssage} <span>${hora}<i class='bx bx-time-five'></i></span> </span></div>`;
          } else if (estado == 'ENVIADO') {
            chat_3.innerHTML += `<div id=${id} class='mensaje_enviado'><span>${menssage} <span>${hora}<i class='bx bx-check' ></i></span> </span></div>`;
          } else if (estado == 'RECIBIDO') {
            chat_3.innerHTML += `<div class='mensaje_recivido'><span>${menssage}<span>${hora}</span></span></div>`;
          }

          //console.log(obj);
        });

        if (countMessagesChat3 != res.result.length) {
          console.log('Scrollsito');
          chat_3.scrollTo({
            top: chat_3.scrollHeight,
          });
          countMessagesChat3 = res.result.length;
        } else {
          //console.log('Sin Envios');
        }
      }
    });
    // ! Repeat

    setTimeout(() => {
      refreshMessagesChat3();
    }, 2000);
  };
  refreshMessagesChat3();
 ///OCULTA BOTONES.
 setInterval(function hidebutton()  {
  //console.log("ESTOY CON EL ESTADO",localStorage.getItem('estadoUser'),"y con la cantidad",localStorage.getItem('cantidad'));
  if (localStorage.getItem('estadoUser')=='ACTIVO'  && localStorage.getItem('cantidad')>0) {
    //console.log("ESTOY ENTRANDO A VALIDAR ELE STADO, ESTA ACTIVO Y CON MAS DE UN CASO");
    document.getElementById('close_session').style.display='none';
    closeChat1.style.visibility='visible';
    closeChat1.style.display='inline';
    closeChat2.style.visibility='visible';
    closeChat2.style.display='inline';
    closeChat3.style.visibility='visible';
    closeChat3.style.display='inline';
  }
  else if(localStorage.getItem('estadoUser')=='BREAK' && localStorage.getItem('cantidad')!=0 ){
    closeChat1.style.visibility='visible';
    closeChat1.style.display='inline';
    closeChat2.style.visibility='visible';
    closeChat2.style.display='inline';
    closeChat3.style.visibility='visible';
    closeChat3.style.display='inline';
    //console.log("ESTOY ENTRANDO A VALIDAR EL ESTADO, ESTA EN BREAK Y CON MAS DE UN CASO O NINGUN CASOS");
    //document.getElementById('close_session').style.visibility='hidden';
    document.getElementById('close_session').style.display='none';
  }
  else if(localStorage.getItem('estadoUser')=='BREAK' && localStorage.getItem('cantidad')==0 ){
    //console.log("ESTOY EN VALIDACION DE CANTIDAD 0 Y BREAK");
   // console.log("ESTOY ENTRANDO A VALIDAR EL ESTADO, ESTA EN BREAK Y CON MAS DE UN CASO O NINGUN CASOS");
    //document.getElementById('close_session').style.visibility='hidden';
    document.getElementById('closeChat1').style.display='none';
    document.getElementById('closeChat2').style.display='none';
    document.getElementById('closeChat3').style.display='none';
    document.getElementById('close_session').style.display='none';
    

  }
  else if(localStorage.getItem('estadoUser')=='TURNO CERRADO'&& localStorage.getItem('cantidad')==0 ){
    document.getElementById('closeChat1').style.display='none';
    document.getElementById('closeChat2').style.display='none';
    document.getElementById('closeChat3').style.display='none';
    document.getElementById('close_session').style.visibility='visible';
    document.getElementById('close_session').style.display='inline';

  }
 }, 1000);

  //METODOS USADOS PARA CERRAR EL CHAT.
  async function cerrarCaso(idArbol,input,tipificacionn,subtipificacionn) {
    console.log('************ME LLEGA************* ', idArbol);
    console.log('************ME LLEGA************* ', input);
    //console.log('************ME LLEGA************* ', sessionStorage.getItem('tipificacion1'));
    //console.log('************ME LLEGA************* ', sessionStorage.getItem('subtipificacion1'));

    let x = await postData('/laika/casoCerrado', { PKGES_CODIGO: idArbol,GES_CTIPIFICACION1:tipificacionn,GES_CTIPIFICACION2:subtipificacionn ,GES_CDETADICIONAL:input});
    return x;
  }


 

  closeChat1.addEventListener('click', async() => {
    let chat_1 = document.getElementById(number1);
    let arbol1 = localStorage.getItem('arbol1');
    //M.toast({html: 'I am a toast!'})
    if (sessionStorage.getItem('tipificacion1')!=null && sessionStorage.getItem('subtipificacion1')!=null) {
    
      console.log('************ME LLEGA************* ', arbol1);
      const mensajeFin="gracias por contactarnos nos estaremos viendo en proximas ocasiones";
  
      postData('/laika/enviarMensaje', { MEN_NUMERO_DESTINO: number1, MEN_TEXTO: mensajeFin,FK_GES_CODIGO:arbol1 }).then((res) => {
        console.log(res);
      });
  
      
     let  input =document.getElementById("observacionChat1").value;
      console.log("EL VALOR ES ",input);
      
      
      await cerrarCaso(arbol1,input,sessionStorage.getItem('tipificacion1'),sessionStorage.getItem('subtipificacion1'));
      //console.log('::::::::', respuestaXD);
      
      localStorage.removeItem('number1');
      localStorage.removeItem('arbol1');
      localStorage.removeItem('Msj1');
      chat_1.innerHTML = '';
      document.getElementById('numero_chat1').innerHTML = ' ';
      console.log('CERRÉ EL CHAT UWU');

      sessionStorage.removeItem('tipificacion1');
      sessionStorage.removeItem('subtipificacion1');
      document.getElementById("observacionChat1").value=''
      //document.getElementById('tipification1').selectedIndex=0;
      //document.getElementById('tipification2').selectedIndex=0;
    }
    else{
      
      M.toast({html: 'DILIGENCIE TODOS LOS CAMPOS'})
    }
    
  });

  closeChat2.addEventListener('click',async() => {
    let chat_2 = document.getElementById(number2);
    let arbol2 = localStorage.getItem('arbol2');
    if (sessionStorage.getItem('tipificacion2')!=null && sessionStorage.getItem('subtipificacion2')!=null) {
      const mensajeFin="gracias por contactarnos nos estaremos viendo en proximas ocasiones";
    
      postData('/laika/enviarMensaje', { MEN_NUMERO_DESTINO: number2, MEN_TEXTO: mensajeFin,FK_GES_CODIGO:arbol2 }).then((res) => {
        console.log(res);
      });
      let input =document.getElementById("observacionChat2").value;
      console.log("EL VALOR ES ",input);

      await cerrarCaso(arbol2, input,sessionStorage.getItem('tipificacion2'),sessionStorage.getItem('subtipificacion2'));
      localStorage.removeItem('number2');
      localStorage.removeItem('arbol2');
      localStorage.removeItem('Msj2');
      chat_2.innerHTML = '';
      document.getElementById('numero_chat2').innerHTML = ' ';
      console.log('CERRÉ EL CHAT UWU');
      sessionStorage.removeItem('tipificacion2');
      sessionStorage.removeItem('subtipificacion2');
      document.getElementById("observacionChat2").value=''
    }
    else{
      M.toast({html: 'DILIGENCIE TODOS LOS CAMPOS'});
    }
    
  });

  closeChat3.addEventListener('click', async () => {
    let chat_3 = document.getElementById(number3);
    let arbol3 = localStorage.getItem('arbol3');
    if (sessionStorage.getItem('tipificacion3')!=null && sessionStorage.getItem('subtipificacion3')!=null) {
      const mensajeFin="gracias por contactarnos nos estaremos viendo en proximas ocasiones";
    
      postData('/laika/enviarMensaje', { MEN_NUMERO_DESTINO: number3, MEN_TEXTO: mensajeFin,FK_GES_CODIGO:arbol3 }).then((res) => {
        console.log(res);
      });
      let input =document.getElementById("observacionChat3").value;
      console.log("EL VALOR ES ",input);
      await cerrarCaso(arbol3,input,sessionStorage.getItem('tipificacion3'),sessionStorage.getItem('subtipificacion3'));
      localStorage.removeItem('number3');
      localStorage.removeItem('arbol3');
      localStorage.removeItem('Msj3');
      chat_3.innerHTML = '';
      document.getElementById('numero_chat3').innerHTML = ' ';
      console.log('CERRÉ EL CHAT UWU');
      sessionStorage.removeItem('tipificacion3');
      sessionStorage.removeItem('subtipificacion3');
      document.getElementById("observacionChat3").value=''
    }
    else{
      M.toast({html: 'DILIGENCIE TODOS LOS CAMPOS'});
    }
    
  });

  //LISENER ENCARGADO DE CAMBIAR LOS ESTADOS DEL AGENTE EN LA BD
  auxState.addEventListener('change', (event) => {
    const resultado = event.target.value;
    let BREAK = 'BREAK';
    let ACTIVO = 'ACTIVO';
    let FINTURNO = 'TURNO CERRADO';

    if (resultado == 'BREAK') {
      console.log('ATENCION: SE ELIGIÓ ', resultado);
      var estadoBreak = resultado;
      postData('/laika/cambioEstado', { PKPER_NCODIGO: idPer, PER_AUXILIAR: estadoBreak }).then((result) => {
        console.log(result);
      });
      localStorage.setItem('estadoUser', BREAK);
    } else if (resultado == 'CERRAR TURNO') {
      if(localStorage.getItem('estadoUser')=='BREAK'){
        
        alert("ADVERTENCIA USTED ESTABA EN BREAK NO PUEDE CERRAR SESIÓN, SE ACTIVARÁ EL ESTADO ACTIVO ");

      var estadoActivo = "ACTIVO";
      postData('/laika/cambioEstado', { PKPER_NCODIGO: idPer, PER_AUXILIAR: estadoActivo }).then((result) => {
        console.log(result);
        localStorage.setItem('estadoUser',estadoActivo);
      });
       }
       else if (localStorage.getItem('estadoUser')=='ACTIVO'){
        console.log('ATENCION: SE ELIGIÓ', resultado);
      var estadoCerrarTurno = resultado;
      postData('/laika/cambioEstado', { PKPER_NCODIGO: idPer, PER_AUXILIAR: estadoCerrarTurno }).then((result) => {
        console.log(result);
      });
      localStorage.setItem('estadoUser', FINTURNO);

       }
      
    } else if (resultado == 'ACTIVO') {
      console.log('ATENCION: SE ELIGIÓ ', resultado);
      var activo = resultado;

      postData('/laika/cambioEstado', { PKPER_NCODIGO: idPer, PER_AUXILIAR: activo }).then((result) => {
        console.log(result);
      });
      localStorage.setItem('estadoUser', ACTIVO);
    }
  });

  //AQUI SE REALIZA LA ESCUCHA DEL BOTON ENTER O DEL CLICK EN EL BOTON DE ENVIO
 //METODO ENCARGADO DE ENVIO DE MENSAJE, ESTA FUNCION RECIBE DOS PARAMETROS, EL NUMERO A ENVIAR
  //Y EL MENSAJE, LOS CHATS USAN LA MISMA RUTA PARA ENVIAR LOS MENSAJES PERO NO PUEDEN USAR EL MISMO SCROLL
  //ASÍ QUE TIENEN METODOS DISTINTOS
 

  inputMensaje1.addEventListener('keyup', (e) => {
    if (e.key === 'Enter') {
      texto = inputMensaje1.value;
      enviarMensaje(number1, texto);
      inputMensaje1.focus();
    }
  });

  
  btnEnvioMensaje_1.addEventListener('click', () => {
    texto = inputMensaje1.value;
     
    enviarMensaje(number1, texto);
    inputMensaje1.focus();
  });

  // inputMensaje2.removeEventListener('keyup', false)
  
  inputMensaje2.addEventListener('keypress', (e) =>{
    // IE
    console.log("antes de preguntar la tecla");
    if (e.keyCode == 13) {
     //console.log("dentro del if");
      //console.log('Enter +++++++++++++++++++++++++++++++++++++++++++++++++');

      number = number2;
      

      Tnumber = number;
      console.log("ANTES DE ENTRAR AL NUMERO");
      inputMensaje2.focus();
      enviarMensaje2(number2, inputMensaje2.value);
      
     //console.log("***************************EL VALOR ES ES ",inputMensaje2.value);
      
    }
    
    });

    const btnEnvioMensaje_2=document.getElementById('btnEnvioMensaje_2') ; 
    btnEnvioMensaje_2.addEventListener('click', () => {
      console.log("ENTRO AL CLICK");
    console.log('+++++++++++++++++++++++++++++++++++++++++++++++++');
    texto = inputMensaje2.value;
    enviarMensaje2(number2, texto);
    inputMensaje2.focus();
  });

  
  inputMensaje3.addEventListener('keyup', (e) => {
    if (e.key === 'Enter') {
      number = number3;
      texto = inputMensaje3.value;

      Tnumber = number;
      console.info('este es el valor y el numero que estoy recogiendo del input 3', Tnumber, texto);
      enviarMensaje3(Tnumber, texto);

      inputMensaje3.focus();
    }
  });

  btnEnvioMensaje_3.addEventListener('click', () => {
    number = number3;
    texto = inputMensaje3.value;

    Tnumber = number;
    console.info('este es el valor y el numero que estoy recogiendo del input 3', Tnumber, texto);
    enviarMensaje3(Tnumber, texto);
    inputMensaje3.focus();
  });


  const enviarMensaje = (numero, mensaje) => {
    let chat_1 = document.getElementById(number1);
    if (inputMensaje1.value === '') {
      //Toast.fire({ icon: 'info', title: 'Ingrese Mensaje' });
      console.log("ENTRÓ UNO VACIO");
    } else {
      let arboll1= localStorage.getItem('arbol1');
      postData('/laika/enviarMensaje', { MEN_NUMERO_DESTINO: numero, MEN_TEXTO: mensaje, FK_GES_CODIGO:arboll1}).then((res) => {
        console.log(res);
        
      });
      inputMensaje1.value = '';
        chat_1.scrollTo({
          top: chat_1.scrollHeight,
        });
    }
  };

  const enviarMensaje2 = (numero, mensaje) => {
    let chat_2 = document.getElementById(number2);
    if (inputMensaje2.value === '') {
      Toast.fire({ icon: 'info', title: 'Ingrese Mensaje' });
    } else {
      let arboll2= localStorage.getItem('arbol2');
      console.log("OBTENGO ",numero,mensaje);
      postData('/laika/enviarMensaje', { MEN_NUMERO_DESTINO: numero, MEN_TEXTO: mensaje,FK_GES_CODIGO:arboll2}).then((res) => {
        console.log(res);
      });
      console.log('HICE UNA PÉTICIÓN JEJE');
      //chat_313481.innerHTML += `<div class='mensaje_enviado'><span>${inputMensaje1.value}</span></div>`;
      inputMensaje2.value = '';
      chat_2.scrollTo({
        top: chat_2.scrollHeight,
      });
    }
    console.log('HICE UNA PÉTICIÓN JEJE2');
  };

  const enviarMensaje3 = (numero, mensaje) => {
    let chat_3 = document.getElementById(number3);
    if (inputMensaje3.value === '') {
      Toast.fire({ icon: 'info', title: 'Ingrese Mensaje' });
    } else {
      let arboll3= localStorage.getItem('arbol3');
      postData('/laika/enviarMensaje', { MEN_NUMERO_DESTINO: numero, MEN_TEXTO: mensaje,FK_GES_CODIGO:arboll3 }).then((res) => {
        console.log(res);
      });
      console.log('HICE UNA PÉTICIÓN JEJE');
      //chat_313481.innerHTML += `<div class='mensaje_enviado'><span>${inputMensaje1.value}</span></div>`;
      inputMensaje3.value = '';
      chat_3.scrollTo({
        top: chat_3.scrollHeight,
      });
    }
  };

  btnLogOut = document.getElementById('close_session');
  btnLogOut.addEventListener('click',() => { 
    
    
    console.log("HOOOOOOOOOOOOOOOOOOOOLIRIJILLA");
    localStorage.removeItem('number1');
    localStorage.removeItem('arbol1');
    localStorage.removeItem('Msj1');
    localStorage.removeItem('number2');
    localStorage.removeItem('arbol2');
    localStorage.removeItem('Msj2');
    localStorage.removeItem('number3');
    localStorage.removeItem('arbol3');
    localStorage.removeItem('Msj3');
    localStorage.removeItem('cantidad');
    localStorage.removeItem('estadoUser');
    

  });
  

  setInterval(function ping () {
    let state=localStorage.getItem('estadoUser');
    postData('/laika/cambioEstado', { PKPER_NCODIGO: idPer, PER_AUXILIAR: state }).then((result) => {
      console.log("MAKING PING....!",result);
    });

  }, 100000);




  tipificacion1.addEventListener('change',function () {
    var selectedOption= this.options[tipificacion1.selectedIndex];
    var select2;
    const option = document.createElement('option')
    console.log("opcion elegidda ",selectedOption.text);
    if (selectedOption.text=="Gestión cita") {
      console.log("YA ENTRE AL IF");
      subtipificacion1.innerHTML=' ';
      subtipificacion1.add(new Option("cita agendada"));
      subtipificacion1.add(new Option("confirmada"));
      subtipificacion1.add(new Option("cancelada"));
      $('#subtipification1').formSelect();
      sessionStorage.removeItem('tipificacion2');
      sessionStorage.removeItem('tipificacion3');
      sessionStorage.setItem('tipificacion1',selectedOption.text);
      //subtipificacion1.appendChild(option);
    }
    else if(selectedOption.text=="No agendada"){
      subtipificacion1.innerHTML=' ';
      subtipificacion1.add(new Option("Sin agenda"));
      subtipificacion1.add(new Option("Autorización errada"));
      subtipificacion1.add(new Option("No se maneja"));
      subtipificacion1.add(new Option("Inactivo EPS"));
      subtipificacion1.add(new Option("Escalamiento"));
      subtipificacion1.add(new Option("No se acepta disponibilidad"));
      $('#subtipification1').formSelect();
      sessionStorage.removeItem('tipificacion2');
      sessionStorage.removeItem('tipificacion3');
      sessionStorage.setItem('tipificacion1',selectedOption.text);
  
    }
    else if(selectedOption.text=="Información general"){
      subtipificacion1.innerHTML=' ';
      subtipificacion1.add(new Option("Se direcciona al conmutador"));
      subtipificacion1.add(new Option("Otros"));
      $('#subtipification1').formSelect();
      sessionStorage.removeItem('tipificacion2');
      sessionStorage.removeItem('tipificacion3');
      sessionStorage.setItem('tipificacion1',selectedOption.text);
    }
    else if(selectedOption.text=="Cliente abandona chat"){
      subtipificacion1.innerHTML=' ';
      subtipificacion1.add(new Option("Tiempo de espera agotado"));
      subtipificacion1.add(new Option("Equivocado"));
      $('#subtipification1').formSelect();
      sessionStorage.removeItem('tipificacion2');
      sessionStorage.removeItem('tipificacion3');
      sessionStorage.setItem('tipificacion1',selectedOption.text);
    }
  
  
  })
  
  
  
  subtipificacion1.addEventListener('change',function () {
    var selectedOption= this.options[subtipificacion1.selectedIndex];
    
    const option = document.createElement('option')
    console.log("opcion elegidda ",selectedOption.text);
    sessionStorage.removeItem('subtipificacion2');
    sessionStorage.removeItem('subtipificacion3');
    sessionStorage.setItem('subtipificacion1',selectedOption.text);
  })





  tipificacion2.addEventListener('change',function () {
    var selectedOption= this.options[tipificacion2.selectedIndex];
    var select2;
    const option = document.createElement('option')
    console.log("opcion elegidda ",selectedOption.text);
    if (selectedOption.text=="Gestión cita") {
      console.log("YA ENTRE AL IF");
      subtipificacion2.innerHTML=' ';
      subtipificacion2.add(new Option("cita agendada"));
      subtipificacion2.add(new Option("confirmada"));
      subtipificacion2.add(new Option("cancelada"));
      $('#subtipification2').formSelect();
      sessionStorage.removeItem('tipificacion1')
      sessionStorage.removeItem('tipificacion3')
      sessionStorage.setItem('tipificacion2',selectedOption.text);
      //subtipificacion1.appendChild(option);
    }
    else if(selectedOption.text=="No agendada"){
      subtipificacion2.innerHTML=' ';
      subtipificacion2.add(new Option("Sin agenda"));
      subtipificacion2.add(new Option("Autorización errada"));
      subtipificacion2.add(new Option("No se maneja"));
      subtipificacion2.add(new Option("Inactivo EPS"));
      subtipificacion2.add(new Option("Escalamiento"));
      subtipificacion2.add(new Option("No se acepta disponibilidad"));
      $('#subtipification2').formSelect();
      sessionStorage.removeItem('tipificacion1')
      sessionStorage.removeItem('tipificacion3')
      sessionStorage.setItem('tipificacion2',selectedOption.text);
  
    }
    else if(selectedOption.text=="Información general"){
      subtipificacion2.innerHTML=' ';
      subtipificacion2.add(new Option("Se direcciona al conmutador"));
      subtipificacion2.add(new Option("Otros"));
      $('#subtipification2').formSelect();
      sessionStorage.removeItem('tipificacion1')
      sessionStorage.removeItem('tipificacion3')
      sessionStorage.setItem('tipificacion2',selectedOption.text);
    }
    else if(selectedOption.text=="Cliente abandona chat"){
      subtipificacion2.innerHTML=' ';
      subtipificacion2.add(new Option("Tiempo de espera agotado"));
      subtipificacion2.add(new Option("Equivocado"));
      $('#subtipification2').formSelect();
      sessionStorage.removeItem('tipificacion1')
      sessionStorage.removeItem('tipificacion3')
      sessionStorage.setItem('tipificacion2',selectedOption.text);
    }
  
  
  })
  
  subtipificacion2.addEventListener('change',function () {
    var selectedOption= this.options[subtipificacion2.selectedIndex];
    
    const option = document.createElement('option')
    console.log("opcion elegidda ",selectedOption.text);
    sessionStorage.removeItem('subtipificacion1');
    sessionStorage.removeItem('subtipificacion3');
    sessionStorage.setItem('subtipificacion2',selectedOption.text);
  })



  tipificacion3.addEventListener('change',function () {
    var selectedOption= this.options[tipificacion3.selectedIndex];
    var select2;
    const option = document.createElement('option')
    console.log("opcion elegidda ",selectedOption.text);
    if (selectedOption.text=="Gestión cita") {
      console.log("YA ENTRE AL IF");
      subtipificacion3.innerHTML=' ';

      subtipificacion3.add(new Option("cita agendada"));
      subtipificacion3.add(new Option("confirmada"));
      subtipificacion3.add(new Option("cancelada"));
      $('#subtipificacion3').formSelect();
      sessionStorage.removeItem('tipificacion1')
      sessionStorage.removeItem('tipificacion2')
      sessionStorage.setItem('tipificacion3',selectedOption.text);
      //subtipificacion1.appendChild(option);
    }
    else if(selectedOption.text=="No agendada"){
      subtipificacion3.innerHTML=' ';
      subtipificacion3.add(new Option("Sin agenda"));
      subtipificacion3.add(new Option("Autorización errada"));
      subtipificacion3.add(new Option("No se maneja"));
      subtipificacion3.add(new Option("Inactivo EPS"));
      subtipificacion3.add(new Option("Escalamiento"));
      subtipificacion3.add(new Option("No se acepta disponibilidad"));
      $('#subtipification3').formSelect();
      sessionStorage.removeItem('tipificacion1')
      sessionStorage.removeItem('tipificacion2')
      sessionStorage.setItem('tipificacion3',selectedOption.text);
  
    }
    else if(selectedOption.text=="Información general"){
      subtipificacion3.innerHTML=' ';
      subtipificacion3.add(new Option("Se direcciona al conmutador"));
      subtipificacion3.add(new Option("Otros"));
      $('#subtipification3').formSelect();
      sessionStorage.removeItem('tipificacion1')
      sessionStorage.removeItem('tipificacion2')
      sessionStorage.setItem('tipificacion3',selectedOption.text);
    }
    else if(selectedOption.text=="Cliente abandona chat"){
      subtipificacion3.innerHTML=' ';
      subtipificacion3.add(new Option("Tiempo de espera agotado"));
      subtipificacion3.add(new Option("Equivocado"));
      $('#subtipification3').formSelect();
      sessionStorage.removeItem('tipificacion1')
      sessionStorage.removeItem('tipificacion2')
      sessionStorage.setItem('tipificacion3',selectedOption.text);
    }
  
  
  })

  subtipificacion3.addEventListener('change',function () {
    var selectedOption= this.options[subtipificacion3.selectedIndex];
    
    const option = document.createElement('option')
    console.log("opcion elegidda ",selectedOption.text);
    sessionStorage.removeItem('subtipificacion1')
      sessionStorage.removeItem('subtipificacion2')
    sessionStorage.setItem('subtipificacion3',selectedOption.text);
  })











});
