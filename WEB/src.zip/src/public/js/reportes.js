document.addEventListener('DOMContentLoaded', () => {
  let table = '';
  let table1 = '';
  let information = [];
  let casosAbiertos = 0;
  let casosCerrados = 0;
  let casosPendientes = 0;
  let hora1;
  let hora2;
  let hora3;
  let hora4;
  let hora5;
  let mychart;
  let idclick;
  /*
  setTimeout(() => {
    
    M.toast({html: 'CARGANDO... ESPERE POR FAVOR'});  
  }, 1000);*/

 cargarLoader("Espere por favor...");
  
  setTimeout(() => {
    ocultarLoader();
  }, 6000);
  /*
  setTimeout(() => {
    M.toast({html: 'CARGANDO..'})  
  }, 2000);
  setTimeout(() => {
    M.toast({html: 'CARGANDO.'})  
  }, 3000);
  */
  
  
  mychart = document.getElementById('mychar').getContext('2d');
  const refreshtableUser = () => {
    getData('/samaritanaRep/allUser').then((res) => {
      //console.log("HERRRRRRRRRRRR");
      table = '';
      res.result.forEach((mensaje) => {
        table += '<tr class="clickable-row modal-trigger" data-idsito="' + mensaje.PKPER_NCODIGO + '" href="#modalDetGestion">';

        table += '  <td> ' + mensaje.CRE_CUSUARIO + '</td>';

        table += '  <td>' + mensaje.NOMBRE + '</td>';
        table += '  <td>' + mensaje.DOCUMENTO + '</td>';
        table += '  <td>' + mensaje.PER_AUXILIAR + '</td>';
        table += '  <td>' + mensaje.CANTIDAD_CHAT + '/3' + '</td>';

        
        table += '</tr>';
      });

      document.getElementById('table1').innerHTML = table;
      clickTrs();
    });
    // ! Repeat
    setTimeout(() => {
      refreshtableUser();
    }, 2000);
  };
  refreshtableUser();

setTimeout(() => {
  hora1=  new Date().getHours()-1;
  hora2= new Date().getHours()-2;
  hora3= new Date().getHours()-3;
  hora4= new Date().getHours()-4;
  hora5=new Date().getHours()-5;
/*
  hora1.setHours(hora1-1);
  hora2.setHours(hora2-2);
  hora3.setHours(hora3-3);
  hora4.setHours(hora4-4);
  hora5.setHours(hora5-5);
*/

  setInterval(() => {
    //captura fechas
  hora1=  new Date().getHours()-1;
  hora2= new Date().getHours()-2;
  hora3= new Date().getHours()-3;
  hora4= new Date().getHours()-4;
  hora5=new Date().getHours()-5;

console.log("las horas son",hora=new Date().getHours());

}, 10000);

}, 2000);


  const RefreshtableCasosPendientes=() =>{
  getData('/samaritanaRep/allCasosPendientes').then((res) => {
      //console.log("HERRRRRRRRRRRR");
      table = '';
      res.result.forEach((mensaje) => {
        table += '<tr class="clickable-row modal-trigger" data-idsito2="' + mensaje.PKGES_CODIGO + '" href="#">';

        table += '  <td> ' + mensaje.GES_NUMERO_COMUNICA + '</td>';

        table += '  <td>' + mensaje.GES_CDETALLE + '</td>';
        table += '  <td>' + mensaje.GES_CDETALLE1 + '</td>';
        table += '  <td>' + mensaje.GES_CDETALLE3 + '</td>';
        table += '  <td>' + mensaje.GES_CDETALLE6 +  '</td>';

        
        table += '</tr>';
      });

      document.getElementById('table2').innerHTML = table;
     // clickTrs();
    });
    // ! Repeat
    setTimeout(() => {
      RefreshtableCasosPendientes();
    }, 2000);

  }
  RefreshtableCasosPendientes();
  //refresco data de las tablas

//esta primera es la grafica de torta

  setInterval(function updateData() {
    getData('/samaritanaRep/countCasosOpen').then((res) => {
      casosAbiertos = res.contador;
      sessionStorage.setItem('casosAbiertos', res.contador);
    });
    getData('/samaritanaRep/countCasosClosed').then((res) => {
      casosCerrados = res.contador;
      sessionStorage.setItem('casosCerrados', res.contador);
    });
    getData('/samaritanaRep/countCasosPending').then((res) => {
      casosPendientes = res.contador;
      sessionStorage.setItem('casosPending', res.contador);
    });
/*******************************/
    var datetime1= new Date();
    var datetimeFin1= new Date();
    var datetime2= new Date();
    var datetimeFin2= new Date();
    var datetime3= new Date();
    var datetimeFin3= new Date();
    var datetime4= new Date();
    var datetimeFin4= new Date();
    var datetime5= new Date();
    var datetimeFin5= new Date();

    //1HORA
    if((datetime1.getHours()-1)>=10 || (datetime1.getHours()-1)>=10){
      console.log("EL DATETIME ES************ ",(datetime1.getHours()-1));
      datetime1= datetime1.getFullYear()+"-"+(datetime1.getMonth()+1)+"-"+datetime1.getDate()+" "+(datetime1.getHours()-1)+":"+"00:00"+"";
      datetimeFin1= datetimeFin1.getFullYear()+"-"+(datetimeFin1.getMonth()+1)+"-"+datetimeFin1.getDate()+" "+(datetimeFin1.getHours()-1)+":"+"59:59"+"";    
    }
    else if((datetime1.getHours()-1)<=9 || (datetimeFin1.getHours()-1)<=9 ){
      console.log("EL DATETIME ES************ ",datetime1.getHours());
      datetime1= datetime1.getFullYear()+"-"+(datetime1.getMonth()+1)+"-"+datetime1.getDate()+" "+"0"+(datetime1.getHours()-1)+":"+"00:00"+"";
      datetimeFin1= datetimeFin1.getFullYear()+"-"+(datetimeFin1.getMonth()+1)+"-"+datetimeFin1.getDate()+" "+"0"+(datetimeFin1.getHours()-1)+":"+"59:59"+"";    
    }
    //2HORAS
    if((datetime2.getHours()-2)>=10 || (datetime2.getHours()-2)>=10){
      console.log("EL DATETIME ES************ ",datetime2.getHours());
      datetime2= datetime2.getFullYear()+"-"+(datetime2.getMonth()+1)+"-"+datetime2.getDate()+" "+(datetime2.getHours()-2)+":"+"00:00"+"";
      datetimeFin2= datetimeFin2.getFullYear()+"-"+(datetimeFin2.getMonth()+1)+"-"+datetimeFin2.getDate()+" "+(datetimeFin2.getHours()-2)+":"+"59:59"+"";    
    }
    else if((datetime2.getHours()-2)<=9 || (datetimeFin2.getHours()-2)<=9 ){
      datetime2= datetime2.getFullYear()+"-"+(datetime2.getMonth()+1)+"-"+datetime2.getDate()+" "+"0"+(datetime2.getHours()-2)+":"+"00:00"+"";
      datetimeFin2= datetimeFin2.getFullYear()+"-"+(datetimeFin2.getMonth()+1)+"-"+datetimeFin2.getDate()+" "+"0"+(datetimeFin2.getHours()-2)+":"+"59:59"+"";    
    }
    //3 HORAS
    if((datetime3.getHours()-3)>=10 || (datetimeFin3.getHours()-3)>=10){
      datetime3= datetime3.getFullYear()+"-"+(datetime3.getMonth()+1)+"-"+datetime3.getDate()+" "+(datetime3.getHours()-3)+":"+"00:00"+"";
      datetimeFin3= datetimeFin3.getFullYear()+"-"+(datetimeFin3.getMonth()+1)+"-"+datetimeFin3.getDate()+" "+(datetimeFin3.getHours()-3)+":"+"59:59"+"";    
    }
    else if((datetime3.getHours()-3)<=9 || (datetime3.getHours()-3)<=9 ){
      datetime3= datetime3.getFullYear()+"-"+(datetime3.getMonth()+1)+"-"+datetime3.getDate()+" "+"0"+(datetime3.getHours()-3)+":"+"00:00"+"";
      datetimeFin3= datetimeFin3.getFullYear()+"-"+(datetimeFin3.getMonth()+1)+"-"+datetimeFin3.getDate()+" "+"0"+(datetimeFin3.getHours()-3)+":"+"59:59"+"";    
    }

    //4HORAS
    if((datetime4.getHours()-4)>=10 || (datetime4.getHours()-4)>=10){
      datetime4= datetime4.getFullYear()+"-"+(datetime4.getMonth()+1)+"-"+datetime4.getDate()+" "+(datetime4.getHours()-4)+":"+"00:00"+"";
      datetimeFin4= datetimeFin4.getFullYear()+"-"+(datetimeFin4.getMonth()+1)+"-"+datetimeFin4.getDate()+" "+(datetimeFin4.getHours()-4)+":"+"59:59"+"";    
    }
    else if((datetime4.getHours()-4)<=9 || (datetime4.getHours()-4)<=9 ){
      datetime4= datetime4.getFullYear()+"-"+(datetime4.getMonth()+1)+"-"+datetime4.getDate()+" "+"0"+(datetime4.getHours()-4)+":"+"00:00"+"";
      datetimeFin4= datetimeFin4.getFullYear()+"-"+(datetimeFin4.getMonth()+1)+"-"+datetimeFin4.getDate()+" "+"0"+(datetimeFin4.getHours()-4)+":"+"59:59"+"";    
    }
    //5HORAS
    if((datetime5.getHours()-5)>=10 || (datetime5.getHours()-5)>=10){
      console.log("EL DATETIME MAS VIEJO ES************ ",datetime5.getHours());
      datetime5= datetime5.getFullYear()+"-"+(datetime5.getMonth()+1)+"-"+datetime5.getDate()+" "+(datetime5.getHours()-5)+":"+"00:00"+"";
      datetimeFin5= datetimeFin5.getFullYear()+"-"+(datetimeFin5.getMonth()+1)+"-"+datetimeFin5.getDate()+" "+(datetimeFin5.getHours()-5)+":"+"59:59"+"";    
    }
    else if((datetime5.getHours()-5)<=9 || (datetime5.getHours()-5)<=9 ){
      console.log("EL DATETIME MAS VIEJO ES************ ",datetime5.getHours());
      datetime5= datetime5.getFullYear()+"-"+(datetime5.getMonth()+1)+"-"+datetime5.getDate()+" "+"0"+(datetime5.getHours()-5)+":"+"00:00"+"";
      datetimeFin5= datetimeFin5.getFullYear()+"-"+(datetimeFin5.getMonth()+1)+"-"+datetimeFin5.getDate()+" "+"0"+(datetimeFin5.getHours()-5)+":"+"59:59"+"";    
    }


    
    console.log("ENVIO ESTA DATA>>>>>>>>>>>>> ",datetime1,datetimeFin1);  
    console.log("ENVIO ESTA DATA>>>>>>>>>>>>> ",datetime2,datetimeFin2);  
    console.log("ENVIO ESTA DATA>>>>>>>>>>>>> ",datetime3,datetimeFin3);  
    console.log("ENVIO ESTA DATA>>>>>>>>>>>>> ",datetime4,datetimeFin4);  
    console.log("ENVIO ESTA DATA>>>>>>>>>>>>> ",datetime5,datetimeFin5);  


    postData('/samaritanaRep/count1horas', { HoraIni: datetime1 ,HoraFin:datetimeFin1}).then((res) => {
      sessionStorage.setItem('1hora', res.contador);
    });
    postData('/samaritanaRep/count2horas',{ HoraIni: datetime2 ,HoraFin:datetimeFin2}).then((res) => {
      
      sessionStorage.setItem('2hora', res.contador);
    });
    postData('/samaritanaRep/count3horas',{ HoraIni: datetime3 ,HoraFin:datetimeFin3}).then((res) => {
      
      sessionStorage.setItem('3hora', res.contador);
    });
    postData('/samaritanaRep/count4horas',{ HoraIni: datetime4 ,HoraFin:datetimeFin4}).then((res) => {
      
      sessionStorage.setItem('4hora', res.contador);
    });
    postData('/samaritanaRep/count5horas',{ HoraIni: datetime5 ,HoraFin:datetimeFin5}).then((res) => {
      
      sessionStorage.setItem('5hora', res.contador);
    });



    
  }, 4000);

  setTimeout(function grafica() {
    //console.log("LOS VALORES QUE RECOJO",casosAbiertos,casosCerrados,casosPendientes);
    massPopchart = new Chart(mychart, {
      type: 'doughnut',
      data: {
        labels: ['EN GESTION', 'CERRADOS','EN COLA'],
        datasets: [
          {
            label: 'METRICAS CHATS',
            data: [sessionStorage.getItem('casosAbiertos'), sessionStorage.getItem('casosCerrados'), sessionStorage.getItem('casosPending')],
            backgroundColor: ['rgb(255,172,51)' ,'rgb(119, 255, 51)' ,'rgb(240, 128, 128)'],
          },
        ],
      },
      options: {
        animation: false
      },
    });
    
    setInterval(() => {
      //massPopchart.data.labels.pop();
      if(massPopchart.data.datasets.length!=0){

        
          massPopchart.data.datasets.pop();
          console.log("HEY WACHE ESTO>>>>>>>>>>>>>>>>>>",massPopchart.data.datasets.length);
          let label =['EN GESTION', 'CERRADOS','EN COLA'];
          let casabierto;
          let cascerrado;
          let caspendiente;
          casabierto=sessionStorage.getItem('casosAbiertos');
          cascerrado=sessionStorage.getItem('casosCerrados');
          caspendiente=sessionStorage.getItem('casosPending');
          let dataS=[casabierto,cascerrado ,caspendiente];
          //massPopchart.data.labels.push(label);
          massPopchart.data.datasets.push({
            label:label,
            data:dataS,
            backgroundColor: ['rgb(255,172,51)' ,'rgb(119, 255, 51)' ,'rgb(240, 128, 128)']
            
          });
          massPopchart.update();
          
        
        
        


      }
      
    }, 8000);


    //updateChartDonut(mychart);
  }, 5000);

setTimeout(function graficaLine() {
  /*
  *TROZO DE CODIGO QUE SIRVE PARA LA GRAFICA LINEAL, PERO CUANDO SEAN BASTANTE DATOS
  let resting=[]
  // datetime= datetime.getFullYear();
  for (let index = 0; index <= 4; index++) {
    var datetime= new Date();
    var datetimeFin= new Date();
    datetime= datetime.getFullYear()+"-"+(datetime.getMonth()+1)+"-"+datetime.getDate()+" "+"0"+(datetime.getHours()-index)+":"+"00:00"+"";
    datetimeFin= datetimeFin.getFullYear()+"-"+(datetimeFin.getMonth()+1)+"-"+datetimeFin.getDate()+" "+"0"+(datetimeFin.getHours()-index)+":"+"59:59"+"";    
    console.log(">>>>>>>>>>>>>>EL RESULT",datetime,datetimeFin);      
    postData('/samaritanaRep/countHour', { HoraIni: datetime ,HoraFin:datetimeFin}).then((res) => {
      resting[index]=res.contador;
      console.log("LOS RESULTADOS SON ",res.contador);
    });

    console.log("TAMAÑO DEL ARRAY>>>>>>>>>",resting.length);
    console.log("TAMAÑO DEL ARRAY>>>>>>>>>",resting);
    

    }*/

      mychartLine = document.getElementById('mycharline').getContext('2d');

  console.log("LOS VALORES QUE RECOJO",sessionStorage.getItem('5hora'),sessionStorage.getItem('4hora'),sessionStorage.getItem('3hora'),sessionStorage.getItem('2hora'),sessionStorage.getItem('1hora'));
  Linechart = new Chart(mychartLine, {
    type: 'line',
    
    data: {
      labels: [hora5, hora4, hora3,hora2,hora1],
      datasets: [
        {
          label: 'CANTIDAD DE CASOS POR HORA',
          data: [sessionStorage.getItem('5hora'),sessionStorage.getItem('4hora'),sessionStorage.getItem('3hora'),sessionStorage.getItem('2hora'),sessionStorage.getItem('1hora')],
          backgroundColor: ['rgb(240, 128, 128)'],
        },
      ],

    },

    title: {
      display: true,
      text: 'CANTIDAD DE CASOS POR HORA'
    },
    
    options: {
      animation: false,
      responsive:true,
      scales: {
        x: {
          display: true,
          title: {
            display: true,
            text: 'ÚLTIMAS 5 HORAS',
            color: '#911',
            font: {
              family: 'Arial',
              size: 20,
              weight: 'bold',
              lineHeight: 1.2,
            },
            padding: {top: 20, left: 0, right: 0, bottom: 0}
          }
        },
        y: {
          beginAtZero:true,
          display: true,
          title: {
            display: true,
            text: 'CANTIDAD DE CASOS',
            color: '#191',
            font: {
              family: 'Arial',
              size: 20,
              style: 'normal',
              lineHeight: 1.2
            },
            padding: {top: 30, left: 0, right: 0, bottom: 0}
          }
          
        }
    },
  }
  });


  setInterval(() => {



    //quita los intervalos de tiempo
    
      //Linechart.data.labels.pop();
      //let dataE=[hora1,hora2,hora3,hora4,hora5];
      Linechart.data.datasets.pop();
      Linechart.data.datasets.push({
      label: 'CANTIDAD DE CASOS POR HORA',
      data:[sessionStorage.getItem('5hora'),sessionStorage.getItem('4hora'),sessionStorage.getItem('3hora'),sessionStorage.getItem('2hora'),sessionStorage.getItem('1hora')],
      backgroundColor: ['rgb(240, 128, 128)'],
        });

      Linechart.data.labels=[]
      Linechart.data.labels=[hora5,hora4,hora3,hora2,hora1]
      Linechart.update();
      
  }, 6000);
/*
  setInterval(() => {
    let labelS=[hora1,hora2,hora3,hora4,hora5];
    console.log("LAS HORAS SON",hora1,hora2,hora3,hora4,hora5);
        Linechart.data.labels.push({
          labels:[hora1,hora2,hora3,hora4,hora5],
          //data:dataE,
          backgroundColor: ['rgb(240, 128, 128)']
        });
        
        Linechart.update();
  }, 6000);
*/



  
  //updateChartDonut(mychart);
}, 5000);


  const clickTrs = () => {
    let numero=0;
    let diferencia='';
    let tables = ''; 
    let cadena='';
    let trs = document.querySelectorAll('[data-idsito]'),
    modaldetGestion = document.querySelector('#modaldetGestion .modal-content');
    
    trs.forEach((tr) => {
      
      
      tr.addEventListener('click', (efe) => {
      
        //para prevenir  que se siga haciendo el intervalo y la consulta  al hacer click sobre areas fuera del modal limpiamos el intervalo
        
        clearInterval(idclick);
        modaldetGestion.innerHTML = '';
        idclick= setInterval(() => {
        tables='';
        
        tables += '<table>';
        tables += '<tr>';
        tables += '<th>' + 'Numero cliente' + '</th>';
        tables += '<th>' + 'Tiempo atención del bot' + '</th>';
        tables += '<th>' + 'Tiempo atención del asesor' + '</th>';
        postData('/samaritanaRep/consultaFeatures', { PKPER_NCODIGO:tr.dataset.idsito }).then((res) => {
          console.log("EL IDSITO ES",tr.dataset.idsito);
          console.log("EL RESULT ES  ================>"+res.numeros2,"EL TIPO ES ",typeof(res.numeros2));
          cadena=res.numeros2;
          if(cadena!=""){
            cadena=cadena.split("-");
            console.log("==========>",cadena);

            for (let index = 0; index < cadena.length; index++) {
              cadena[index] = cadena[index].toString().split("|");
            
            }
  
            console.log(">>>>>>>>>>>",cadena);
            
  
            for (let index = 0; index < cadena.length; index++) {
              tables += '<tr>';
              //numero
               tables += '<td>'+' ' + cadena[index][1]+'</td>';
                tables += '<td>'+' ' + cadena[index][2]+'  MINUTOS' + '</td>';
                tables += '<td>'+' ' + cadena[index][3]+'  MINUTOS' + '</td>';
              
              
              
              //tiempo atencion bot
              
              //tiempo atencion asesor
              
              
            }
            
            tables += '</tr>';
            
            tables += '</table>';  
          modaldetGestion.innerHTML = tables;
  

          }
          else{
            tables += '<tr>';
            tables += '<td>'+' ' + "Sin datos por el momento"+'</td>';
            tables += '<td>'+' ' + "Sin datos por el momento"+'</td>';
            tables += '<td>'+' ' + "Sin datos por el momento"+'</td>';
            tables += '</tr>';
            
            tables += '</table>';  
          modaldetGestion.innerHTML = tables;
          }
          
          
         
        });
        
        
       }, 2000);
        
      });
    });
  };
  clickTrs();

  buttonclose = document.getElementById('closeChat1');
  buttonclose.addEventListener('click',()=>{
///cierra el intervalo para que no se sigan haciendo petciones
    console.log("SOY EL JOODIDO CLICK Y ESTE ES EL ID",idclick);
    clearInterval(idclick);
  
  });
});
